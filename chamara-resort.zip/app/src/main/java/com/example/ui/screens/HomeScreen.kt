package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.RoomEntity
import com.example.data.RoomStatus
import com.example.ui.components.LargeRoomButton
import com.example.ui.theme.AvailableGreen
import com.example.ui.theme.AvailableGreenBg
import com.example.ui.theme.AvailableGreenDot
import com.example.ui.theme.CashierPrimary
import com.example.util.PricingCalculator
import com.example.ui.theme.CashierPrimaryVariant
import com.example.ui.theme.CleanBg
import com.example.ui.theme.CleanBorder
import com.example.ui.theme.CleanTextPrimary
import com.example.ui.theme.CleanTextSecondary
import com.example.ui.theme.OccupiedRed
import com.example.ui.theme.OccupiedRedBg
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate50
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900

@Composable
fun HomeScreen(
    rooms: List<RoomEntity>,
    availableCount: Int,
    occupiedCount: Int,
    onRoomClick: (RoomEntity) -> Unit,
    onNewBillClick: () -> Unit,
    onReportsClick: () -> Unit = {},
    todayIncome: Double = 0.0,
    todayExpenses: Double = 0.0,
    todayNet: Double = 0.0,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    // Map rooms by roomNumber for quick access to the 13 rooms
    val roomMap = rooms.associateBy { it.roomNumber }

    // Row definitions matching the prompt:
    // 01 02 03 04 05
    // 06 07 08 09 10
    // 11  - 13 14
    val row1 = listOf("01", "02", "03", "04", "05")
    val row2 = listOf("06", "07", "08", "09", "10")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CleanBg)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Header - Clean Minimalism
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CHAMARA RESORT",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = CleanTextPrimary,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = "Cashier Dashboard",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CleanTextSecondary.copy(alpha = 0.7f),
                    letterSpacing = 1.2.sp
                )
            }
            Surface(
                color = Color.White,
                shape = RoundedCornerShape(20.dp),
                shadowElevation = 1.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, CleanBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(AvailableGreenDot)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ONLINE",
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = CleanTextPrimary,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        // Available & Occupied Stats Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Available Rooms Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CleanBorder),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("available_rooms_card")
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = "AVAILABLE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = CleanTextSecondary,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = String.format("%02d", availableCount),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = AvailableGreen
                    )
                    Text(
                        text = "Rooms Ready",
                        fontSize = 11.sp,
                        color = CleanTextSecondary.copy(alpha = 0.8f),
                        fontWeight = FontWeight.Normal
                    )
                }
            }

            // Occupied Rooms Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CleanBorder),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("occupied_rooms_card")
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = "OCCUPIED",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = CleanTextSecondary,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = String.format("%02d", occupiedCount),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = OccupiedRed
                    )
                    Text(
                        text = "Rooms in Use",
                        fontSize = 11.sp,
                        color = CleanTextSecondary.copy(alpha = 0.8f),
                        fontWeight = FontWeight.Normal
                    )
                }
            }
        }

        // 13 Rooms Grid - 5 Columns Grid
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Row 1: 01, 02, 03, 04, 05
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                row1.forEach { roomNum ->
                    val room = roomMap[roomNum]
                    if (room != null) {
                        LargeRoomButton(
                            room = room,
                            onClick = { onRoomClick(room) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Row 2: 06, 07, 08, 09, 10
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                row2.forEach { roomNum ->
                    val room = roomMap[roomNum]
                    if (room != null) {
                        LargeRoomButton(
                            room = room,
                            onClick = { onRoomClick(room) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Row 3: 11, [dash for 12], 13, 14, [spacer]
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val room11 = roomMap["11"]
                if (room11 != null) {
                    LargeRoomButton(
                        room = room11,
                        onClick = { onRoomClick(room11) },
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    Spacer(modifier = Modifier.weight(1f))
                }

                // Room 12 does NOT exist - minimal dash placeholder
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(82.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.5f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CleanBorder.copy(alpha = 0.5f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "—",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = CleanTextSecondary.copy(alpha = 0.4f)
                        )
                    }
                }

                val room13 = roomMap["13"]
                if (room13 != null) {
                    LargeRoomButton(
                        room = room13,
                        onClick = { onRoomClick(room13) },
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    Spacer(modifier = Modifier.weight(1f))
                }

                val room14 = roomMap["14"]
                if (room14 != null) {
                    LargeRoomButton(
                        room = room14,
                        onClick = { onRoomClick(room14) },
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    Spacer(modifier = Modifier.weight(1f))
                }

                // 5th column placeholder for perfect 5-col alignment
                Spacer(modifier = Modifier.weight(1f))
            }
        }

        // Primary Action: Large "+ NEW BILL" Button
        Button(
            onClick = onNewBillClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("new_bill_button"),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = CashierPrimary,
                contentColor = Color.White
            ),
            elevation = ButtonDefaults.buttonElevation(
                defaultElevation = 4.dp,
                pressedElevation = 2.dp
            )
        ) {
            Text(
                text = "+",
                fontSize = 24.sp,
                fontWeight = FontWeight.Light
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "NEW BILL",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
        }

        // Cashier Shift Financial Summary Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .clickable { onReportsClick() }
                .testTag("card_home_financial_summary"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, CleanBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFFEFF6FF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Assessment,
                                contentDescription = null,
                                tint = CashierPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "TODAY'S CASHIER REPORT",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CleanTextPrimary,
                            letterSpacing = 0.5.sp
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Reports",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CashierPrimary
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "View Reports",
                            tint = CashierPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Income
                    Column {
                        Text(
                            text = "INCOME",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = CleanTextSecondary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = PricingCalculator.formatCurrency(todayIncome),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF059669)
                        )
                    }

                    // Expenses
                    Column {
                        Text(
                            text = "EXPENSES",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = CleanTextSecondary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = PricingCalculator.formatCurrency(todayExpenses),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFD97706)
                        )
                    }

                    // Net
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "NET CASHIER",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = CleanTextSecondary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        val netColor = if (todayNet >= 0) Color(0xFF059669) else Color(0xFFDC2626)
                        Text(
                            text = PricingCalculator.formatCurrency(todayNet),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = netColor
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
    }
}
