package com.example.util

import com.example.data.RoomEntity
import com.example.data.RoomType
import com.example.data.StayType

object PricingCalculator {

    /**
     * Calculates the room charge based on a specific room entity and its dynamic custom pricing.
     */
    fun calculateRoomCharge(room: RoomEntity, guests: Int, stayType: StayType): Double {
        return room.getPrice(guests, stayType)
    }

    /**
     * Calculates the room charge based on room type, number of guests, and stay type.
     */
    fun calculateRoomCharge(roomType: RoomType, guests: Int, stayType: StayType): Double {
        val guestCount = guests.coerceAtLeast(1)

        return when (roomType) {
            RoomType.AC_FAMILY -> {
                when (stayType) {
                    StayType.NIGHT -> 5000.0
                    StayType.FULL_DAY -> 7500.0
                }
            }
            RoomType.AC -> {
                when (guestCount) {
                    1 -> if (stayType == StayType.NIGHT) 3000.0 else 4500.0
                    2 -> if (stayType == StayType.NIGHT) 3500.0 else 5500.0
                    3 -> if (stayType == StayType.NIGHT) 4000.0 else 6000.0
                    4 -> if (stayType == StayType.NIGHT) 4500.0 else 6500.0
                    else -> if (stayType == StayType.NIGHT) 5000.0 else 7500.0
                }
            }
            RoomType.NON_AC -> {
                when (guestCount) {
                    1 -> if (stayType == StayType.NIGHT) 2500.0 else 4000.0
                    2 -> if (stayType == StayType.NIGHT) 3000.0 else 4500.0
                    3 -> if (stayType == StayType.NIGHT) 3500.0 else 5000.0
                    4 -> if (stayType == StayType.NIGHT) 4000.0 else 5500.0
                    else -> if (stayType == StayType.NIGHT) 4500.0 else 6000.0
                }
            }
        }
    }

    /**
     * Formats currency as "Rs. 3,500" or "Rs. 3500"
     */
    fun formatCurrency(amount: Double): String {
        return if (amount % 1.0 == 0.0) {
            "Rs. %,d".format(amount.toLong())
        } else {
            "Rs. %,.2f".format(amount)
        }
    }
}
