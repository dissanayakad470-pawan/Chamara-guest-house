package com.example.util

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.BillEntity
import com.example.data.BillItemEntity
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object PdfInvoiceGenerator {

    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val MARGIN_LEFT = 36f
    private const val MARGIN_RIGHT = 559f
    private const val CONTENT_WIDTH = MARGIN_RIGHT - MARGIN_LEFT

    /**
     * Standardized filename: GuestHouse_INV-2026-0001.pdf
     */
    fun getInvoiceFileName(bill: BillEntity): String {
        val cleanNumber = bill.billNumber
            .replace('/', '-')
            .replace('\\', '-')
            .replace(' ', '_')
            .replace(':', '-')
        return "GuestHouse_$cleanNumber.pdf"
    }

    /**
     * Returns the dedicated file path inside the app's invoices directory.
     * Guarantees previous bills are NOT overwritten by using the distinct billNumber.
     */
    fun getInvoiceFile(context: Context, bill: BillEntity): File {
        val dir = File(context.filesDir, "invoices")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return File(dir, getInvoiceFileName(bill))
    }

    /**
     * Generates a high-quality, professional, 100% offline PDF invoice using Android's native PdfDocument.
     * Contains:
     * - Guest House Logo and Title
     * - Bill Number and Date
     * - Customer Name, NIC / ID Number, Phone Number, Customer ID Photo (if captured)
     * - Room Number, Room Type, Number of Guests, Stay Type, Check-in/Check-out Date & Time
     * - Room Charge, Itemized Extra Charges, Discount, TOTAL, PAID, BALANCE, Payment Method
     */
    fun generatePdf(context: Context, bill: BillEntity, items: List<BillItemEntity>): File {
        val file = getInvoiceFile(context, bill)

        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        // Paints
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A") // Slate 900
        }

        // 1. Header background / emblem
        val emblemRect = RectF(MARGIN_LEFT, 36f, MARGIN_LEFT + 52f, 88f)
        paint.color = Color.parseColor("#0F172A")
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(emblemRect, 10f, 10f, paint)

        // Monogram in emblem
        paint.color = Color.parseColor("#F59E0B") // Amber / Gold
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 20f
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("GH", emblemRect.centerX(), emblemRect.centerY() + 7f, paint)

        // Title and Subtitle
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 20f
        textPaint.color = Color.parseColor("#0F172A")
        canvas.drawText("GUEST HOUSE", MARGIN_LEFT + 62f, 60f, textPaint)

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textPaint.textSize = 9.5f
        textPaint.color = Color.parseColor("#64748B")
        canvas.drawText("Official Cashier Receipt & Tax Invoice", MARGIN_LEFT + 62f, 76f, textPaint)

        // Invoice Meta Box (Top Right)
        val metaBox = RectF(370f, 36f, MARGIN_RIGHT, 88f)
        paint.color = Color.parseColor("#F8FAFC")
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(metaBox, 8f, 8f, paint)
        paint.color = Color.parseColor("#CBD5E1")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        canvas.drawRoundRect(metaBox, 8f, 8f, paint)

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 8.5f
        textPaint.color = Color.parseColor("#64748B")
        canvas.drawText("INVOICE NUMBER", 382f, 52f, textPaint)

        textPaint.textSize = 12f
        textPaint.color = Color.parseColor("#0284C7") // Blue
        canvas.drawText(bill.billNumber, 382f, 67f, textPaint)

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textPaint.textSize = 9f
        textPaint.color = Color.parseColor("#334155")
        canvas.drawText("Date: ${bill.checkInDate}", 382f, 81f, textPaint)

        // Divider
        paint.color = Color.parseColor("#0F172A")
        paint.strokeWidth = 2f
        paint.style = Paint.Style.STROKE
        canvas.drawLine(MARGIN_LEFT, 100f, MARGIN_RIGHT, 100f, paint)

        // 2. Customer Information Section (with Customer Photo)
        var curY = 118f
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 10f
        textPaint.color = Color.parseColor("#475569")
        canvas.drawText("CUSTOMER INFORMATION", MARGIN_LEFT, curY, textPaint)

        curY += 6f
        val customerBoxHeight = 84f
        val customerBox = RectF(MARGIN_LEFT, curY, MARGIN_RIGHT, curY + customerBoxHeight)
        paint.color = Color.parseColor("#F8FAFC")
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(customerBox, 8f, 8f, paint)
        paint.color = Color.parseColor("#E2E8F0")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        canvas.drawRoundRect(customerBox, 8f, 8f, paint)

        // Customer details on left
        val colLabelX = MARGIN_LEFT + 14f
        val colValX = MARGIN_LEFT + 120f
        var custTextY = curY + 20f

        fun drawField(label: String, value: String, isValueBold: Boolean = true, colorHex: String = "#0F172A") {
            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textPaint.textSize = 9f
            textPaint.color = Color.parseColor("#64748B")
            canvas.drawText(label, colLabelX, custTextY, textPaint)

            textPaint.typeface = Typeface.create(Typeface.DEFAULT, if (isValueBold) Typeface.BOLD else Typeface.NORMAL)
            textPaint.color = Color.parseColor(colorHex)
            canvas.drawText(value, colValX, custTextY, textPaint)
            custTextY += 18f
        }

        drawField("Customer Name:", bill.customerName)
        drawField("NIC / ID Number:", bill.customerNic)
        drawField("Phone Number:", bill.customerPhone.ifBlank { "N/A" })
        drawField("Payment Method:", bill.paymentMethod.displayName, colorHex = "#0284C7")

        // Customer ID Photo on right
        val photoBox = RectF(MARGIN_RIGHT - 74f, curY + 7f, MARGIN_RIGHT - 8f, curY + 77f)
        val customerPhoto = loadCustomerPhoto(bill.customerPhotoPath)
        if (customerPhoto != null) {
            canvas.drawBitmap(customerPhoto, null, photoBox, null)
            paint.color = Color.parseColor("#CBD5E1")
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1f
            canvas.drawRoundRect(photoBox, 6f, 6f, paint)
        } else {
            paint.color = Color.parseColor("#E2E8F0")
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1f
            canvas.drawRoundRect(photoBox, 6f, 6f, paint)
            textPaint.textSize = 7.5f
            textPaint.color = Color.parseColor("#94A3B8")
            textPaint.textAlign = Paint.Align.CENTER
            canvas.drawText("No Photo", photoBox.centerX(), photoBox.centerY() + 3f, textPaint)
            textPaint.textAlign = Paint.Align.LEFT
        }

        // 3. Room & Stay Details Section
        curY += customerBoxHeight + 14f
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 10f
        textPaint.color = Color.parseColor("#475569")
        canvas.drawText("ROOM & STAY DETAILS", MARGIN_LEFT, curY, textPaint)

        curY += 6f
        val stayBoxHeight = 66f
        val stayBox = RectF(MARGIN_LEFT, curY, MARGIN_RIGHT, curY + stayBoxHeight)
        paint.color = Color.parseColor("#F8FAFC")
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(stayBox, 8f, 8f, paint)
        paint.color = Color.parseColor("#E2E8F0")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        canvas.drawRoundRect(stayBox, 8f, 8f, paint)

        // 2 Columns for room & stay
        var stayTextY = curY + 20f
        fun drawStayRow(l1: String, v1: String, l2: String, v2: String) {
            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textPaint.textSize = 9f
            textPaint.color = Color.parseColor("#64748B")
            canvas.drawText(l1, MARGIN_LEFT + 14f, stayTextY, textPaint)
            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textPaint.color = Color.parseColor("#0F172A")
            canvas.drawText(v1, MARGIN_LEFT + 105f, stayTextY, textPaint)

            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textPaint.color = Color.parseColor("#64748B")
            canvas.drawText(l2, 310f, stayTextY, textPaint)
            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textPaint.color = Color.parseColor("#0F172A")
            canvas.drawText(v2, 395f, stayTextY, textPaint)

            stayTextY += 18f
        }

        drawStayRow(
            "Room Number:", "Room ${bill.roomNumber} (${bill.roomType.badgeText})",
            "Stay Type:", bill.stayType.displayName
        )
        drawStayRow(
            "Room Type:", bill.roomType.displayName,
            "Check-in:", "${bill.checkInDate} (${bill.checkInTime})"
        )
        drawStayRow(
            "Guests Count:", "${bill.guestsCount} Person(s)",
            "Check-out:", "${bill.checkOutDate} (${bill.checkOutTime})"
        )

        // 4. Billing Breakdown Table
        curY += stayBoxHeight + 14f
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 10f
        textPaint.color = Color.parseColor("#475569")
        canvas.drawText("BILLING BREAKDOWN", MARGIN_LEFT, curY, textPaint)

        curY += 6f
        // Table Header
        val headerHeight = 22f
        val tableHeaderRect = RectF(MARGIN_LEFT, curY, MARGIN_RIGHT, curY + headerHeight)
        paint.color = Color.parseColor("#0F172A")
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(tableHeaderRect, 4f, 4f, paint)

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 8.5f
        textPaint.color = Color.WHITE
        canvas.drawText("DESCRIPTION", MARGIN_LEFT + 12f, curY + 14f, textPaint)
        canvas.drawText("CATEGORY", 320f, curY + 14f, textPaint)
        textPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText("AMOUNT", MARGIN_RIGHT - 12f, curY + 14f, textPaint)
        textPaint.textAlign = Paint.Align.LEFT

        curY += headerHeight + 4f

        // Table Rows
        fun drawTableRow(desc: String, cat: String, amountStr: String, isRoomCharge: Boolean = false) {
            paint.color = Color.parseColor("#F1F5F9")
            paint.strokeWidth = 0.5f
            paint.style = Paint.Style.STROKE
            canvas.drawLine(MARGIN_LEFT, curY + 16f, MARGIN_RIGHT, curY + 16f, paint)

            textPaint.typeface = Typeface.create(Typeface.DEFAULT, if (isRoomCharge) Typeface.BOLD else Typeface.NORMAL)
            textPaint.textSize = 9f
            textPaint.color = Color.parseColor("#0F172A")
            canvas.drawText(desc, MARGIN_LEFT + 12f, curY + 12f, textPaint)

            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textPaint.color = Color.parseColor("#64748B")
            canvas.drawText(cat, 320f, curY + 12f, textPaint)

            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textPaint.color = Color.parseColor("#0F172A")
            textPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText(amountStr, MARGIN_RIGHT - 12f, curY + 12f, textPaint)
            textPaint.textAlign = Paint.Align.LEFT

            curY += 20f
        }

        // Room charge row
        drawTableRow(
            desc = "Room ${bill.roomNumber} (${bill.roomType.displayName}, ${bill.stayType.displayName})",
            cat = "Room Tariff",
            amountStr = PricingCalculator.formatCurrency(bill.roomCharge),
            isRoomCharge = true
        )

        // Extra charge rows
        items.forEach { item ->
            drawTableRow(
                desc = item.description,
                cat = item.category,
                amountStr = PricingCalculator.formatCurrency(item.amount)
            )
        }

        // 5. Totals & Balance Summary Box
        curY += 8f
        val summaryBoxHeight = if (bill.discount > 0) 100f else 82f
        val summaryBox = RectF(MARGIN_LEFT, curY, MARGIN_RIGHT, curY + summaryBoxHeight)
        paint.color = Color.parseColor("#F8FAFC")
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(summaryBox, 8f, 8f, paint)
        paint.color = Color.parseColor("#CBD5E1")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        canvas.drawRoundRect(summaryBox, 8f, 8f, paint)

        var summaryTextY = curY + 18f

        // Discount if any
        if (bill.discount > 0) {
            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textPaint.textSize = 9.5f
            textPaint.color = Color.parseColor("#16A34A") // Green
            canvas.drawText("Discount Applied:", MARGIN_LEFT + 14f, summaryTextY, textPaint)
            textPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("-${PricingCalculator.formatCurrency(bill.discount)}", MARGIN_RIGHT - 14f, summaryTextY, textPaint)
            textPaint.textAlign = Paint.Align.LEFT
            summaryTextY += 18f
        }

        // TOTAL Highlight Row
        val totalHighlight = RectF(MARGIN_LEFT + 8f, summaryTextY - 14f, MARGIN_RIGHT - 8f, summaryTextY + 14f)
        paint.color = Color.parseColor("#E2E8F0")
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(totalHighlight, 6f, 6f, paint)

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 12f
        textPaint.color = Color.parseColor("#0F172A")
        canvas.drawText("TOTAL AMOUNT:", MARGIN_LEFT + 16f, summaryTextY + 4f, textPaint)

        textPaint.textSize = 13f
        textPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(PricingCalculator.formatCurrency(bill.total), MARGIN_RIGHT - 16f, summaryTextY + 4f, textPaint)
        textPaint.textAlign = Paint.Align.LEFT
        summaryTextY += 26f

        // PAID
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 10f
        textPaint.color = Color.parseColor("#0284C7")
        canvas.drawText("PAID (${bill.paymentMethod.displayName}):", MARGIN_LEFT + 14f, summaryTextY, textPaint)
        textPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(PricingCalculator.formatCurrency(bill.paid), MARGIN_RIGHT - 14f, summaryTextY, textPaint)
        textPaint.textAlign = Paint.Align.LEFT
        summaryTextY += 18f

        // BALANCE
        val isSettled = bill.balance <= 0.0
        val balanceColorHex = if (isSettled) "#16A34A" else "#DC2626"
        val balanceLabel = if (isSettled) "BALANCE (SETTLED):" else "BALANCE DUE:"
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 11f
        textPaint.color = Color.parseColor(balanceColorHex)
        canvas.drawText(balanceLabel, MARGIN_LEFT + 14f, summaryTextY, textPaint)
        textPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(PricingCalculator.formatCurrency(bill.balance), MARGIN_RIGHT - 14f, summaryTextY, textPaint)
        textPaint.textAlign = Paint.Align.LEFT

        // 6. Footer Section
        val footerY = PAGE_HEIGHT - 60f
        paint.color = Color.parseColor("#CBD5E1")
        paint.strokeWidth = 1f
        paint.style = Paint.Style.STROKE
        canvas.drawLine(MARGIN_LEFT, footerY, MARGIN_RIGHT, footerY, paint)

        textPaint.textAlign = Paint.Align.CENTER
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textPaint.textSize = 9.5f
        textPaint.color = Color.parseColor("#64748B")
        canvas.drawText("Thank you for staying with us! Please retain this bill for your records.", PAGE_WIDTH / 2f, footerY + 18f, textPaint)

        textPaint.textSize = 8f
        textPaint.color = Color.parseColor("#94A3B8")
        canvas.drawText("Official Guest House Cashier System • Generated Offline • No Internet Required", PAGE_WIDTH / 2f, footerY + 34f, textPaint)

        pdfDocument.finishPage(page)

        // Write directly to file
        FileOutputStream(file).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        return file
    }

    /**
     * Safely decodes and downsamples the customer photo for the PDF canvas.
     */
    private fun loadCustomerPhoto(path: String?): Bitmap? {
        if (path.isNullOrBlank()) return null
        val file = File(path)
        if (!file.exists()) return null

        return try {
            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, boundsOptions)

            val reqWidth = 180
            val reqHeight = 180
            var sampleSize = 1
            if (boundsOptions.outHeight > reqHeight || boundsOptions.outWidth > reqWidth) {
                val halfH = boundsOptions.outHeight / 2
                val halfW = boundsOptions.outWidth / 2
                while ((halfH / sampleSize) >= reqHeight && (halfW / sampleSize) >= reqWidth) {
                    sampleSize *= 2
                }
            }
            val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            BitmapFactory.decodeFile(file.absolutePath, decodeOptions)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Native Android share sheet launcher for the PDF file.
     * Works with WhatsApp, Gmail, Messenger, Bluetooth, Nearby/Quick Share, Drive, and any app supporting file sharing.
     */
    fun sharePdf(context: Context, bill: BillEntity, items: List<BillItemEntity>) {
        val file = generatePdf(context, bill, items)
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Guest House Bill - ${bill.billNumber}")
            putExtra(
                Intent.EXTRA_TEXT,
                "Bill Receipt for ${bill.customerName} - Room ${bill.roomNumber} (${bill.billNumber})\nTotal: ${PricingCalculator.formatCurrency(bill.total)}"
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        val chooser = Intent.createChooser(sendIntent, "Share Bill PDF").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    /**
     * Launches Android's native print manager with the exact generated PDF document.
     */
    fun printPdf(activity: Activity, bill: BillEntity, items: List<BillItemEntity>) {
        val file = generatePdf(activity, bill, items)
        val printManager = activity.getSystemService(Context.PRINT_SERVICE) as? PrintManager
        if (printManager == null) {
            Toast.makeText(activity, "Print service is not available on this device", Toast.LENGTH_SHORT).show()
            return
        }

        val jobName = "GuestHouse_${bill.billNumber}"
        val printAdapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder(getInvoiceFileName(bill))
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out android.print.PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                try {
                    FileInputStream(file).use { input ->
                        FileOutputStream(destination?.fileDescriptor).use { output ->
                            input.copyTo(output)
                        }
                    }
                    callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                }
            }
        }

        printManager.print(jobName, printAdapter, PrintAttributes.Builder().build())
    }

    /**
     * Copies / exports the generated PDF to user-accessible Downloads or documents storage,
     * and returns a user-friendly confirmation message.
     */
    fun savePdfToStorage(context: Context, bill: BillEntity, items: List<BillItemEntity>): String {
        val srcFile = generatePdf(context, bill, items)
        val fileName = getInvoiceFileName(bill)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/GuestHouse")
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(srcFile).use { input ->
                            input.copyTo(out)
                        }
                    }
                    return "PDF saved to Downloads: $fileName"
                }
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val targetDir = File(downloadsDir, "GuestHouse")
                if (!targetDir.exists()) targetDir.mkdirs()
                val destFile = File(targetDir, fileName)
                FileInputStream(srcFile).use { input ->
                    FileOutputStream(destFile).use { output ->
                        input.copyTo(output)
                    }
                }
                return "PDF saved to Downloads: $fileName"
            }
        } catch (e: Exception) {
            // Fallback to internal storage confirmation
        }
        return "PDF saved successfully: $fileName"
    }
}
