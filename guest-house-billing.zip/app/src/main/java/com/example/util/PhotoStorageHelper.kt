package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

object PhotoStorageHelper {

    private fun getPhotosDir(context: Context): File {
        val dir = File(context.filesDir, "customer_photos")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    /**
     * Saves a Bitmap from camera preview to local private storage
     */
    fun saveBitmap(context: Context, bitmap: Bitmap): String {
        val photosDir = getPhotosDir(context)
        val fileName = "cust_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.jpg"
        val file = File(photosDir, fileName)

        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)
            out.flush()
        }
        return file.absolutePath
    }

    /**
     * Copies an image from a Gallery Uri to local private storage
     */
    fun saveUriImage(context: Context, uri: Uri): String? {
        return try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            inputStream?.use { stream ->
                val bitmap = BitmapFactory.decodeStream(stream) ?: return null
                saveBitmap(context, bitmap)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
