package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object ReportDateHelper {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    fun getToday(): String {
        return dateFormat.format(Date())
    }

    fun getThisWeekRange(): Pair<String, String> {
        val cal = Calendar.getInstance()
        cal.firstDayOfWeek = Calendar.MONDAY
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        val daysFromMonday = if (dayOfWeek == Calendar.SUNDAY) 6 else dayOfWeek - Calendar.MONDAY
        cal.add(Calendar.DAY_OF_MONTH, -daysFromMonday)
        val fromDate = dateFormat.format(cal.time)
        cal.add(Calendar.DAY_OF_MONTH, 6)
        val toDate = dateFormat.format(cal.time)
        return Pair(fromDate, toDate)
    }

    fun getThisMonthRange(): Pair<String, String> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val fromDate = dateFormat.format(cal.time)
        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH))
        val toDate = dateFormat.format(cal.time)
        return Pair(fromDate, toDate)
    }

    fun formatDisplayDate(dateStr: String): String {
        return try {
            val parsed = dateFormat.parse(dateStr) ?: return dateStr
            SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(parsed)
        } catch (_: Exception) {
            dateStr
        }
    }
}
