package com.example.util

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.data.BillEntity
import com.example.data.ExpenseEntity
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfReportGenerator {

    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val MARGIN_LEFT = 36f
    private const val MARGIN_RIGHT = 559f
    private const val CONTENT_WIDTH = MARGIN_RIGHT - MARGIN_LEFT

    fun getReportFileName(periodTitle: String, fromDate: String, toDate: String): String {
        val cleanPeriod = periodTitle.replace(" ", "_").replace("/", "-")
        return "GuestHouse_Report_${cleanPeriod}_${fromDate}_to_${toDate}.pdf"
    }

    fun getReportFile(context: Context, periodTitle: String, fromDate: String, toDate: String): File {
        val dir = File(context.filesDir, "reports")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return File(dir, getReportFileName(periodTitle, fromDate, toDate))
    }

    /**
     * Generates a comprehensive, 100% offline Income and Expense PDF Report.
     * Respects the core principle: Only money actually received is counted as income.
     */
    fun generateReportPdf(
        context: Context,
        periodTitle: String,
        fromDate: String,
        toDate: String,
        totalIncome: Double,
        totalExpenses: Double,
        netIncome: Double,
        outstandingBalance: Double,
        billsCount: Int,
        bills: List<BillEntity>,
        expenses: List<ExpenseEntity>
    ): File {
        val file = getReportFile(context, periodTitle, fromDate, toDate)
        val pdfDocument = PdfDocument()

        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
        }

        // 1. Header with Emblem
        val emblemRect = RectF(MARGIN_LEFT, 32f, MARGIN_LEFT + 46f, 78f)
        paint.color = Color.parseColor("#0F172A") // Slate 900
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(emblemRect, 8f, 8f, paint)

        paint.color = Color.parseColor("#F59E0B") // Amber
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textSize = 18f
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("GH", emblemRect.centerX(), emblemRect.centerY() + 6f, paint)

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 18f
        textPaint.color = Color.parseColor("#0F172A")
        canvas.drawText("GUEST HOUSE", MARGIN_LEFT + 56f, 52f, textPaint)

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textPaint.textSize = 9.5f
        textPaint.color = Color.parseColor("#64748B")
        canvas.drawText("Financial Income & Expense Report • Official Cashier Summary", MARGIN_LEFT + 56f, 68f, textPaint)

        // Report Meta Box (Right Side)
        val metaBox = RectF(370f, 32f, MARGIN_RIGHT, 78f)
        paint.color = Color.parseColor("#F8FAFC")
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(metaBox, 8f, 8f, paint)
        paint.color = Color.parseColor("#CBD5E1")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        canvas.drawRoundRect(metaBox, 8f, 8f, paint)

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 8.5f
        textPaint.color = Color.parseColor("#64748B")
        canvas.drawText("REPORT PERIOD", 380f, 47f, textPaint)

        textPaint.textSize = 11f
        textPaint.color = Color.parseColor("#0284C7")
        canvas.drawText(periodTitle, 380f, 61f, textPaint)

        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textPaint.textSize = 8f
        textPaint.color = Color.parseColor("#475569")
        canvas.drawText("$fromDate to $toDate", 380f, 73f, textPaint)

        // Divider
        paint.color = Color.parseColor("#0F172A")
        paint.strokeWidth = 2f
        paint.style = Paint.Style.STROKE
        canvas.drawLine(MARGIN_LEFT, 88f, MARGIN_RIGHT, 88f, paint)

        // 2. Large Financial Metrics Cards (2x2 Grid)
        var curY = 100f

        val cardWidth = (CONTENT_WIDTH - 12f) / 2f
        val cardHeight = 48f

        fun drawMetricCard(
            x: Float,
            y: Float,
            title: String,
            amountStr: String,
            subtitle: String,
            titleColor: String,
            amountColor: String,
            bgColor: String = "#F8FAFC",
            borderColor: String = "#E2E8F0"
        ) {
            val cardRect = RectF(x, y, x + cardWidth, y + cardHeight)
            paint.color = Color.parseColor(bgColor)
            paint.style = Paint.Style.FILL
            canvas.drawRoundRect(cardRect, 6f, 6f, paint)

            paint.color = Color.parseColor(borderColor)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1f
            canvas.drawRoundRect(cardRect, 6f, 6f, paint)

            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textPaint.textSize = 8f
            textPaint.color = Color.parseColor(titleColor)
            canvas.drawText(title, x + 10f, y + 14f, textPaint)

            textPaint.textSize = 13f
            textPaint.color = Color.parseColor(amountColor)
            canvas.drawText(amountStr, x + 10f, y + 31f, textPaint)

            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textPaint.textSize = 7.5f
            textPaint.color = Color.parseColor("#64748B")
            canvas.drawText(subtitle, x + 10f, y + 43f, textPaint)
        }

        // Row 1: TOTAL INCOME & TOTAL EXPENSES
        drawMetricCard(
            x = MARGIN_LEFT,
            y = curY,
            title = "TOTAL INCOME (MONEY RECEIVED)",
            amountStr = PricingCalculator.formatCurrency(totalIncome),
            subtitle = "$billsCount Bills • Actual Payments Received",
            titleColor = "#059669",
            amountColor = "#059669",
            bgColor = "#F0FDF4",
            borderColor = "#BBF7D0"
        )

        drawMetricCard(
            x = MARGIN_LEFT + cardWidth + 12f,
            y = curY,
            title = "TOTAL EXPENSES",
            amountStr = PricingCalculator.formatCurrency(totalExpenses),
            subtitle = "${expenses.size} Recorded Expenses",
            titleColor = "#D97706",
            amountColor = "#D97706",
            bgColor = "#FFFBEB",
            borderColor = "#FDE68A"
        )

        curY += cardHeight + 8f

        // Row 2: NET INCOME & OUTSTANDING
        val isNetPositive = netIncome >= 0
        val netColor = if (isNetPositive) "#059669" else "#DC2626"
        val netBg = if (isNetPositive) "#F0FDF4" else "#FEF2F2"
        val netBorder = if (isNetPositive) "#BBF7D0" else "#FECACA"

        drawMetricCard(
            x = MARGIN_LEFT,
            y = curY,
            title = "NET INCOME (INCOME - EXPENSES)",
            amountStr = PricingCalculator.formatCurrency(netIncome),
            subtitle = "Actual Received - Recorded Expenses",
            titleColor = netColor,
            amountColor = netColor,
            bgColor = netBg,
            borderColor = netBorder
        )

        drawMetricCard(
            x = MARGIN_LEFT + cardWidth + 12f,
            y = curY,
            title = "OUTSTANDING BALANCE (DUE)",
            amountStr = PricingCalculator.formatCurrency(outstandingBalance),
            subtitle = "Excluded from Income (Not yet paid)",
            titleColor = "#E11D48",
            amountColor = "#E11D48",
            bgColor = "#FFF1F2",
            borderColor = "#FECDD3"
        )

        curY += cardHeight + 14f

        // 3. Income Details Section Table
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 9.5f
        textPaint.color = Color.parseColor("#0F172A")
        canvas.drawText("INCOME BREAKDOWN (${bills.size} Bills)", MARGIN_LEFT, curY, textPaint)

        curY += 6f
        val tableHeaderH = 18f
        val incHeaderRect = RectF(MARGIN_LEFT, curY, MARGIN_RIGHT, curY + tableHeaderH)
        paint.color = Color.parseColor("#0F172A")
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(incHeaderRect, 3f, 3f, paint)

        textPaint.color = Color.WHITE
        textPaint.textSize = 7.5f
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("BILL NO", MARGIN_LEFT + 8f, curY + 12f, textPaint)
        canvas.drawText("CUSTOMER", MARGIN_LEFT + 95f, curY + 12f, textPaint)
        canvas.drawText("ROOM", MARGIN_LEFT + 220f, curY + 12f, textPaint)
        canvas.drawText("DATE", MARGIN_LEFT + 285f, curY + 12f, textPaint)
        canvas.drawText("METHOD", MARGIN_LEFT + 365f, curY + 12f, textPaint)
        textPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText("PAID AMOUNT", MARGIN_RIGHT - 8f, curY + 12f, textPaint)
        textPaint.textAlign = Paint.Align.LEFT

        curY += tableHeaderH + 2f

        if (bills.isEmpty()) {
            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textPaint.textSize = 8f
            textPaint.color = Color.parseColor("#64748B")
            canvas.drawText("No bills or payments recorded in this period.", MARGIN_LEFT + 8f, curY + 12f, textPaint)
            curY += 18f
        } else {
            val maxBillsToShow = 10.coerceAtMost(bills.size)
            for (i in 0 until maxBillsToShow) {
                val b = bills[i]
                paint.color = Color.parseColor("#F1F5F9")
                paint.strokeWidth = 0.5f
                paint.style = Paint.Style.STROKE
                canvas.drawLine(MARGIN_LEFT, curY + 14f, MARGIN_RIGHT, curY + 14f, paint)

                textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textPaint.textSize = 8f
                textPaint.color = Color.parseColor("#0284C7")
                canvas.drawText(b.billNumber, MARGIN_LEFT + 8f, curY + 11f, textPaint)

                textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                textPaint.color = Color.parseColor("#0F172A")
                val cleanName = if (b.customerName.length > 20) b.customerName.take(18) + "…" else b.customerName
                canvas.drawText(cleanName, MARGIN_LEFT + 95f, curY + 11f, textPaint)
                canvas.drawText("Room ${b.roomNumber}", MARGIN_LEFT + 220f, curY + 11f, textPaint)
                canvas.drawText(b.checkInDate, MARGIN_LEFT + 285f, curY + 11f, textPaint)
                canvas.drawText(b.paymentMethod.displayName, MARGIN_LEFT + 365f, curY + 11f, textPaint)

                textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textPaint.color = Color.parseColor("#059669")
                textPaint.textAlign = Paint.Align.RIGHT
                canvas.drawText(PricingCalculator.formatCurrency(b.paid), MARGIN_RIGHT - 8f, curY + 11f, textPaint)
                textPaint.textAlign = Paint.Align.LEFT

                curY += 15f
            }
            if (bills.size > maxBillsToShow) {
                textPaint.textSize = 7.5f
                textPaint.color = Color.parseColor("#64748B")
                canvas.drawText("+ ${bills.size - maxBillsToShow} additional bills included in total sum.", MARGIN_LEFT + 8f, curY + 10f, textPaint)
                curY += 14f
            }
        }

        curY += 8f

        // 4. Expense Details Section Table
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.textSize = 9.5f
        textPaint.color = Color.parseColor("#0F172A")
        canvas.drawText("EXPENSE BREAKDOWN (${expenses.size} Expenses)", MARGIN_LEFT, curY, textPaint)

        curY += 6f
        val expHeaderRect = RectF(MARGIN_LEFT, curY, MARGIN_RIGHT, curY + tableHeaderH)
        paint.color = Color.parseColor("#334155")
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(expHeaderRect, 3f, 3f, paint)

        textPaint.color = Color.WHITE
        textPaint.textSize = 7.5f
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("DATE", MARGIN_LEFT + 8f, curY + 12f, textPaint)
        canvas.drawText("CATEGORY", MARGIN_LEFT + 90f, curY + 12f, textPaint)
        canvas.drawText("DESCRIPTION", MARGIN_LEFT + 195f, curY + 12f, textPaint)
        textPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText("AMOUNT", MARGIN_RIGHT - 8f, curY + 12f, textPaint)
        textPaint.textAlign = Paint.Align.LEFT

        curY += tableHeaderH + 2f

        if (expenses.isEmpty()) {
            textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textPaint.textSize = 8f
            textPaint.color = Color.parseColor("#64748B")
            canvas.drawText("No expenses recorded in this period.", MARGIN_LEFT + 8f, curY + 12f, textPaint)
            curY += 18f
        } else {
            val maxExpToShow = 12.coerceAtMost(expenses.size)
            for (i in 0 until maxExpToShow) {
                val e = expenses[i]
                paint.color = Color.parseColor("#F1F5F9")
                paint.strokeWidth = 0.5f
                paint.style = Paint.Style.STROKE
                canvas.drawLine(MARGIN_LEFT, curY + 14f, MARGIN_RIGHT, curY + 14f, paint)

                textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                textPaint.textSize = 8f
                textPaint.color = Color.parseColor("#475569")
                canvas.drawText(e.date, MARGIN_LEFT + 8f, curY + 11f, textPaint)

                textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textPaint.color = Color.parseColor("#0F172A")
                canvas.drawText(e.category, MARGIN_LEFT + 90f, curY + 11f, textPaint)

                textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                val cleanDesc = if (e.description.length > 34) e.description.take(32) + "…" else e.description
                canvas.drawText(cleanDesc, MARGIN_LEFT + 195f, curY + 11f, textPaint)

                textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textPaint.color = Color.parseColor("#D97706")
                textPaint.textAlign = Paint.Align.RIGHT
                canvas.drawText(PricingCalculator.formatCurrency(e.amount), MARGIN_RIGHT - 8f, curY + 11f, textPaint)
                textPaint.textAlign = Paint.Align.LEFT

                curY += 15f
            }
            if (expenses.size > maxExpToShow) {
                textPaint.textSize = 7.5f
                textPaint.color = Color.parseColor("#64748B")
                canvas.drawText("+ ${expenses.size - maxExpToShow} additional expenses included in total sum.", MARGIN_LEFT + 8f, curY + 10f, textPaint)
                curY += 14f
            }
        }

        // 5. Footer
        val footerY = PAGE_HEIGHT - 45f
        paint.color = Color.parseColor("#CBD5E1")
        paint.strokeWidth = 1f
        paint.style = Paint.Style.STROKE
        canvas.drawLine(MARGIN_LEFT, footerY, MARGIN_RIGHT, footerY, paint)

        val timestampStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        textPaint.textSize = 8f
        textPaint.color = Color.parseColor("#64748B")
        canvas.drawText("Generated on $timestampStr • Official Guest House Cashier System", PAGE_WIDTH / 2f, footerY + 14f, textPaint)

        textPaint.textSize = 7.5f
        textPaint.color = Color.parseColor("#94A3B8")
        canvas.drawText("Note: Income represents actual received cash/card payments. Unpaid balances are kept separate.", PAGE_WIDTH / 2f, footerY + 26f, textPaint)

        pdfDocument.finishPage(page)

        FileOutputStream(file).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        return file
    }

    /**
     * Native Android share sheet launcher for the Report PDF file.
     * Works with WhatsApp, Gmail, Messenger, Bluetooth, Nearby/Quick Share, Drive, etc.
     */
    fun shareReportPdf(
        context: Context,
        periodTitle: String,
        fromDate: String,
        toDate: String,
        totalIncome: Double,
        totalExpenses: Double,
        netIncome: Double,
        outstandingBalance: Double,
        billsCount: Int,
        bills: List<BillEntity>,
        expenses: List<ExpenseEntity>
    ) {
        val file = generateReportPdf(
            context = context,
            periodTitle = periodTitle,
            fromDate = fromDate,
            toDate = toDate,
            totalIncome = totalIncome,
            totalExpenses = totalExpenses,
            netIncome = netIncome,
            outstandingBalance = outstandingBalance,
            billsCount = billsCount,
            bills = bills,
            expenses = expenses
        )

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Guest House Financial Report - $periodTitle")
            putExtra(
                Intent.EXTRA_TEXT,
                "Guest House Financial Report ($periodTitle: $fromDate to $toDate)\n" +
                        "Total Income: ${PricingCalculator.formatCurrency(totalIncome)}\n" +
                        "Total Expenses: ${PricingCalculator.formatCurrency(totalExpenses)}\n" +
                        "Net Income: ${PricingCalculator.formatCurrency(netIncome)}\n" +
                        "Outstanding Balance: ${PricingCalculator.formatCurrency(outstandingBalance)}"
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        val chooser = Intent.createChooser(sendIntent, "Share Financial Report").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    /**
     * Saves a copy of the Report PDF to the device's Downloads folder and returns user feedback string.
     */
    fun saveReportPdfToStorage(
        context: Context,
        periodTitle: String,
        fromDate: String,
        toDate: String,
        totalIncome: Double,
        totalExpenses: Double,
        netIncome: Double,
        outstandingBalance: Double,
        billsCount: Int,
        bills: List<BillEntity>,
        expenses: List<ExpenseEntity>
    ): String {
        val srcFile = generateReportPdf(
            context = context,
            periodTitle = periodTitle,
            fromDate = fromDate,
            toDate = toDate,
            totalIncome = totalIncome,
            totalExpenses = totalExpenses,
            netIncome = netIncome,
            outstandingBalance = outstandingBalance,
            billsCount = billsCount,
            bills = bills,
            expenses = expenses
        )
        val fileName = getReportFileName(periodTitle, fromDate, toDate)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/GuestHouse")
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(srcFile).use { input ->
                            input.copyTo(out)
                        }
                    }
                    return "Report PDF saved to Downloads: $fileName"
                }
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val targetDir = File(downloadsDir, "GuestHouse")
                if (!targetDir.exists()) targetDir.mkdirs()
                val destFile = File(targetDir, fileName)
                FileInputStream(srcFile).use { input ->
                    FileOutputStream(destFile).use { output ->
                        input.copyTo(output)
                    }
                }
                return "Report PDF saved to Downloads: $fileName"
            }
        } catch (_: Exception) {}
        return "Report PDF generated: $fileName"
    }
}
