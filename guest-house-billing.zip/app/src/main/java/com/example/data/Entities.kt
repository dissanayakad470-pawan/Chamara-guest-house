package com.example.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class RoomType(val displayName: String, val badgeText: String) {
    NON_AC("Non-AC", "Non-AC"),
    AC("Air Conditioned", "AC"),
    AC_FAMILY("AC Family", "Family")
}

enum class RoomStatus {
    AVAILABLE,
    OCCUPIED
}

enum class StayType(val displayName: String) {
    NIGHT("Night"),
    FULL_DAY("Full Day")
}

enum class PaymentMethod(val displayName: String) {
    CASH("Cash"),
    CARD("Card"),
    OTHER("Other")
}

enum class BillStatus {
    ACTIVE,
    PAID
}

@Entity(tableName = "rooms")
data class RoomEntity(
    @PrimaryKey val roomNumber: String,
    val roomType: RoomType,
    val status: RoomStatus = RoomStatus.AVAILABLE,
    val currentBillId: Long? = null,
    val category: String = "Standard",
    val maxGuests: Int = 5,
    val description: String = "",
    val amenities: String = "WiFi, TV, Attached Bathroom",
    val isActive: Boolean = true,
    // Custom Pricing for AC & Non-AC (1 to 5 persons):
    val nightPrice1: Double = 3000.0,
    val nightPrice2: Double = 3500.0,
    val nightPrice3: Double = 4000.0,
    val nightPrice4: Double = 4500.0,
    val nightPrice5: Double = 5000.0,
    val fullDayPrice1: Double = 4500.0,
    val fullDayPrice2: Double = 5500.0,
    val fullDayPrice3: Double = 6000.0,
    val fullDayPrice4: Double = 6500.0,
    val fullDayPrice5: Double = 7500.0,
    // AC Family room fixed pricing:
    val familyNightPrice: Double = 5000.0,
    val familyFullDayPrice: Double = 7500.0
) {
    fun getPrice(guests: Int, stayType: StayType): Double {
        if (roomType == RoomType.AC_FAMILY) {
            return when (stayType) {
                StayType.NIGHT -> familyNightPrice
                StayType.FULL_DAY -> familyFullDayPrice
            }
        }
        val g = guests.coerceIn(1, 5)
        return when (stayType) {
            StayType.NIGHT -> when (g) {
                1 -> nightPrice1
                2 -> nightPrice2
                3 -> nightPrice3
                4 -> nightPrice4
                else -> nightPrice5
            }
            StayType.FULL_DAY -> when (g) {
                1 -> fullDayPrice1
                2 -> fullDayPrice2
                3 -> fullDayPrice3
                4 -> fullDayPrice4
                else -> fullDayPrice5
            }
        }
    }
}

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val nic: String,
    val phone: String,
    val photoPath: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "bills",
    foreignKeys = [
        ForeignKey(
            entity = CustomerEntity::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index(value = ["billNumber"], unique = true), Index(value = ["customerId"])]
)
data class BillEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val billNumber: String,
    val customerId: Long? = null,
    val customerName: String,
    val customerNic: String,
    val customerPhone: String,
    val customerPhotoPath: String? = null,
    val roomNumber: String,
    val roomType: RoomType,
    val guestsCount: Int,
    val stayType: StayType,
    val checkInDate: String,
    val checkInTime: String = "5:00 PM",
    val checkOutDate: String,
    val checkOutTime: String = "8:30 AM",
    val roomCharge: Double,
    val extraChargesTotal: Double = 0.0,
    val discount: Double = 0.0,
    val total: Double,
    val paid: Double,
    val balance: Double,
    val paymentMethod: PaymentMethod = PaymentMethod.CASH,
    val status: BillStatus = BillStatus.ACTIVE,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "bill_items",
    foreignKeys = [
        ForeignKey(
            entity = BillEntity::class,
            parentColumns = ["id"],
            childColumns = ["billId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["billId"])]
)
data class BillItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val billId: Long,
    val category: String, // Food, Drinks, Extra Bed, Other
    val description: String,
    val amount: Double
)

object ExpenseCategories {
    val DEFAULT = listOf(
        "Electricity",
        "Water",
        "Cleaning",
        "Food Supplies",
        "Maintenance",
        "Staff",
        "Transport",
        "Other"
    )
}

@Entity(
    tableName = "expenses",
    indices = [Index(value = ["date"]), Index(value = ["category"])]
)
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,
    val description: String,
    val amount: Double,
    val date: String, // "yyyy-MM-dd"
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

