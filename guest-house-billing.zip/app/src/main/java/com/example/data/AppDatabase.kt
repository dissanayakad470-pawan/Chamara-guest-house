package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        RoomEntity::class,
        CustomerEntity::class,
        BillEntity::class,
        BillItemEntity::class,
        ExpenseEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun roomDao(): RoomDao
    abstract fun customerDao(): CustomerDao
    abstract fun billDao(): BillDao
    abstract fun billItemDao(): BillItemDao
    abstract fun expenseDao(): ExpenseDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val DEFAULT_ROOMS = listOf(
            // Non-AC rooms: 01, 04, 05, 10, 11
            RoomEntity(
                roomNumber = "01",
                roomType = RoomType.NON_AC,
                category = "Standard Non-AC",
                maxGuests = 5,
                description = "Standard ventilated room with attached bath.",
                amenities = "Ceiling Fan, Free WiFi, Attached Bathroom",
                nightPrice1 = 2500.0, nightPrice2 = 3000.0, nightPrice3 = 3500.0, nightPrice4 = 4000.0, nightPrice5 = 4500.0,
                fullDayPrice1 = 4000.0, fullDayPrice2 = 4500.0, fullDayPrice3 = 5000.0, fullDayPrice4 = 5500.0, fullDayPrice5 = 6000.0
            ),
            // AC rooms: 02, 03, 06, 07, 08, 14
            RoomEntity(
                roomNumber = "02",
                roomType = RoomType.AC,
                category = "Deluxe AC",
                maxGuests = 5,
                description = "Deluxe air-conditioned room with premium bedding.",
                amenities = "Air Conditioning, Free WiFi, Hot Water, TV, Attached Bathroom",
                nightPrice1 = 3000.0, nightPrice2 = 3500.0, nightPrice3 = 4000.0, nightPrice4 = 4500.0, nightPrice5 = 5000.0,
                fullDayPrice1 = 4500.0, fullDayPrice2 = 5500.0, fullDayPrice3 = 6000.0, fullDayPrice4 = 6500.0, fullDayPrice5 = 7500.0
            ),
            RoomEntity(
                roomNumber = "03",
                roomType = RoomType.AC,
                category = "Deluxe AC",
                maxGuests = 5,
                description = "Quiet AC room overlooking the garden.",
                amenities = "Air Conditioning, Free WiFi, Hot Water, TV, Attached Bathroom",
                nightPrice1 = 3000.0, nightPrice2 = 3500.0, nightPrice3 = 4000.0, nightPrice4 = 4500.0, nightPrice5 = 5000.0,
                fullDayPrice1 = 4500.0, fullDayPrice2 = 5500.0, fullDayPrice3 = 6000.0, fullDayPrice4 = 6500.0, fullDayPrice5 = 7500.0
            ),
            RoomEntity(
                roomNumber = "04",
                roomType = RoomType.NON_AC,
                category = "Standard Non-AC",
                maxGuests = 5,
                description = "Spacious non-AC budget room with good airflow.",
                amenities = "Ceiling Fan, Free WiFi, Attached Bathroom",
                nightPrice1 = 2500.0, nightPrice2 = 3000.0, nightPrice3 = 3500.0, nightPrice4 = 4000.0, nightPrice5 = 4500.0,
                fullDayPrice1 = 4000.0, fullDayPrice2 = 4500.0, fullDayPrice3 = 5000.0, fullDayPrice4 = 5500.0, fullDayPrice5 = 6000.0
            ),
            RoomEntity(
                roomNumber = "05",
                roomType = RoomType.NON_AC,
                category = "Standard Non-AC",
                maxGuests = 5,
                description = "Economical non-AC room with double windows.",
                amenities = "Ceiling Fan, Free WiFi, Attached Bathroom",
                nightPrice1 = 2500.0, nightPrice2 = 3000.0, nightPrice3 = 3500.0, nightPrice4 = 4000.0, nightPrice5 = 4500.0,
                fullDayPrice1 = 4000.0, fullDayPrice2 = 4500.0, fullDayPrice3 = 5000.0, fullDayPrice4 = 5500.0, fullDayPrice5 = 6000.0
            ),
            RoomEntity(
                roomNumber = "06",
                roomType = RoomType.AC,
                category = "Deluxe AC",
                maxGuests = 5,
                description = "Modern air-conditioned room with desk and wardrobe.",
                amenities = "Air Conditioning, Free WiFi, Hot Water, TV, Attached Bathroom",
                nightPrice1 = 3000.0, nightPrice2 = 3500.0, nightPrice3 = 4000.0, nightPrice4 = 4500.0, nightPrice5 = 5000.0,
                fullDayPrice1 = 4500.0, fullDayPrice2 = 5500.0, fullDayPrice3 = 6000.0, fullDayPrice4 = 6500.0, fullDayPrice5 = 7500.0
            ),
            RoomEntity(
                roomNumber = "07",
                roomType = RoomType.AC,
                category = "Deluxe AC",
                maxGuests = 5,
                description = "First-floor comfortable AC room.",
                amenities = "Air Conditioning, Free WiFi, Hot Water, TV, Attached Bathroom",
                nightPrice1 = 3000.0, nightPrice2 = 3500.0, nightPrice3 = 4000.0, nightPrice4 = 4500.0, nightPrice5 = 5000.0,
                fullDayPrice1 = 4500.0, fullDayPrice2 = 5500.0, fullDayPrice3 = 6000.0, fullDayPrice4 = 6500.0, fullDayPrice5 = 7500.0
            ),
            RoomEntity(
                roomNumber = "08",
                roomType = RoomType.AC,
                category = "Deluxe AC",
                maxGuests = 5,
                description = "Cozy and quiet AC room with ambient lighting.",
                amenities = "Air Conditioning, Free WiFi, Hot Water, TV, Attached Bathroom",
                nightPrice1 = 3000.0, nightPrice2 = 3500.0, nightPrice3 = 4000.0, nightPrice4 = 4500.0, nightPrice5 = 5000.0,
                fullDayPrice1 = 4500.0, fullDayPrice2 = 5500.0, fullDayPrice3 = 6000.0, fullDayPrice4 = 6500.0, fullDayPrice5 = 7500.0
            ),
            // AC Family rooms: 09, 13
            RoomEntity(
                roomNumber = "09",
                roomType = RoomType.AC_FAMILY,
                category = "Family Suite AC",
                maxGuests = 8,
                description = "Large family suite with multiple beds, AC and seating area.",
                amenities = "Air Conditioning, Free WiFi, Hot Water, Smart TV, Sofa, Attached Bathroom",
                familyNightPrice = 5000.0,
                familyFullDayPrice = 7500.0
            ),
            RoomEntity(
                roomNumber = "10",
                roomType = RoomType.NON_AC,
                category = "Standard Non-AC",
                maxGuests = 5,
                description = "Budget non-AC room with good ventilation.",
                amenities = "Ceiling Fan, Free WiFi, Attached Bathroom",
                nightPrice1 = 2500.0, nightPrice2 = 3000.0, nightPrice3 = 3500.0, nightPrice4 = 4000.0, nightPrice5 = 4500.0,
                fullDayPrice1 = 4000.0, fullDayPrice2 = 4500.0, fullDayPrice3 = 5000.0, fullDayPrice4 = 5500.0, fullDayPrice5 = 6000.0
            ),
            RoomEntity(
                roomNumber = "11",
                roomType = RoomType.NON_AC,
                category = "Standard Non-AC",
                maxGuests = 5,
                description = "Corner non-AC room with ample daylight.",
                amenities = "Ceiling Fan, Free WiFi, Attached Bathroom",
                nightPrice1 = 2500.0, nightPrice2 = 3000.0, nightPrice3 = 3500.0, nightPrice4 = 4000.0, nightPrice5 = 4500.0,
                fullDayPrice1 = 4000.0, fullDayPrice2 = 4500.0, fullDayPrice3 = 5000.0, fullDayPrice4 = 5500.0, fullDayPrice5 = 6000.0
            ),
            RoomEntity(
                roomNumber = "13",
                roomType = RoomType.AC_FAMILY,
                category = "Family Suite AC",
                maxGuests = 8,
                description = "Spacious ground floor family suite with direct access.",
                amenities = "Air Conditioning, Free WiFi, Hot Water, Smart TV, Attached Bathroom",
                familyNightPrice = 5000.0,
                familyFullDayPrice = 7500.0
            ),
            RoomEntity(
                roomNumber = "14",
                roomType = RoomType.AC,
                category = "Deluxe AC",
                maxGuests = 5,
                description = "Premium upper-level AC room with private balcony view.",
                amenities = "Air Conditioning, Free WiFi, Hot Water, TV, Attached Bathroom",
                nightPrice1 = 3000.0, nightPrice2 = 3500.0, nightPrice3 = 4000.0, nightPrice4 = 4500.0, nightPrice5 = 5000.0,
                fullDayPrice1 = 4500.0, fullDayPrice2 = 5500.0, fullDayPrice3 = 6000.0, fullDayPrice4 = 6500.0, fullDayPrice5 = 7500.0
            )
        )

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "guest_house_billing.db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Seed default 13 rooms in background
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.roomDao()?.insertRooms(DEFAULT_ROOMS)
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
