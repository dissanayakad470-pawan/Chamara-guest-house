package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface RoomDao {
    @Query("SELECT * FROM rooms ORDER BY roomNumber ASC")
    fun getAllRoomsFlow(): Flow<List<RoomEntity>>

    @Query("SELECT * FROM rooms ORDER BY roomNumber ASC")
    suspend fun getAllRooms(): List<RoomEntity>

    @Query("SELECT * FROM rooms WHERE roomNumber = :roomNumber LIMIT 1")
    suspend fun getRoomByNumber(roomNumber: String): RoomEntity?

    @Query("SELECT * FROM rooms WHERE roomNumber = :roomNumber LIMIT 1")
    fun getRoomFlow(roomNumber: String): Flow<RoomEntity?>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertRooms(rooms: List<RoomEntity>)

    @Update
    suspend fun updateRoom(room: RoomEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateRoom(room: RoomEntity)

    @Query("DELETE FROM rooms WHERE roomNumber = :roomNumber")
    suspend fun deleteRoom(roomNumber: String)

    @Query("UPDATE rooms SET status = :status, currentBillId = :currentBillId WHERE roomNumber = :roomNumber")
    suspend fun updateRoomStatus(roomNumber: String, status: RoomStatus, currentBillId: Long?)
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers ORDER BY createdAt DESC")
    fun getAllCustomers(): Flow<List<CustomerEntity>>

    @Query("""
        SELECT * FROM customers 
        WHERE name LIKE '%' || :query || '%' 
           OR nic LIKE '%' || :query || '%' 
           OR phone LIKE '%' || :query || '%'
        ORDER BY createdAt DESC
    """)
    fun searchCustomers(query: String): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
    suspend fun getCustomerById(id: Long): CustomerEntity?

    @Query("SELECT * FROM customers WHERE LOWER(nic) = LOWER(:nic) LIMIT 1")
    suspend fun getCustomerByNic(nic: String): CustomerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: CustomerEntity): Long

    @Update
    suspend fun updateCustomer(customer: CustomerEntity)
}

@Dao
interface BillDao {
    @Query("SELECT * FROM bills ORDER BY createdAt DESC")
    fun getAllBills(): Flow<List<BillEntity>>

    @Query("""
        SELECT * FROM bills 
        WHERE billNumber LIKE '%' || :query || '%' 
           OR customerName LIKE '%' || :query || '%' 
           OR customerNic LIKE '%' || :query || '%' 
           OR roomNumber LIKE '%' || :query || '%'
        ORDER BY createdAt DESC
    """)
    fun searchBills(query: String): Flow<List<BillEntity>>

    @Query("SELECT * FROM bills WHERE id = :id LIMIT 1")
    suspend fun getBillById(id: Long): BillEntity?

    @Query("SELECT * FROM bills WHERE id = :id LIMIT 1")
    fun getBillByIdFlow(id: Long): Flow<BillEntity?>

    @Query("SELECT * FROM bills WHERE customerId = :customerId ORDER BY createdAt DESC")
    fun getBillsForCustomer(customerId: Long): Flow<List<BillEntity>>

    @Query("SELECT * FROM bills WHERE LOWER(customerNic) = LOWER(:nic) ORDER BY createdAt DESC")
    fun getBillsForCustomerByNic(nic: String): Flow<List<BillEntity>>

    @Query("SELECT * FROM bills WHERE roomNumber = :roomNumber AND status = 'ACTIVE' ORDER BY createdAt DESC LIMIT 1")
    suspend fun getActiveBillForRoom(roomNumber: String): BillEntity?

    @Query("SELECT * FROM bills WHERE roomNumber = :roomNumber AND status = 'ACTIVE' ORDER BY createdAt DESC LIMIT 1")
    fun getActiveBillForRoomFlow(roomNumber: String): Flow<BillEntity?>

    @Query("SELECT billNumber FROM bills ORDER BY id DESC LIMIT 1")
    suspend fun getLastBillNumber(): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBill(bill: BillEntity): Long

    @Update
    suspend fun updateBill(bill: BillEntity)
}

@Dao
interface BillItemDao {
    @Query("SELECT * FROM bill_items WHERE billId = :billId")
    fun getItemsForBill(billId: Long): Flow<List<BillItemEntity>>

    @Query("SELECT * FROM bill_items WHERE billId = :billId")
    suspend fun getItemsForBillSync(billId: Long): List<BillItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<BillItemEntity>)

    @Query("DELETE FROM bill_items WHERE billId = :billId")
    suspend fun deleteItemsForBill(billId: Long)
}

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expenses ORDER BY date DESC, createdAt DESC")
    fun getAllExpensesFlow(): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses ORDER BY date DESC, createdAt DESC")
    suspend fun getAllExpenses(): List<ExpenseEntity>

    @Query("SELECT * FROM expenses WHERE id = :id LIMIT 1")
    suspend fun getExpenseById(id: Long): ExpenseEntity?

    @Query("SELECT * FROM expenses WHERE date >= :fromDate AND date <= :toDate ORDER BY date DESC, createdAt DESC")
    fun getExpensesBetweenDatesFlow(fromDate: String, toDate: String): Flow<List<ExpenseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity): Long

    @Update
    suspend fun updateExpense(expense: ExpenseEntity)

    @Delete
    suspend fun deleteExpense(expense: ExpenseEntity)

    @Query("DELETE FROM expenses WHERE id = :id")
    suspend fun deleteExpenseById(id: Long)
}
