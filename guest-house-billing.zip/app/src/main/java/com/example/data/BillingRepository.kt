package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BillingRepository(private val database: AppDatabase) {

    private val roomDao = database.roomDao()
    private val customerDao = database.customerDao()
    private val billDao = database.billDao()
    private val billItemDao = database.billItemDao()
    private val expenseDao = database.expenseDao()

    val allRoomsFlow: Flow<List<RoomEntity>> = roomDao.getAllRoomsFlow()
    val allBillsFlow: Flow<List<BillEntity>> = billDao.getAllBills()
    val allCustomersFlow: Flow<List<CustomerEntity>> = customerDao.getAllCustomers()
    val allExpensesFlow: Flow<List<ExpenseEntity>> = expenseDao.getAllExpensesFlow()

    suspend fun initDefaultRoomsIfNeeded() = withContext(Dispatchers.IO) {
        val existing = roomDao.getAllRooms()
        if (existing.isEmpty()) {
            roomDao.insertRooms(AppDatabase.DEFAULT_ROOMS)
        } else {
            val defaultMap = AppDatabase.DEFAULT_ROOMS.associateBy { it.roomNumber }
            for (r in existing) {
                val def = defaultMap[r.roomNumber]
                if (def != null && (r.nightPrice1 == 0.0 && r.familyNightPrice == 0.0)) {
                    val updated = r.copy(
                        category = def.category,
                        maxGuests = def.maxGuests,
                        description = def.description,
                        amenities = def.amenities,
                        nightPrice1 = def.nightPrice1,
                        nightPrice2 = def.nightPrice2,
                        nightPrice3 = def.nightPrice3,
                        nightPrice4 = def.nightPrice4,
                        nightPrice5 = def.nightPrice5,
                        fullDayPrice1 = def.fullDayPrice1,
                        fullDayPrice2 = def.fullDayPrice2,
                        fullDayPrice3 = def.fullDayPrice3,
                        fullDayPrice4 = def.fullDayPrice4,
                        fullDayPrice5 = def.fullDayPrice5,
                        familyNightPrice = def.familyNightPrice,
                        familyFullDayPrice = def.familyFullDayPrice
                    )
                    roomDao.updateRoom(updated)
                }
            }
        }
    }

    suspend fun getRoomByNumber(roomNumber: String): RoomEntity? = withContext(Dispatchers.IO) {
        roomDao.getRoomByNumber(roomNumber)
    }

    suspend fun updateRoom(room: RoomEntity) = withContext(Dispatchers.IO) {
        roomDao.updateRoom(room)
    }

    suspend fun updateRoomWithRename(oldRoomNumber: String, updatedRoom: RoomEntity) = withContext(Dispatchers.IO) {
        if (oldRoomNumber != updatedRoom.roomNumber) {
            roomDao.deleteRoom(oldRoomNumber)
        }
        roomDao.insertOrUpdateRoom(updatedRoom)
    }

    fun getRoomFlow(roomNumber: String): Flow<RoomEntity?> = roomDao.getRoomFlow(roomNumber)

    fun getBillByIdFlow(id: Long): Flow<BillEntity?> = billDao.getBillByIdFlow(id)

    fun getItemsForBill(billId: Long): Flow<List<BillItemEntity>> = billItemDao.getItemsForBill(billId)

    suspend fun getItemsForBillSync(billId: Long): List<BillItemEntity> = withContext(Dispatchers.IO) {
        billItemDao.getItemsForBillSync(billId)
    }

    suspend fun getActiveBillForRoom(roomNumber: String): BillEntity? = withContext(Dispatchers.IO) {
        billDao.getActiveBillForRoom(roomNumber)
    }

    fun searchBills(query: String): Flow<List<BillEntity>> = billDao.searchBills(query)

    fun searchCustomers(query: String): Flow<List<CustomerEntity>> = customerDao.searchCustomers(query)

    fun getBillsForCustomer(customerId: Long): Flow<List<BillEntity>> = billDao.getBillsForCustomer(customerId)

    fun getBillsForCustomerByNic(nic: String): Flow<List<BillEntity>> = billDao.getBillsForCustomerByNic(nic)

    suspend fun generateNextBillNumber(): String = withContext(Dispatchers.IO) {
        val datePrefix = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
        val lastBill = billDao.getLastBillNumber()
        val nextSeq = if (lastBill != null && lastBill.startsWith("GH-$datePrefix-")) {
            val suffix = lastBill.substringAfterLast("-").toIntOrNull() ?: 0
            suffix + 1
        } else {
            1
        }
        "GH-$datePrefix-%03d".format(nextSeq)
    }

    suspend fun createAndSaveBill(
        customerName: String,
        customerNic: String,
        customerPhone: String,
        customerPhotoPath: String?,
        roomNumber: String,
        roomType: RoomType,
        guestsCount: Int,
        stayType: StayType,
        checkInDate: String,
        checkInTime: String,
        checkOutDate: String,
        checkOutTime: String,
        roomCharge: Double,
        extraItems: List<Pair<String, Pair<String, Double>>>, // List of (Category, (Description, Amount))
        discount: Double,
        paid: Double,
        paymentMethod: PaymentMethod
    ): BillEntity = withContext(Dispatchers.IO) {
        // 1. Save or update customer
        val existingCustomer = customerDao.getCustomerByNic(customerNic.trim())
        val customerId = if (existingCustomer != null) {
            val updated = existingCustomer.copy(
                name = customerName.trim(),
                phone = customerPhone.trim().ifBlank { existingCustomer.phone },
                photoPath = customerPhotoPath ?: existingCustomer.photoPath
            )
            customerDao.updateCustomer(updated)
            existingCustomer.id
        } else {
            val newCustomer = CustomerEntity(
                name = customerName.trim(),
                nic = customerNic.trim(),
                phone = customerPhone.trim(),
                photoPath = customerPhotoPath
            )
            customerDao.insertCustomer(newCustomer)
        }

        // Calculate totals
        val extraChargesTotal = extraItems.sumOf { it.second.second }
        val total = (roomCharge + extraChargesTotal - discount).coerceAtLeast(0.0)
        val balance = (total - paid).coerceAtLeast(0.0)
        val billStatus = if (balance <= 0.0) BillStatus.PAID else BillStatus.ACTIVE

        val billNumber = generateNextBillNumber()

        // 2. Save the bill
        val bill = BillEntity(
            billNumber = billNumber,
            customerId = customerId,
            customerName = customerName.trim(),
            customerNic = customerNic.trim(),
            customerPhone = customerPhone.trim(),
            customerPhotoPath = customerPhotoPath,
            roomNumber = roomNumber,
            roomType = roomType,
            guestsCount = guestsCount,
            stayType = stayType,
            checkInDate = checkInDate,
            checkInTime = checkInTime,
            checkOutDate = checkOutDate,
            checkOutTime = checkOutTime,
            roomCharge = roomCharge,
            extraChargesTotal = extraChargesTotal,
            discount = discount,
            total = total,
            paid = paid,
            balance = balance,
            paymentMethod = paymentMethod,
            status = billStatus
        )
        val billId = billDao.insertBill(bill)

        // 3. Save extra charges as bill items
        if (extraItems.isNotEmpty()) {
            val items = extraItems.map { (category, descAmount) ->
                BillItemEntity(
                    billId = billId,
                    category = category,
                    description = descAmount.first,
                    amount = descAmount.second
                )
            }
            billItemDao.insertItems(items)
        }

        // 4. Mark selected room as OCCUPIED
        roomDao.updateRoomStatus(
            roomNumber = roomNumber,
            status = RoomStatus.OCCUPIED,
            currentBillId = billId
        )

        bill.copy(id = billId)
    }

    /**
     * Checkout room:
     * Applies final payment if any, marks bill as PAID, and marks room as AVAILABLE.
     */
    suspend fun checkoutRoom(
        roomNumber: String,
        billId: Long,
        additionalPayment: Double
    ) = withContext(Dispatchers.IO) {
        val bill = billDao.getBillById(billId)
        if (bill != null) {
            val newPaid = bill.paid + additionalPayment
            val newBalance = (bill.total - newPaid).coerceAtLeast(0.0)
            val updatedBill = bill.copy(
                paid = newPaid,
                balance = newBalance,
                status = if (newBalance <= 0.0) BillStatus.PAID else bill.status
            )
            billDao.updateBill(updatedBill)
        }

        // Mark room as AVAILABLE
        roomDao.updateRoomStatus(
            roomNumber = roomNumber,
            status = RoomStatus.AVAILABLE,
            currentBillId = null
        )
    }

    suspend fun updateBillPayment(billId: Long, additionalPayment: Double): BillEntity? = withContext(Dispatchers.IO) {
        val bill = billDao.getBillById(billId) ?: return@withContext null
        val newPaid = bill.paid + additionalPayment
        val newBalance = (bill.total - newPaid).coerceAtLeast(0.0)
        val updated = bill.copy(
            paid = newPaid,
            balance = newBalance,
            status = if (newBalance <= 0.0) BillStatus.PAID else bill.status
        )
        billDao.updateBill(updated)
        updated
    }

    suspend fun insertExpense(expense: ExpenseEntity): Long = withContext(Dispatchers.IO) {
        expenseDao.insertExpense(expense)
    }

    suspend fun updateExpense(expense: ExpenseEntity) = withContext(Dispatchers.IO) {
        expenseDao.updateExpense(expense)
    }

    suspend fun deleteExpense(expense: ExpenseEntity) = withContext(Dispatchers.IO) {
        expenseDao.deleteExpense(expense)
    }

    suspend fun deleteExpenseById(id: Long) = withContext(Dispatchers.IO) {
        expenseDao.deleteExpenseById(id)
    }
}
