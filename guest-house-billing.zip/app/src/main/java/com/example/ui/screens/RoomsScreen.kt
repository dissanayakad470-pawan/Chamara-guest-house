package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.RoomEntity
import com.example.data.RoomStatus
import com.example.data.RoomType
import com.example.ui.components.RoomStatusBadge
import com.example.ui.components.RoomTypeBadge
import com.example.ui.theme.AvailableGreen
import com.example.ui.theme.CashierPrimary
import com.example.ui.theme.OccupiedRed
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate50
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900

enum class RoomFilter {
    ALL,
    AVAILABLE,
    OCCUPIED
}

@Composable
fun RoomsScreen(
    rooms: List<RoomEntity>,
    onSelectAvailableRoom: (RoomEntity) -> Unit,
    onSelectOccupiedRoom: (RoomEntity) -> Unit,
    onSelectRoomDetails: (RoomEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf(RoomFilter.ALL) }

    val filteredRooms = remember(rooms, selectedFilter) {
        when (selectedFilter) {
            RoomFilter.ALL -> rooms
            RoomFilter.AVAILABLE -> rooms.filter { it.status == RoomStatus.AVAILABLE }
            RoomFilter.OCCUPIED -> rooms.filter { it.status == RoomStatus.OCCUPIED }
        }
    }

    val availableCount = rooms.count { it.status == RoomStatus.AVAILABLE }
    val occupiedCount = rooms.count { it.status == RoomStatus.OCCUPIED }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Slate50)
            .padding(16.dp)
    ) {
        // Top Header
        Text(
            text = "Rooms Management",
            fontSize = 22.sp,
            fontWeight = FontWeight.Black,
            color = Slate900
        )
        Text(
            text = "13 Total Rooms (AC, Non-AC, Family) • Tap to Edit Details & Pricing",
            fontSize = 13.sp,
            color = Slate500
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Filter Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedFilter == RoomFilter.ALL,
                onClick = { selectedFilter = RoomFilter.ALL },
                label = { Text("All (${rooms.size})") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = CashierPrimary,
                    selectedLabelColor = Color.White
                )
            )
            FilterChip(
                selected = selectedFilter == RoomFilter.AVAILABLE,
                onClick = { selectedFilter = RoomFilter.AVAILABLE },
                label = { Text("Available ($availableCount)") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = AvailableGreen,
                    selectedLabelColor = Color.White
                )
            )
            FilterChip(
                selected = selectedFilter == RoomFilter.OCCUPIED,
                onClick = { selectedFilter = RoomFilter.OCCUPIED },
                label = { Text("Occupied ($occupiedCount)") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = OccupiedRed,
                    selectedLabelColor = Color.White
                )
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Room List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredRooms, key = { it.roomNumber }) { room ->
                RoomDetailCard(
                    room = room,
                    onBookClick = { onSelectAvailableRoom(room) },
                    onCheckoutClick = { onSelectOccupiedRoom(room) },
                    onEditClick = { onSelectRoomDetails(room) }
                )
            }
        }
    }
}

@Composable
fun RoomDetailCard(
    room: RoomEntity,
    onBookClick: () -> Unit,
    onCheckoutClick: () -> Unit,
    onEditClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isAvailable = room.status == RoomStatus.AVAILABLE

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onEditClick() }
            .testTag("room_card_${room.roomNumber}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Slate200),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left: Room Number & Type & Status
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Room ${room.roomNumber}",
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            color = Slate900
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        RoomTypeBadge(roomType = room.roomType)
                        Spacer(modifier = Modifier.width(6.dp))
                        RoomStatusBadge(status = room.status)
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${room.category} • Max ${room.maxGuests} Guests",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Slate500
                    )
                }
            }

            // Current price range
            Text(
                text = when (room.roomType) {
                    RoomType.AC_FAMILY -> "Fixed Rate: Night Rs. ${room.familyNightPrice.toLong()} | Full Day Rs. ${room.familyFullDayPrice.toLong()}"
                    RoomType.AC -> "Night: Rs. ${room.nightPrice1.toLong()} - ${room.nightPrice5.toLong()} | Full: Rs. ${room.fullDayPrice1.toLong()} - ${room.fullDayPrice5.toLong()}"
                    RoomType.NON_AC -> "Night: Rs. ${room.nightPrice1.toLong()} - ${room.nightPrice5.toLong()} | Full: Rs. ${room.fullDayPrice1.toLong()} - ${room.fullDayPrice5.toLong()}"
                },
                fontSize = 12.sp,
                color = Slate700,
                fontWeight = FontWeight.SemiBold
            )

            // Buttons: Edit Room (always available) + Action button (Bill / Checkout)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onEditClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .testTag("edit_room_${room.roomNumber}"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Slate900)
                ) {
                    Text("Edit Room", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                if (isAvailable) {
                    Button(
                        onClick = onBookClick,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).height(40.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CashierPrimary)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Bill", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                } else {
                    Button(
                        onClick = onCheckoutClick,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).height(40.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = OccupiedRed)
                    ) {
                        Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Checkout", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
