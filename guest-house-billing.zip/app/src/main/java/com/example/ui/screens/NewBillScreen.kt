package com.example.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.BillEntity
import com.example.data.PaymentMethod
import com.example.data.RoomEntity
import com.example.data.RoomStatus
import com.example.data.RoomType
import com.example.data.StayType
import com.example.ui.BillingViewModel
import com.example.ui.NewBillUiState
import com.example.ui.components.RoomTypeBadge
import com.example.ui.theme.AvailableGreen
import com.example.ui.theme.AvailableGreenBg
import com.example.ui.theme.CashierPrimary
import com.example.ui.theme.FamilyGold
import com.example.ui.theme.OccupiedRed
import com.example.ui.theme.OccupiedRedBg
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate50
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.util.PhotoStorageHelper
import com.example.util.PricingCalculator
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewBillScreen(
    state: NewBillUiState,
    rooms: List<RoomEntity>,
    viewModel: BillingViewModel,
    onBillSaved: (BillEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // Camera launcher for ID photo
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            val path = PhotoStorageHelper.saveBitmap(context, bitmap)
            viewModel.setCustomerPhotoPath(path)
        }
    }

    // Gallery launcher for ID photo
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val path = PhotoStorageHelper.saveUriImage(context, uri)
            viewModel.setCustomerPhotoPath(path)
        }
    }

    // Extra charges temp input states
    var extraCategory by remember { mutableStateOf("Food") }
    var extraDescription by remember { mutableStateOf("") }
    var extraAmountInput by remember { mutableStateOf("") }

    // Discount text state
    var discountInput by remember { mutableStateOf("") }

    // Paid text state
    var paidInput by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Slate50)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "NEW GUEST BILL",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = Slate900
                )
                Text(
                    text = "Fast cashier check-in & billing",
                    fontSize = 13.sp,
                    color = Slate500
                )
            }
        }

        // Error Banner if validation failed
        state.errorMessage?.let { msg ->
            Surface(
                color = OccupiedRedBg,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, OccupiedRed),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = msg,
                    color = OccupiedRed,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        // ================= SECTION 1: ROOM SELECTION =================
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate200),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "1. SELECT ROOM (13 ROOMS)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Slate700,
                    letterSpacing = 0.5.sp
                )

                // Room Selector Grid / Horizontal wrap
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val row1 = listOf("01", "02", "03", "04", "05")
                    row1.forEach { roomNum ->
                        val room = rooms.find { it.roomNumber == roomNum }
                        val isSelected = state.selectedRoomNumber == roomNum
                        val isOccupied = room?.status == RoomStatus.OCCUPIED
                        RoomSelectChip(
                            roomNumber = roomNum,
                            roomType = room?.roomType ?: RoomType.NON_AC,
                            isSelected = isSelected,
                            isOccupied = isOccupied,
                            onClick = { viewModel.selectRoomForNewBill(roomNum) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val row2 = listOf("06", "07", "08", "09", "10")
                    row2.forEach { roomNum ->
                        val room = rooms.find { it.roomNumber == roomNum }
                        val isSelected = state.selectedRoomNumber == roomNum
                        val isOccupied = room?.status == RoomStatus.OCCUPIED
                        RoomSelectChip(
                            roomNumber = roomNum,
                            roomType = room?.roomType ?: RoomType.NON_AC,
                            isSelected = isSelected,
                            isOccupied = isOccupied,
                            onClick = { viewModel.selectRoomForNewBill(roomNum) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val room11 = rooms.find { it.roomNumber == "11" }
                    RoomSelectChip(
                        roomNumber = "11",
                        roomType = room11?.roomType ?: RoomType.NON_AC,
                        isSelected = state.selectedRoomNumber == "11",
                        isOccupied = room11?.status == RoomStatus.OCCUPIED,
                        onClick = { viewModel.selectRoomForNewBill("11") },
                        modifier = Modifier.weight(1f)
                    )

                    // Empty spacer where room 12 would be
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .background(Slate100, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No 12", fontSize = 10.sp, color = Slate500)
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    val room13 = rooms.find { it.roomNumber == "13" }
                    RoomSelectChip(
                        roomNumber = "13",
                        roomType = room13?.roomType ?: RoomType.AC_FAMILY,
                        isSelected = state.selectedRoomNumber == "13",
                        isOccupied = room13?.status == RoomStatus.OCCUPIED,
                        onClick = { viewModel.selectRoomForNewBill("13") },
                        modifier = Modifier.weight(1f)
                    )

                    val room14 = rooms.find { it.roomNumber == "14" }
                    RoomSelectChip(
                        roomNumber = "14",
                        roomType = room14?.roomType ?: RoomType.AC,
                        isSelected = state.selectedRoomNumber == "14",
                        isOccupied = room14?.status == RoomStatus.OCCUPIED,
                        onClick = { viewModel.selectRoomForNewBill("14") },
                        modifier = Modifier.weight(1f)
                    )
                }

                val currentSelectedRoom = rooms.find { it.roomNumber == state.selectedRoomNumber }
                if (currentSelectedRoom?.status == RoomStatus.OCCUPIED) {
                    Text(
                        text = "⚠️ Note: Room ${state.selectedRoomNumber} is currently marked as OCCUPIED.",
                        color = OccupiedRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // ================= SECTION 2: GUESTS & STAY TYPE =================
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate200),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "2. GUESTS & STAY TYPE",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Slate700,
                    letterSpacing = 0.5.sp
                )

                // Stay Type: NIGHT vs FULL DAY
                Text(text = "Stay Type:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Slate800)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val isNight = state.stayType == StayType.NIGHT
                    Button(
                        onClick = { viewModel.setStayType(StayType.NIGHT) },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("stay_type_night"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isNight) CashierPrimary else Slate100,
                            contentColor = if (isNight) Color.White else Slate800
                        ),
                        border = if (!isNight) androidx.compose.foundation.BorderStroke(1.dp, Slate200) else null
                    ) {
                        Text(
                            text = "NIGHT",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp
                        )
                    }

                    val isFullDay = state.stayType == StayType.FULL_DAY
                    Button(
                        onClick = { viewModel.setStayType(StayType.FULL_DAY) },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("stay_type_full_day"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isFullDay) CashierPrimary else Slate100,
                            contentColor = if (isFullDay) Color.White else Slate800
                        ),
                        border = if (!isFullDay) androidx.compose.foundation.BorderStroke(1.dp, Slate200) else null
                    ) {
                        Text(
                            text = "FULL DAY",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp
                        )
                    }
                }

                // Guests Count
                Text(
                    text = if (state.roomType == RoomType.AC_FAMILY) "Number of Guests (Family Room price is fixed):" else "Number of Guests:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Slate800
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    (1..5).forEach { count ->
                        val isSelected = state.guestsCount == count
                        Button(
                            onClick = { viewModel.setGuestsCount(count) },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("guests_count_$count"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) CashierPrimary else Slate100,
                                contentColor = if (isSelected) Color.White else Slate800
                            ),
                            border = if (!isSelected) androidx.compose.foundation.BorderStroke(1.dp, Slate200) else null
                        ) {
                            Text(
                                text = "$count",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }

                // Automatic Calculated Room Price Callout
                Surface(
                    color = Color(0xFFEFF6FF),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "CALCULATED ROOM CHARGE",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1D4ED8)
                                )
                                Text(
                                    text = "Room ${state.selectedRoomNumber} (${state.roomType.badgeText}) • ${state.guestsCount} Guest(s) • ${state.stayType.displayName}",
                                    fontSize = 12.sp,
                                    color = Slate700
                                )
                            }
                            Text(
                                text = PricingCalculator.formatCurrency(state.roomCharge),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF1D4ED8)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            androidx.compose.material3.TextButton(
                                onClick = {
                                    val r = rooms.find { it.roomNumber == state.selectedRoomNumber }
                                    if (r != null) {
                                        viewModel.selectRoomForDetails(r)
                                    }
                                },
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    Icons.Default.Edit,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp),
                                    tint = CashierPrimary
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Edit Room / Custom Prices",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CashierPrimary
                                )
                            }
                        }
                    }
                }
            }
        }

        // ================= SECTION 3: CHECK-IN / CHECK-OUT =================
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate200),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "3. CHECK-IN / CHECK-OUT",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Slate700,
                    letterSpacing = 0.5.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = state.checkInDate,
                        onValueChange = { viewModel.setCheckInDate(it) },
                        label = { Text("Check-In Date") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = state.checkInTime,
                        onValueChange = {},
                        enabled = false,
                        label = { Text("Check-In Time") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = state.checkOutDate,
                        onValueChange = { viewModel.setCheckOutDate(it) },
                        label = { Text("Check-Out Date") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = state.checkOutTime,
                        onValueChange = {},
                        enabled = false,
                        label = { Text("Check-Out Time") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }
        }

        // ================= SECTION 4: CUSTOMER DETAILS & PHOTO =================
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate200),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "4. CUSTOMER DETAILS",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Slate700,
                    letterSpacing = 0.5.sp
                )

                OutlinedTextField(
                    value = state.customerName,
                    onValueChange = { viewModel.setCustomerName(it) },
                    label = { Text("Customer Name *") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("customer_name_input"),
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = Slate500) }
                )

                OutlinedTextField(
                    value = state.customerNic,
                    onValueChange = { viewModel.setCustomerNic(it) },
                    label = { Text("NIC / ID Number *") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("customer_nic_input"),
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null, tint = Slate500) }
                )

                OutlinedTextField(
                    value = state.customerPhone,
                    onValueChange = { viewModel.setCustomerPhone(it) },
                    label = { Text("Phone Number") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("customer_phone_input"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = Slate500) }
                )

                // ID Photo Section
                Text(
                    text = "Customer ID Photo:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Slate800
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { cameraLauncher.launch(null) },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("take_photo_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("TAKE PHOTO", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            galleryLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("gallery_photo_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("GALLERY", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                // ID Photo Preview if captured
                state.customerPhotoPath?.let { path ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Slate100),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AsyncImage(
                                    model = File(path),
                                    contentDescription = "ID Photo Preview",
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(RoundedCornerShape(6.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "ID Photo Attached",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = AvailableGreen
                                    )
                                    Text(
                                        text = "Saved to local storage",
                                        fontSize = 11.sp,
                                        color = Slate500
                                    )
                                }
                            }
                            IconButton(onClick = { viewModel.setCustomerPhotoPath(null) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Remove photo", tint = OccupiedRed)
                            }
                        }
                    }
                }
            }
        }

        // ================= SECTION 5: EXTRA CHARGES =================
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate200),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "5. EXTRA CHARGES (OPTIONAL)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Slate700,
                        letterSpacing = 0.5.sp
                    )
                    if (state.extraCharges.isNotEmpty()) {
                        Text(
                            text = "+${PricingCalculator.formatCurrency(state.extraChargesTotal)}",
                            fontWeight = FontWeight.Bold,
                            color = CashierPrimary,
                            fontSize = 13.sp
                        )
                    }
                }

                // Quick Category selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Food", "Drinks", "Extra Bed", "Other").forEach { cat ->
                        val isSel = extraCategory == cat
                        FilterChip(
                            selected = isSel,
                            onClick = {
                                extraCategory = cat
                                if (extraDescription.isBlank() || listOf("Food", "Drinks", "Extra Bed", "Other").contains(extraDescription)) {
                                    extraDescription = cat
                                }
                            },
                            label = { Text(cat, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CashierPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = extraDescription,
                        onValueChange = { extraDescription = it },
                        label = { Text("Description") },
                        modifier = Modifier.weight(1.5f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = extraAmountInput,
                        onValueChange = { extraAmountInput = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Amount (Rs.)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    Button(
                        onClick = {
                            val amount = extraAmountInput.toDoubleOrNull() ?: 0.0
                            val desc = extraDescription.ifBlank { extraCategory }
                            if (amount > 0.0) {
                                viewModel.addExtraCharge(extraCategory, desc, amount)
                                extraDescription = ""
                                extraAmountInput = ""
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CashierPrimary),
                        modifier = Modifier.height(56.dp)
                    ) {
                        Text("ADD", fontWeight = FontWeight.Bold)
                    }
                }

                // List of added extra charges
                if (state.extraCharges.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        state.extraCharges.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Slate100, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${item.description} (${item.category})",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Slate900
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = PricingCalculator.formatCurrency(item.amount),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Slate900
                                    )
                                    IconButton(
                                        onClick = { viewModel.removeExtraCharge(item.id) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "Delete item",
                                            tint = OccupiedRed,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ================= SECTION 6: DISCOUNT & PAYMENT =================
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate200),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "6. DISCOUNT & PAYMENT",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Slate700,
                    letterSpacing = 0.5.sp
                )

                // Optional Discount Field
                OutlinedTextField(
                    value = discountInput,
                    onValueChange = {
                        discountInput = it.filter { ch -> ch.isDigit() || ch == '.' }
                        viewModel.setDiscount(discountInput.toDoubleOrNull() ?: 0.0)
                    },
                    label = { Text("Optional Discount Amount (Rs.)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )

                // Payment Method Selector
                Text(text = "Payment Method:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Slate800)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PaymentMethod.values().forEach { method ->
                        val isSelected = state.paymentMethod == method
                        Button(
                            onClick = { viewModel.setPaymentMethod(method) },
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) CashierPrimary else Slate100,
                                contentColor = if (isSelected) Color.White else Slate800
                            ),
                            border = if (!isSelected) androidx.compose.foundation.BorderStroke(1.dp, Slate200) else null
                        ) {
                            Text(method.displayName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }

                // Amount Customer Pays Field
                OutlinedTextField(
                    value = paidInput,
                    onValueChange = {
                        paidInput = it.filter { ch -> ch.isDigit() || ch == '.' }
                        viewModel.setPaidAmount(paidInput.toDoubleOrNull() ?: 0.0)
                    },
                    label = { Text("Amount Paid by Customer (Rs.)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("paid_amount_input"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    trailingIcon = {
                        Text(
                            text = "Pay Full",
                            color = CashierPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .clickable {
                                    paidInput = state.total.toLong().toString()
                                    viewModel.setPaidAmount(state.total)
                                }
                        )
                    }
                )

                // TOTAL & BALANCE DISPLAY (VERY LARGE & CLEAR)
                Surface(
                    color = Slate900,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "TOTAL",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = PricingCalculator.formatCurrency(state.total),
                                color = Color.White,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 10.dp),
                            color = Color(0xFF334155)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "PAID (${state.paymentMethod.displayName})",
                                color = Color(0xFF38BDF8),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = PricingCalculator.formatCurrency(state.paidAmount),
                                color = Color(0xFF38BDF8),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        val balanceColor = if (state.balance > 0.0) OccupiedRed else AvailableGreen
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (state.balance > 0.0) "BALANCE DUE" else "BALANCE SETTLED",
                                color = balanceColor,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = PricingCalculator.formatCurrency(state.balance),
                                color = balanceColor,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
        }

        // SAVE BILL BUTTON (VERY LARGE, PROMINENT)
        Button(
            onClick = {
                viewModel.saveBill(onSuccess = onBillSaved)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
                .testTag("save_bill_button"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AvailableGreen),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp),
            enabled = !state.isSubmitting
        ) {
            if (state.isSubmitting) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
            } else {
                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "SAVE BILL",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun RoomSelectChip(
    roomNumber: String,
    roomType: RoomType,
    isSelected: Boolean,
    isOccupied: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor = when {
        isSelected -> CashierPrimary
        isOccupied -> OccupiedRed
        else -> Slate200
    }
    val containerBg = when {
        isSelected -> Color(0xFFDBEAFE)
        isOccupied -> OccupiedRedBg
        else -> Slate100
    }

    Box(
        modifier = modifier
            .height(48.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(containerBg)
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onClick)
            .testTag("select_room_$roomNumber"),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = roomNumber,
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (isSelected) CashierPrimary else if (isOccupied) OccupiedRed else Slate900
            )
            Text(
                text = roomType.badgeText,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = when (roomType) {
                    RoomType.AC -> Color(0xFF0284C7)
                    RoomType.AC_FAMILY -> FamilyGold
                    RoomType.NON_AC -> Slate500
                }
            )
        }
    }
}
