package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF93C5FD),
    onPrimary = Color(0xFF001D36),
    primaryContainer = Color(0xFF004A8A),
    onPrimaryContainer = Color(0xFFD3E4FF),
    secondary = Color(0xFF38BDF8),
    tertiary = Color(0xFF2DD4BF),
    background = Color(0xFF1B1B1F),
    surface = Color(0xFF232529),
    onBackground = Color(0xFFF3F4F9),
    onSurface = Color(0xFFF3F4F9),
    surfaceVariant = Color(0xFF303237),
    onSurfaceVariant = Color(0xFFC5C6D0)
)

private val LightColorScheme = lightColorScheme(
    primary = CashierPrimary,
    onPrimary = Color.White,
    primaryContainer = CleanBluePill,
    onPrimaryContainer = CashierPrimaryVariant,
    secondary = CashierSecondary,
    onSecondary = Color.White,
    tertiary = CashierTertiary,
    background = CleanBg,
    surface = CleanSurface,
    onBackground = CleanTextPrimary,
    onSurface = CleanTextPrimary,
    surfaceVariant = CleanBg,
    onSurfaceVariant = CleanTextSecondary,
    outline = CleanBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep consistent high-contrast branding for cashier use
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
