package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.FamilyRestroom
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.RoomEntity
import com.example.data.RoomStatus
import com.example.data.RoomType
import com.example.ui.theme.AvailableGreen
import com.example.ui.theme.AvailableGreenBg
import com.example.ui.theme.AvailableGreenBorder
import com.example.ui.theme.AvailableGreenDot
import com.example.ui.theme.CashierPrimary
import com.example.ui.theme.CleanBorder
import com.example.ui.theme.CleanTextPrimary
import com.example.ui.theme.CleanTextSecondary
import com.example.ui.theme.FamilyBlue
import com.example.ui.theme.FamilyGold
import com.example.ui.theme.FamilyGoldBg
import com.example.ui.theme.OccupiedRed
import com.example.ui.theme.OccupiedRedBg
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900

@Composable
fun RoomTypeBadge(roomType: RoomType, modifier: Modifier = Modifier) {
    val (bgColor, textColor, text) = when (roomType) {
        RoomType.AC -> Triple(Color(0xFFE0F2FE), Color(0xFF005FB0), "AC")
        RoomType.AC_FAMILY -> Triple(Color(0xFFEFF6FF), Color(0xFF2563EB), "Family")
        RoomType.NON_AC -> Triple(Color(0xFFF3F4F9), CleanTextSecondary, "Non-AC")
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(6.dp),
        modifier = modifier
    ) {
        Text(
            text = text,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun RoomStatusBadge(status: RoomStatus, modifier: Modifier = Modifier) {
    val isAvailable = status == RoomStatus.AVAILABLE
    val bgColor = if (isAvailable) AvailableGreenBg else OccupiedRedBg
    val textColor = if (isAvailable) AvailableGreen else OccupiedRed
    val dotColor = if (isAvailable) AvailableGreenDot else OccupiedRed
    val text = if (isAvailable) "AVAILABLE" else "OCCUPIED"

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(6.dp),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = text,
                color = textColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }
    }
}

/**
 * Clean Minimalism Room Button matching design HTML:
 * - Available: White card with green-100 border, dark bold room number, uppercase type, green dot indicator
 * - Occupied: Bold crimson red card (#BA1A1A) with white typography and white dot indicator
 * - Family: Blue accent room number and label
 */
@Composable
fun LargeRoomButton(
    room: RoomEntity,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isAvailable = room.status == RoomStatus.AVAILABLE
    val isFamily = room.roomType == RoomType.AC_FAMILY

    val containerBg = if (isAvailable) Color.White else OccupiedRed
    val borderStroke = if (isAvailable) androidx.compose.foundation.BorderStroke(1.dp, AvailableGreenBorder) else null

    val numberColor = when {
        !isAvailable -> Color.White
        isFamily -> FamilyBlue
        else -> CleanTextPrimary
    }

    val typeLabel = when (room.roomType) {
        RoomType.AC -> "AC"
        RoomType.AC_FAMILY -> "Family"
        RoomType.NON_AC -> "Non-AC"
    }

    val typeColor = when {
        !isAvailable -> Color.White.copy(alpha = 0.85f)
        isFamily -> FamilyBlue
        else -> CleanTextSecondary.copy(alpha = 0.7f)
    }

    val dotColor = if (isAvailable) AvailableGreenDot else Color.White

    Card(
        modifier = modifier
            .testTag("room_button_${room.roomNumber}")
            .height(82.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = containerBg),
        border = borderStroke,
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp, pressedElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 6.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Room Number
            Text(
                text = room.roomNumber,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = numberColor,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )

            // Room Type
            Text(
                text = typeLabel,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = typeColor,
                textAlign = TextAlign.Center,
                maxLines = 1
            )

            Spacer(modifier = Modifier.height(3.dp))

            // Status indicator dot
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
        }
    }
}
