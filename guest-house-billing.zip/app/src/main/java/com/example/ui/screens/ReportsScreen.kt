package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BillEntity
import com.example.data.ExpenseEntity
import com.example.ui.FinancialReportData
import com.example.ui.ReportPeriod
import com.example.ui.theme.CashierPrimary
import com.example.ui.theme.CleanBg
import com.example.ui.theme.CleanBorder
import com.example.ui.theme.CleanSurface
import com.example.ui.theme.CleanTextPrimary
import com.example.ui.theme.CleanTextSecondary
import com.example.util.PdfReportGenerator
import com.example.util.PricingCalculator
import com.example.util.ReportDateHelper

enum class ReportDetailView {
    INCOME,
    EXPENSES
}

@Composable
fun ReportsScreen(
    reportData: FinancialReportData,
    onPeriodSelected: (ReportPeriod) -> Unit,
    onCustomDatesChanged: (from: String, to: String) -> Unit,
    onAddExpenseClick: () -> Unit,
    onEditExpenseClick: (ExpenseEntity) -> Unit,
    onDeleteExpenseClick: (ExpenseEntity) -> Unit,
    onBillClick: (BillEntity) -> Unit
) {
    val context = LocalContext.current
    var activeDetailView by remember { mutableStateOf(ReportDetailView.INCOME) }

    // Custom date pickers state
    var customFromInput by remember(reportData.fromDate) { mutableStateOf(reportData.fromDate) }
    var customToInput by remember(reportData.toDate) { mutableStateOf(reportData.toDate) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CleanBg)
            .padding(horizontal = 16.dp)
            .testTag("reports_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Header & Quick Action Buttons
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(CashierPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Assessment,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "FINANCIAL REPORTS",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = CleanTextPrimary
                        )
                    }
                    Text(
                        text = "Income & Expense tracking for cashier",
                        fontSize = 12.sp,
                        color = CleanTextSecondary,
                        modifier = Modifier.padding(start = 44.dp)
                    )
                }

                // Header Actions: Add Expense & Share PDF
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = onAddExpenseClick,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(38.dp)
                            .testTag("btn_add_expense_top")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "+ EXPENSE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    Button(
                        onClick = {
                            try {
                                PdfReportGenerator.shareReportPdf(
                                    context = context,
                                    periodTitle = reportData.periodTitle,
                                    fromDate = reportData.fromDate,
                                    toDate = reportData.toDate,
                                    totalIncome = reportData.totalIncome,
                                    totalExpenses = reportData.totalExpenses,
                                    netIncome = reportData.netIncome,
                                    outstandingBalance = reportData.outstandingBalance,
                                    billsCount = reportData.billsCount,
                                    bills = reportData.filteredBills,
                                    expenses = reportData.filteredExpenses
                                )
                            } catch (e: Exception) {
                                Toast.makeText(context, "Error creating PDF: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CashierPrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(38.dp)
                            .testTag("btn_export_pdf")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "PDF",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // 2. Four Period Options (Tabs): TODAY, THIS WEEK, THIS MONTH, CUSTOM DATE
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CleanSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    ReportPeriod.values().forEach { period ->
                        val isSelected = reportData.period == period
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onPeriodSelected(period) }
                                .testTag("tab_period_${period.name.lowercase()}"),
                            color = if (isSelected) CashierPrimary else Color.Transparent,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = period.label,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color.White else CleanTextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Custom Date Range Pickers (Visible when CUSTOM DATE is active)
        item {
            AnimatedVisibility(visible = reportData.period == ReportPeriod.CUSTOM_DATE) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CleanSurface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.DateRange,
                                contentDescription = null,
                                tint = CashierPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "CUSTOM DATE RANGE (YYYY-MM-DD)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = CleanTextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = customFromInput,
                                onValueChange = { customFromInput = it },
                                label = { Text("From Date", fontSize = 11.sp) },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("input_custom_from"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CashierPrimary,
                                    unfocusedBorderColor = CleanBorder
                                )
                            )
                            OutlinedTextField(
                                value = customToInput,
                                onValueChange = { customToInput = it },
                                label = { Text("To Date", fontSize = 11.sp) },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("input_custom_to"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CashierPrimary,
                                    unfocusedBorderColor = CleanBorder
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Button(
                                onClick = {
                                    onCustomDatesChanged(customFromInput.trim(), customToInput.trim())
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CashierPrimary),
                                modifier = Modifier.testTag("btn_apply_custom_date")
                            ) {
                                Text("APPLY DATES", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // 4. Period Date Banner
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFFF1F5F9)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Period: ${reportData.fromDate} to ${reportData.toDate}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = CleanTextSecondary
                    )
                    Text(
                        text = "${reportData.billsCount} Bills • ${reportData.filteredExpenses.size} Expenses",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CashierPrimary
                    )
                }
            }
        }

        // 5. Large Easy-to-Read Financial Summary Cards (2x2 Grid)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Row 1: TOTAL INCOME & TOTAL EXPENSES
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // TOTAL INCOME Card
                    FinancialMetricCard(
                        title = "TOTAL INCOME",
                        amount = reportData.totalIncome,
                        subtitle = "Actual Money Received",
                        note = "Tap to view bill receipts",
                        icon = Icons.Default.TrendingUp,
                        primaryColor = Color(0xFF059669),
                        bgColor = Color(0xFFF0FDF4),
                        borderColor = Color(0xFFBBF7D0),
                        isSelected = activeDetailView == ReportDetailView.INCOME,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("card_total_income"),
                        onClick = { activeDetailView = ReportDetailView.INCOME }
                    )

                    // TOTAL EXPENSES Card
                    FinancialMetricCard(
                        title = "TOTAL EXPENSES",
                        amount = reportData.totalExpenses,
                        subtitle = "${reportData.filteredExpenses.size} Recorded Costs",
                        note = "Tap to view breakdown",
                        icon = Icons.Default.TrendingDown,
                        primaryColor = Color(0xFFD97706),
                        bgColor = Color(0xFFFFFBEB),
                        borderColor = Color(0xFFFDE68A),
                        isSelected = activeDetailView == ReportDetailView.EXPENSES,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("card_total_expenses"),
                        onClick = { activeDetailView = ReportDetailView.EXPENSES }
                    )
                }

                // Row 2: NET INCOME & OUTSTANDING BALANCE
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val isNetPositive = reportData.netIncome >= 0
                    val netPrimary = if (isNetPositive) Color(0xFF059669) else Color(0xFFDC2626)
                    val netBg = if (isNetPositive) Color(0xFFF0FDF4) else Color(0xFFFEF2F2)
                    val netBorder = if (isNetPositive) Color(0xFFBBF7D0) else Color(0xFFFECACA)

                    // NET INCOME Card
                    FinancialMetricCard(
                        title = "NET INCOME",
                        amount = reportData.netIncome,
                        subtitle = "Income - Expenses",
                        note = "Payments Rec'd - Costs",
                        icon = Icons.Default.Payments,
                        primaryColor = netPrimary,
                        bgColor = netBg,
                        borderColor = netBorder,
                        isSelected = false,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("card_net_income"),
                        onClick = {}
                    )

                    // OUTSTANDING BALANCE Card
                    FinancialMetricCard(
                        title = "OUTSTANDING",
                        amount = reportData.outstandingBalance,
                        subtitle = "Unpaid Bill Balance",
                        note = "Excluded from income",
                        icon = Icons.Default.Receipt,
                        primaryColor = Color(0xFFE11D48),
                        bgColor = Color(0xFFFFF1F2),
                        borderColor = Color(0xFFFECDD3),
                        isSelected = false,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("card_outstanding_balance"),
                        onClick = {}
                    )
                }
            }
        }

        // 6. Secondary Stats Pill Bar
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = CleanSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "BILLS COUNT",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = CleanTextSecondary
                        )
                        Text(
                            text = "${reportData.billsCount} Bills Saved",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = CleanTextPrimary
                        )
                    }

                    Box(
                        modifier = Modifier
                            .height(28.dp)
                            .width(1.dp)
                            .background(CleanBorder)
                    )

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "AMOUNT RECEIVED",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = CleanTextSecondary
                        )
                        Text(
                            text = PricingCalculator.formatCurrency(reportData.amountReceived),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF059669)
                        )
                    }
                }
            }
        }

        // 7. Details Switch Tabs: [ INCOME BREAKDOWN (X) ] vs [ EXPENSE BREAKDOWN (Y) ]
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier
                        .background(CleanSurface, RoundedCornerShape(10.dp))
                        .border(1.dp, CleanBorder, RoundedCornerShape(10.dp))
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val isIncome = activeDetailView == ReportDetailView.INCOME
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { activeDetailView = ReportDetailView.INCOME }
                            .testTag("tab_view_income"),
                        color = if (isIncome) Color(0xFF059669) else Color.Transparent,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "INCOME DETAILS (${reportData.billsCount})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isIncome) Color.White else CleanTextSecondary,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                        )
                    }

                    val isExpense = activeDetailView == ReportDetailView.EXPENSES
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { activeDetailView = ReportDetailView.EXPENSES }
                            .testTag("tab_view_expenses"),
                        color = if (isExpense) Color(0xFFD97706) else Color.Transparent,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "EXPENSES (${reportData.filteredExpenses.size})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isExpense) Color.White else CleanTextSecondary,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                        )
                    }
                }

                if (activeDetailView == ReportDetailView.EXPENSES) {
                    TextButton(
                        onClick = onAddExpenseClick,
                        modifier = Modifier.testTag("btn_quick_add_expense")
                    ) {
                        Text(
                            text = "+ ADD EXPENSE",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFD97706)
                        )
                    }
                }
            }
        }

        // 8. Dynamic Breakdown List Items
        if (activeDetailView == ReportDetailView.INCOME) {
            if (reportData.filteredBills.isEmpty()) {
                item {
                    EmptyStatePlaceholder(
                        title = "No bills or payments for this period",
                        subtitle = "When cashiers save bills, received payments will appear here as income."
                    )
                }
            } else {
                items(reportData.filteredBills, key = { it.id }) { bill ->
                    IncomeBillCard(
                        bill = bill,
                        onClick = { onBillClick(bill) }
                    )
                }
            }
        } else {
            if (reportData.filteredExpenses.isEmpty()) {
                item {
                    EmptyStatePlaceholder(
                        title = "No expenses recorded for this period",
                        subtitle = "Tap '+ ADD EXPENSE' to record electricity, water, cleaning, supplies or maintenance costs."
                    )
                }
            } else {
                items(reportData.filteredExpenses, key = { it.id }) { expense ->
                    ExpenseItemCard(
                        expense = expense,
                        onEdit = { onEditExpenseClick(expense) },
                        onDelete = { onDeleteExpenseClick(expense) }
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

/**
 * Large, easy-to-read Financial Card specifically crafted for mobile cashiers.
 */
@Composable
fun FinancialMetricCard(
    title: String,
    amount: Double,
    subtitle: String,
    note: String,
    icon: ImageVector,
    primaryColor: Color,
    bgColor: Color,
    borderColor: Color,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) primaryColor else borderColor
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = primaryColor
                )
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(primaryColor.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = primaryColor,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Large, easy-to-read amount
            Text(
                text = PricingCalculator.formatCurrency(amount),
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = primaryColor
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = subtitle,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = CleanTextPrimary
            )

            Text(
                text = note,
                fontSize = 9.5.sp,
                color = CleanTextSecondary
            )
        }
    }
}

/**
 * Income Breakdown Bill Card showing:
 * Bill Number, Customer, Room, Date, Paid Amount, Payment Method.
 */
@Composable
fun IncomeBillCard(
    bill: BillEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .testTag("income_bill_${bill.billNumber}"),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = CleanSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CleanBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = bill.billNumber,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = CashierPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color(0xFFEFF6FF)
                    ) {
                        Text(
                            text = "Room ${bill.roomNumber}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = CashierPrimary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = bill.customerName.ifBlank { "Guest" },
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = CleanTextPrimary
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "${bill.checkInDate} • ${bill.paymentMethod.displayName}",
                    fontSize = 10.5.sp,
                    color = CleanTextSecondary
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = PricingCalculator.formatCurrency(bill.paid),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF059669)
                )
                if (bill.balance > 0) {
                    Text(
                        text = "Due: ${PricingCalculator.formatCurrency(bill.balance)}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFDC2626)
                    )
                } else {
                    Text(
                        text = "PAID FULL",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF059669)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "View receipt",
                        fontSize = 10.sp,
                        color = CashierPrimary
                    )
                    Icon(
                        imageVector = Icons.Default.ArrowForwardIos,
                        contentDescription = null,
                        tint = CashierPrimary,
                        modifier = Modifier.size(10.dp)
                    )
                }
            }
        }
    }
}

/**
 * Expense Card showing:
 * Date, Category, Description, Amount, Note, Edit/Delete actions.
 */
@Composable
fun ExpenseItemCard(
    expense: ExpenseEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("expense_card_${expense.id}"),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = CleanSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CleanBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFFEF3C7)
                    ) {
                        Text(
                            text = expense.category,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB45309),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = expense.date,
                        fontSize = 11.sp,
                        color = CleanTextSecondary
                    )
                }

                // Amount
                Text(
                    text = PricingCalculator.formatCurrency(expense.amount),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFD97706)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = expense.description,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = CleanTextPrimary
            )

            if (expense.note.isNotBlank()) {
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "Note: ${expense.note}",
                    fontSize = 11.sp,
                    color = CleanTextSecondary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(4.dp))

            // Action Buttons: Edit and Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("btn_edit_expense_${expense.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit Expense",
                        tint = CashierPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("btn_delete_expense_${expense.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete Expense",
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun EmptyStatePlaceholder(
    title: String,
    subtitle: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CleanSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CleanBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Assessment,
                contentDescription = null,
                tint = Color(0xFFCBD5E1),
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = CleanTextPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = CleanTextSecondary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}
