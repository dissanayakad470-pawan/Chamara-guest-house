package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.BillEntity
import com.example.data.BillItemEntity
import com.example.data.BillingRepository
import com.example.data.CustomerEntity
import com.example.data.ExpenseEntity
import com.example.data.PaymentMethod
import com.example.data.RoomEntity
import com.example.data.RoomStatus
import com.example.data.RoomType
import com.example.data.StayType
import com.example.util.PricingCalculator
import com.example.util.ReportDateHelper
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ExtraChargeItem(
    val id: String = UUID.randomUUID().toString(),
    val category: String,
    val description: String,
    val amount: Double
)

data class NewBillUiState(
    val selectedRoomNumber: String = "01",
    val roomType: RoomType = RoomType.NON_AC,
    val guestsCount: Int = 1,
    val stayType: StayType = StayType.NIGHT,
    val customerName: String = "",
    val customerNic: String = "",
    val customerPhone: String = "",
    val customerPhotoPath: String? = null,
    val checkInDate: String = "",
    val checkInTime: String = "5:00 PM",
    val checkOutDate: String = "",
    val checkOutTime: String = "8:30 AM",
    val extraCharges: List<ExtraChargeItem> = emptyList(),
    val discount: Double = 0.0,
    val paidAmount: Double = 0.0,
    val paymentMethod: PaymentMethod = PaymentMethod.CASH,
    val isSubmitting: Boolean = false,
    val errorMessage: String? = null,
    val overrideRoomCharge: Double? = null
) {
    val roomCharge: Double
        get() = overrideRoomCharge ?: PricingCalculator.calculateRoomCharge(roomType, guestsCount, stayType)

    val extraChargesTotal: Double
        get() = extraCharges.sumOf { it.amount }

    val total: Double
        get() = (roomCharge + extraChargesTotal - discount).coerceAtLeast(0.0)

    val balance: Double
        get() = (total - paidAmount).coerceAtLeast(0.0)
}

enum class ReportPeriod(val label: String) {
    TODAY("TODAY"),
    THIS_WEEK("THIS WEEK"),
    THIS_MONTH("THIS MONTH"),
    CUSTOM_DATE("CUSTOM DATE")
}

data class FinancialReportData(
    val period: ReportPeriod = ReportPeriod.TODAY,
    val periodTitle: String = "TODAY",
    val fromDate: String = "",
    val toDate: String = "",
    val billsCount: Int = 0,
    val totalIncome: Double = 0.0, // Only money actually received (sum of paid)
    val totalExpenses: Double = 0.0, // Sum of expense amounts
    val netIncome: Double = 0.0, // totalIncome - totalExpenses
    val outstandingBalance: Double = 0.0, // Sum of unpaid balances
    val amountReceived: Double = 0.0,
    val filteredBills: List<BillEntity> = emptyList(),
    val filteredExpenses: List<ExpenseEntity> = emptyList()
)

@OptIn(ExperimentalCoroutinesApi::class)
class BillingViewModel(application: Application) : AndroidViewModel(application) {

    private val database: AppDatabase = AppDatabase.getDatabase(application)
    private val repository: BillingRepository = BillingRepository(database)

    // Selected room for Room Details / Pricing Editor
    private val _selectedRoomForDetails = MutableStateFlow<RoomEntity?>(null)
    val selectedRoomForDetails: StateFlow<RoomEntity?> = _selectedRoomForDetails.asStateFlow()

    // Confirmation message banner / toast
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    val rooms: StateFlow<List<RoomEntity>> = repository.allRoomsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val availableRoomsCount: StateFlow<Int> = rooms.combine(MutableStateFlow(Unit)) { rList, _ ->
        rList.count { it.status == RoomStatus.AVAILABLE }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val occupiedRoomsCount: StateFlow<Int> = rooms.combine(MutableStateFlow(Unit)) { rList, _ ->
        rList.count { it.status == RoomStatus.OCCUPIED }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Bills state & search
    val billSearchQuery = MutableStateFlow("")
    val bills: StateFlow<List<BillEntity>> = billSearchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) repository.allBillsFlow
            else repository.searchBills(query.trim())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Customers state & search
    val customerSearchQuery = MutableStateFlow("")
    val customers: StateFlow<List<CustomerEntity>> = customerSearchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) repository.allCustomersFlow
            else repository.searchCustomers(query.trim())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // New Bill Form State
    private val _newBillState = MutableStateFlow(createInitialNewBillState())
    val newBillState: StateFlow<NewBillUiState> = _newBillState.asStateFlow()

    // Active Checkout state
    private val _activeCheckoutRoom = MutableStateFlow<RoomEntity?>(null)
    val activeCheckoutRoom: StateFlow<RoomEntity?> = _activeCheckoutRoom.asStateFlow()

    private val _activeCheckoutBill = MutableStateFlow<BillEntity?>(null)
    val activeCheckoutBill: StateFlow<BillEntity?> = _activeCheckoutBill.asStateFlow()

    // Completed / Viewed Bill
    private val _viewedBill = MutableStateFlow<BillEntity?>(null)
    val viewedBill: StateFlow<BillEntity?> = _viewedBill.asStateFlow()

    private val _viewedBillItems = MutableStateFlow<List<BillItemEntity>>(emptyList())
    val viewedBillItems: StateFlow<List<BillItemEntity>> = _viewedBillItems.asStateFlow()

    // Selected Customer & their bills
    private val _selectedCustomer = MutableStateFlow<CustomerEntity?>(null)
    val selectedCustomer: StateFlow<CustomerEntity?> = _selectedCustomer.asStateFlow()

    private val _customerBills = MutableStateFlow<List<BillEntity>>(emptyList())
    val customerBills: StateFlow<List<BillEntity>> = _customerBills.asStateFlow()

    private fun getTodayDateString(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    private fun getTomorrowDateString(): String {
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_YEAR, 1)
        return SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.time)
    }

    private fun createInitialNewBillState(): NewBillUiState {
        val defaultRoom = AppDatabase.DEFAULT_ROOMS.first()
        return NewBillUiState(
            selectedRoomNumber = defaultRoom.roomNumber,
            roomType = defaultRoom.roomType,
            guestsCount = 1,
            stayType = StayType.NIGHT,
            checkInDate = getTodayDateString(),
            checkInTime = "5:00 PM",
            checkOutDate = getTomorrowDateString(),
            checkOutTime = "8:30 AM"
        )
    }

    fun resetNewBillForm(roomNumber: String? = null) {
        val targetRoomNumber = roomNumber ?: "01"
        val room = rooms.value.find { it.roomNumber == targetRoomNumber }
            ?: AppDatabase.DEFAULT_ROOMS.find { it.roomNumber == targetRoomNumber }
            ?: AppDatabase.DEFAULT_ROOMS.first()

        _newBillState.value = NewBillUiState(
            selectedRoomNumber = room.roomNumber,
            roomType = room.roomType,
            guestsCount = 1,
            stayType = StayType.NIGHT,
            checkInDate = getTodayDateString(),
            checkInTime = "5:00 PM",
            checkOutDate = getTomorrowDateString(),
            checkOutTime = "8:30 AM"
        )
    }

    fun selectRoomForNewBill(roomNumber: String) {
        val room = rooms.value.find { it.roomNumber == roomNumber }
            ?: AppDatabase.DEFAULT_ROOMS.find { it.roomNumber == roomNumber }
        if (room != null) {
            val price = room.getPrice(_newBillState.value.guestsCount, _newBillState.value.stayType)
            _newBillState.value = _newBillState.value.copy(
                selectedRoomNumber = room.roomNumber,
                roomType = room.roomType,
                overrideRoomCharge = price,
                errorMessage = null
            )
        }
    }

    fun setGuestsCount(count: Int) {
        val clamped = count.coerceIn(1, 10)
        val room = rooms.value.find { it.roomNumber == _newBillState.value.selectedRoomNumber }
        val price = room?.getPrice(clamped, _newBillState.value.stayType)
            ?: PricingCalculator.calculateRoomCharge(_newBillState.value.roomType, clamped, _newBillState.value.stayType)
        _newBillState.value = _newBillState.value.copy(
            guestsCount = clamped,
            overrideRoomCharge = price
        )
    }

    fun setStayType(stayType: StayType) {
        val room = rooms.value.find { it.roomNumber == _newBillState.value.selectedRoomNumber }
        val price = room?.getPrice(_newBillState.value.guestsCount, stayType)
            ?: PricingCalculator.calculateRoomCharge(_newBillState.value.roomType, _newBillState.value.guestsCount, stayType)
        _newBillState.value = _newBillState.value.copy(
            stayType = stayType,
            overrideRoomCharge = price
        )
    }

    fun setCustomerName(name: String) {
        _newBillState.value = _newBillState.value.copy(customerName = name, errorMessage = null)
    }

    fun setCustomerNic(nic: String) {
        _newBillState.value = _newBillState.value.copy(customerNic = nic, errorMessage = null)
    }

    fun setCustomerPhone(phone: String) {
        _newBillState.value = _newBillState.value.copy(customerPhone = phone)
    }

    fun setCustomerPhotoPath(path: String?) {
        _newBillState.value = _newBillState.value.copy(customerPhotoPath = path)
    }

    fun setCheckInDate(date: String) {
        _newBillState.value = _newBillState.value.copy(checkInDate = date)
    }

    fun setCheckOutDate(date: String) {
        _newBillState.value = _newBillState.value.copy(checkOutDate = date)
    }

    fun addExtraCharge(category: String, description: String, amount: Double) {
        if (description.isBlank() || amount <= 0.0) return
        val current = _newBillState.value.extraCharges
        val updated = current + ExtraChargeItem(
            category = category,
            description = description.trim(),
            amount = amount
        )
        _newBillState.value = _newBillState.value.copy(extraCharges = updated)
    }

    fun removeExtraCharge(id: String) {
        val updated = _newBillState.value.extraCharges.filterNot { it.id == id }
        _newBillState.value = _newBillState.value.copy(extraCharges = updated)
    }

    fun setDiscount(discount: Double) {
        _newBillState.value = _newBillState.value.copy(discount = discount.coerceAtLeast(0.0))
    }

    fun setPaidAmount(paid: Double) {
        _newBillState.value = _newBillState.value.copy(paidAmount = paid.coerceAtLeast(0.0))
    }

    fun setPaymentMethod(method: PaymentMethod) {
        _newBillState.value = _newBillState.value.copy(paymentMethod = method)
    }

    fun saveBill(onSuccess: (BillEntity) -> Unit) {
        val state = _newBillState.value
        if (state.customerName.isBlank()) {
            _newBillState.value = state.copy(errorMessage = "Please enter Customer Name")
            return
        }
        if (state.customerNic.isBlank()) {
            _newBillState.value = state.copy(errorMessage = "Please enter NIC / ID Number")
            return
        }

        viewModelScope.launch {
            _newBillState.value = state.copy(isSubmitting = true, errorMessage = null)
            try {
                val bill = repository.createAndSaveBill(
                    customerName = state.customerName,
                    customerNic = state.customerNic,
                    customerPhone = state.customerPhone,
                    customerPhotoPath = state.customerPhotoPath,
                    roomNumber = state.selectedRoomNumber,
                    roomType = state.roomType,
                    guestsCount = state.guestsCount,
                    stayType = state.stayType,
                    checkInDate = state.checkInDate,
                    checkInTime = state.checkInTime,
                    checkOutDate = state.checkOutDate,
                    checkOutTime = state.checkOutTime,
                    roomCharge = state.roomCharge,
                    extraItems = state.extraCharges.map { it.category to (it.description to it.amount) },
                    discount = state.discount,
                    paid = state.paidAmount,
                    paymentMethod = state.paymentMethod
                )
                // Load bill items for viewing
                val items = repository.getItemsForBillSync(bill.id)
                _viewedBill.value = bill
                _viewedBillItems.value = items
                _newBillState.value = createInitialNewBillState()
                onSuccess(bill)
            } catch (e: Exception) {
                _newBillState.value = state.copy(
                    isSubmitting = false,
                    errorMessage = "Error saving bill: ${e.message}"
                )
            }
        }
    }

    // Checkout Flow
    fun openCheckout(room: RoomEntity) {
        _activeCheckoutRoom.value = room
        viewModelScope.launch {
            val bill = repository.getActiveBillForRoom(room.roomNumber)
            _activeCheckoutBill.value = bill
        }
    }

    fun closeCheckout() {
        _activeCheckoutRoom.value = null
        _activeCheckoutBill.value = null
    }

    fun completeCheckout(
        roomNumber: String,
        billId: Long,
        finalPayment: Double,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            repository.checkoutRoom(
                roomNumber = roomNumber,
                billId = billId,
                additionalPayment = finalPayment
            )
            closeCheckout()
            onComplete()
        }
    }

    // Viewing a specific bill
    fun viewBill(bill: BillEntity) {
        _viewedBill.value = bill
        viewModelScope.launch {
            _viewedBillItems.value = repository.getItemsForBillSync(bill.id)
        }
    }

    fun clearViewedBill() {
        _viewedBill.value = null
        _viewedBillItems.value = emptyList()
    }

    // Viewing customer details
    fun viewCustomer(customer: CustomerEntity) {
        _selectedCustomer.value = customer
        viewModelScope.launch {
            repository.getBillsForCustomer(customer.id).collect { bills ->
                _customerBills.value = bills
            }
        }
    }

    fun clearSelectedCustomer() {
        _selectedCustomer.value = null
        _customerBills.value = emptyList()
    }

    // Room Management & Pricing Editor
    fun selectRoomForDetails(room: RoomEntity) {
        _selectedRoomForDetails.value = room
    }

    fun clearSelectedRoomForDetails() {
        _selectedRoomForDetails.value = null
    }

    fun clearSnackbarMessage() {
        _snackbarMessage.value = null
    }

    fun setSnackbarMessage(msg: String) {
        _snackbarMessage.value = msg
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun updateRoomDetails(
        oldRoomNumber: String,
        updatedRoom: RoomEntity,
        onSuccess: () -> Unit,
        onError: (String) -> Unit = {}
    ) {
        val trimmedNum = updatedRoom.roomNumber.trim()
        if (trimmedNum == "12" || trimmedNum == "012") {
            onError("Room 12 does not exist and cannot be created.")
            return
        }
        if (trimmedNum.isBlank()) {
            onError("Room number cannot be empty.")
            return
        }

        viewModelScope.launch {
            try {
                repository.updateRoomWithRename(oldRoomNumber, updatedRoom)
                _selectedRoomForDetails.value = updatedRoom
                _snackbarMessage.value = "Room details updated successfully."
                onSuccess()
            } catch (e: Exception) {
                onError("Failed to update room: ${e.message}")
            }
        }
    }

    fun updateRoomPricing(
        room: RoomEntity,
        onSuccess: () -> Unit,
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                repository.updateRoom(room)
                _selectedRoomForDetails.value = room
                _snackbarMessage.value = "Room pricing updated successfully."

                // If currently building a bill with this room, immediately update the price
                if (_newBillState.value.selectedRoomNumber == room.roomNumber) {
                    val newPrice = room.getPrice(_newBillState.value.guestsCount, _newBillState.value.stayType)
                    _newBillState.value = _newBillState.value.copy(
                        roomType = room.roomType,
                        overrideRoomCharge = newPrice
                    )
                }
                onSuccess()
            } catch (e: Exception) {
                onError("Failed to update pricing: ${e.message}")
            }
        }
    }

    // ==========================================
    // EXPENSES & FINANCIAL REPORTING
    // ==========================================

    val allExpenses: StateFlow<List<ExpenseEntity>> = repository.allExpensesFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _reportPeriod = MutableStateFlow(ReportPeriod.TODAY)
    val reportPeriod: StateFlow<ReportPeriod> = _reportPeriod.asStateFlow()

    private val _customFromDate = MutableStateFlow(ReportDateHelper.getToday())
    val customFromDate: StateFlow<String> = _customFromDate.asStateFlow()

    private val _customToDate = MutableStateFlow(ReportDateHelper.getToday())
    val customToDate: StateFlow<String> = _customToDate.asStateFlow()

    val showAddExpenseDialog = MutableStateFlow(false)
    val expenseToEdit = MutableStateFlow<ExpenseEntity?>(null)
    val expenseToDelete = MutableStateFlow<ExpenseEntity?>(null)

    fun setReportPeriod(period: ReportPeriod) {
        _reportPeriod.value = period
    }

    fun setCustomFromDate(date: String) {
        _customFromDate.value = date
    }

    fun setCustomToDate(date: String) {
        _customToDate.value = date
    }

    val reportData: StateFlow<FinancialReportData> = combine(
        _reportPeriod,
        _customFromDate,
        _customToDate,
        bills,
        allExpenses
    ) { period, customFrom, customTo, allBillsList, allExpensesList ->
        val (fromDate, toDate, title) = when (period) {
            ReportPeriod.TODAY -> {
                val today = ReportDateHelper.getToday()
                Triple(today, today, "TODAY (${ReportDateHelper.formatDisplayDate(today)})")
            }
            ReportPeriod.THIS_WEEK -> {
                val (wFrom, wTo) = ReportDateHelper.getThisWeekRange()
                Triple(wFrom, wTo, "THIS WEEK (${ReportDateHelper.formatDisplayDate(wFrom)} - ${ReportDateHelper.formatDisplayDate(wTo)})")
            }
            ReportPeriod.THIS_MONTH -> {
                val (mFrom, mTo) = ReportDateHelper.getThisMonthRange()
                Triple(mFrom, mTo, "THIS MONTH (${ReportDateHelper.formatDisplayDate(mFrom)} - ${ReportDateHelper.formatDisplayDate(mTo)})")
            }
            ReportPeriod.CUSTOM_DATE -> {
                val from = if (customFrom.isNotBlank()) customFrom else ReportDateHelper.getToday()
                val to = if (customTo.isNotBlank()) customTo else from
                Triple(from, to, "CUSTOM (${ReportDateHelper.formatDisplayDate(from)} - ${ReportDateHelper.formatDisplayDate(to)})")
            }
        }

        val filteredBills = allBillsList.filter { bill ->
            val bDate = if (bill.checkInDate.isNotBlank()) {
                bill.checkInDate
            } else {
                SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(bill.createdAt))
            }
            bDate in fromDate..toDate
        }

        val filteredExpenses = allExpensesList.filter { expense ->
            val eDate = if (expense.date.isNotBlank()) {
                expense.date
            } else {
                SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(expense.createdAt))
            }
            eDate in fromDate..toDate
        }

        // CRITICAL REQUIREMENT:
        // Income must come from payments recorded against saved bills.
        // Show: Total Income, Number of Bills, Total Paid, Outstanding Balance.
        // Do NOT count outstanding balance as income.
        // Only money actually received should be counted as income.
        val totalIncome = filteredBills.sumOf { it.paid }
        val totalExpenses = filteredExpenses.sumOf { it.amount }
        val netIncome = totalIncome - totalExpenses
        val outstanding = filteredBills.sumOf { it.balance }

        FinancialReportData(
            period = period,
            periodTitle = title,
            fromDate = fromDate,
            toDate = toDate,
            billsCount = filteredBills.size,
            totalIncome = totalIncome,
            totalExpenses = totalExpenses,
            netIncome = netIncome,
            outstandingBalance = outstanding,
            amountReceived = totalIncome,
            filteredBills = filteredBills,
            filteredExpenses = filteredExpenses
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FinancialReportData())

    init {
        viewModelScope.launch {
            repository.initDefaultRoomsIfNeeded()
        }
        viewModelScope.launch {
            rooms.collect { rList ->
                val currentNum = _newBillState.value.selectedRoomNumber
                val currentRoom = rList.find { it.roomNumber == currentNum }
                if (currentRoom != null) {
                    val updatedPrice = currentRoom.getPrice(
                        _newBillState.value.guestsCount,
                        _newBillState.value.stayType
                    )
                    _newBillState.value = _newBillState.value.copy(
                        roomType = currentRoom.roomType,
                        overrideRoomCharge = updatedPrice
                    )
                }
                // Keep selected room for details updated if modified
                val detailsNum = _selectedRoomForDetails.value?.roomNumber
                if (detailsNum != null) {
                    val updatedDetailsRoom = rList.find { it.roomNumber == detailsNum }
                    if (updatedDetailsRoom != null) {
                        _selectedRoomForDetails.value = updatedDetailsRoom
                    }
                }
            }
        }
    }

    fun saveExpense(
        id: Long = 0,
        category: String,
        description: String,
        amount: Double,
        date: String,
        note: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit = {}
    ) {
        if (category.isBlank()) {
            onError("Please select or enter an expense category.")
            return
        }
        if (description.isBlank()) {
            onError("Please enter a description for the expense.")
            return
        }
        if (amount <= 0) {
            onError("Amount must be greater than 0.")
            return
        }
        val cleanDate = date.ifBlank { ReportDateHelper.getToday() }

        viewModelScope.launch {
            try {
                val expense = ExpenseEntity(
                    id = id,
                    category = category.trim(),
                    description = description.trim(),
                    amount = amount,
                    date = cleanDate.trim(),
                    note = note.trim()
                )
                if (id == 0L) {
                    repository.insertExpense(expense)
                    _snackbarMessage.value = "Expense of ${PricingCalculator.formatCurrency(amount)} recorded."
                } else {
                    repository.updateExpense(expense)
                    _snackbarMessage.value = "Expense updated successfully."
                }
                showAddExpenseDialog.value = false
                expenseToEdit.value = null
                onSuccess()
            } catch (e: Exception) {
                onError("Failed to save expense: ${e.message}")
            }
        }
    }

    fun deleteExpense(
        expense: ExpenseEntity,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                repository.deleteExpense(expense)
                _snackbarMessage.value = "Expense deleted."
                expenseToDelete.value = null
                onSuccess()
            } catch (e: Exception) {
                _snackbarMessage.value = "Failed to delete expense: ${e.message}"
            }
        }
    }
}
