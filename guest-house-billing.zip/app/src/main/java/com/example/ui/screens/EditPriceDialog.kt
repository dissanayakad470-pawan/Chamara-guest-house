package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.RoomEntity
import com.example.data.RoomType
import com.example.ui.theme.CashierPrimary
import com.example.ui.theme.CleanBorder
import com.example.ui.theme.OccupiedRed
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900

@Composable
fun EditPriceDialog(
    room: RoomEntity,
    onDismiss: () -> Unit,
    onSavePrices: (RoomEntity) -> Unit
) {
    // Normal Room price text inputs
    var night1 by remember { mutableStateOf(room.nightPrice1.toLong().toString()) }
    var night2 by remember { mutableStateOf(room.nightPrice2.toLong().toString()) }
    var night3 by remember { mutableStateOf(room.nightPrice3.toLong().toString()) }
    var night4 by remember { mutableStateOf(room.nightPrice4.toLong().toString()) }
    var night5 by remember { mutableStateOf(room.nightPrice5.toLong().toString()) }

    var fullDay1 by remember { mutableStateOf(room.fullDayPrice1.toLong().toString()) }
    var fullDay2 by remember { mutableStateOf(room.fullDayPrice2.toLong().toString()) }
    var fullDay3 by remember { mutableStateOf(room.fullDayPrice3.toLong().toString()) }
    var fullDay4 by remember { mutableStateOf(room.fullDayPrice4.toLong().toString()) }
    var fullDay5 by remember { mutableStateOf(room.fullDayPrice5.toLong().toString()) }

    // Family Room price text inputs
    var familyNight by remember { mutableStateOf(room.familyNightPrice.toLong().toString()) }
    var familyFullDay by remember { mutableStateOf(room.familyFullDayPrice.toLong().toString()) }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 24.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, CleanBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "EDIT PRICES — ROOM ${room.roomNumber}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = Slate900
                        )
                        Text(
                            text = "Category: ${room.category} (${room.roomType.badgeText})",
                            fontSize = 12.sp,
                            color = Slate500
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Slate500)
                    }
                }

                HorizontalDivider(color = Slate200, thickness = 1.dp)

                errorMessage?.let { err ->
                    Text(
                        text = err,
                        color = OccupiedRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (room.roomType == RoomType.AC_FAMILY) {
                    // Family Room Fixed Pricing inputs
                    Text(
                        text = "AC FAMILY ROOM PRICING (FIXED)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = CashierPrimary,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Fixed room rate. Does not multiply by guest count.",
                        fontSize = 12.sp,
                        color = Slate500
                    )

                    PriceInputField(
                        label = "Fixed Night Price",
                        value = familyNight,
                        onValueChange = { familyNight = it },
                        testTag = "input_family_night"
                    )

                    PriceInputField(
                        label = "Fixed Full Day Price",
                        value = familyFullDay,
                        onValueChange = { familyFullDay = it },
                        testTag = "input_family_full_day"
                    )
                } else {
                    // Normal AC & Non-AC Room Pricing inputs
                    Text(
                        text = "NIGHT PRICES",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = CashierPrimary,
                        letterSpacing = 0.5.sp
                    )

                    PriceInputField(
                        label = "1 Person",
                        value = night1,
                        onValueChange = { night1 = it },
                        testTag = "input_night_1"
                    )
                    PriceInputField(
                        label = "2 Persons",
                        value = night2,
                        onValueChange = { night2 = it },
                        testTag = "input_night_2"
                    )
                    PriceInputField(
                        label = "3 Persons",
                        value = night3,
                        onValueChange = { night3 = it },
                        testTag = "input_night_3"
                    )
                    PriceInputField(
                        label = "4 Persons",
                        value = night4,
                        onValueChange = { night4 = it },
                        testTag = "input_night_4"
                    )
                    PriceInputField(
                        label = "5 Persons",
                        value = night5,
                        onValueChange = { night5 = it },
                        testTag = "input_night_5"
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    HorizontalDivider(color = Slate200, thickness = 1.dp)

                    Text(
                        text = "FULL DAY PRICES",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = CashierPrimary,
                        letterSpacing = 0.5.sp
                    )

                    PriceInputField(
                        label = "1 Person",
                        value = fullDay1,
                        onValueChange = { fullDay1 = it },
                        testTag = "input_fullday_1"
                    )
                    PriceInputField(
                        label = "2 Persons",
                        value = fullDay2,
                        onValueChange = { fullDay2 = it },
                        testTag = "input_fullday_2"
                    )
                    PriceInputField(
                        label = "3 Persons",
                        value = fullDay3,
                        onValueChange = { fullDay3 = it },
                        testTag = "input_fullday_3"
                    )
                    PriceInputField(
                        label = "4 Persons",
                        value = fullDay4,
                        onValueChange = { fullDay4 = it },
                        testTag = "input_fullday_4"
                    )
                    PriceInputField(
                        label = "5 Persons",
                        value = fullDay5,
                        onValueChange = { fullDay5 = it },
                        testTag = "input_fullday_5"
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Buttons: SAVE and CANCEL
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("btn_cancel_pricing"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("CANCEL", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            val n1 = night1.toDoubleOrNull()
                            val n2 = night2.toDoubleOrNull()
                            val n3 = night3.toDoubleOrNull()
                            val n4 = night4.toDoubleOrNull()
                            val n5 = night5.toDoubleOrNull()
                            val f1 = fullDay1.toDoubleOrNull()
                            val f2 = fullDay2.toDoubleOrNull()
                            val f3 = fullDay3.toDoubleOrNull()
                            val f4 = fullDay4.toDoubleOrNull()
                            val f5 = fullDay5.toDoubleOrNull()
                            val fn = familyNight.toDoubleOrNull()
                            val ff = familyFullDay.toDoubleOrNull()

                            if (room.roomType == RoomType.AC_FAMILY) {
                                if (fn == null || fn <= 0 || ff == null || ff <= 0) {
                                    errorMessage = "Please enter valid prices greater than 0."
                                    return@Button
                                }
                                val updated = room.copy(
                                    familyNightPrice = fn,
                                    familyFullDayPrice = ff
                                )
                                onSavePrices(updated)
                            } else {
                                if (n1 == null || n2 == null || n3 == null || n4 == null || n5 == null ||
                                    f1 == null || f2 == null || f3 == null || f4 == null || f5 == null) {
                                    errorMessage = "Please enter valid prices for all guest counts."
                                    return@Button
                                }
                                val updated = room.copy(
                                    nightPrice1 = n1,
                                    nightPrice2 = n2,
                                    nightPrice3 = n3,
                                    nightPrice4 = n4,
                                    nightPrice5 = n5,
                                    fullDayPrice1 = f1,
                                    fullDayPrice2 = f2,
                                    fullDayPrice3 = f3,
                                    fullDayPrice4 = f4,
                                    fullDayPrice5 = f5
                                )
                                onSavePrices(updated)
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("btn_save_pricing"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CashierPrimary)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("SAVE", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun PriceInputField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = Slate800,
            modifier = Modifier.width(100.dp)
        )
        OutlinedTextField(
            value = value,
            onValueChange = { newVal ->
                if (newVal.all { it.isDigit() }) {
                    onValueChange(newVal)
                }
            },
            leadingIcon = {
                Text("Rs.", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Slate500)
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier
                .weight(1f)
                .testTag(testTag),
            shape = RoundedCornerShape(8.dp)
        )
    }
}
