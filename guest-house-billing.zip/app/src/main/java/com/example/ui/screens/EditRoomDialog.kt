package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.RoomEntity
import com.example.data.RoomType
import com.example.ui.theme.AvailableGreen
import com.example.ui.theme.CashierPrimary
import com.example.ui.theme.CleanBorder
import com.example.ui.theme.OccupiedRed
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900

@Composable
fun EditRoomDialog(
    room: RoomEntity,
    existingRoomNumbers: List<String>,
    onDismiss: () -> Unit,
    onSave: (oldNumber: String, updatedRoom: RoomEntity) -> Unit
) {
    var roomNumber by remember { mutableStateOf(room.roomNumber) }
    var category by remember { mutableStateOf(room.category) }
    var selectedType by remember { mutableStateOf(room.roomType) }
    var maxGuests by remember { mutableIntStateOf(room.maxGuests) }
    var description by remember { mutableStateOf(room.description) }
    var amenities by remember { mutableStateOf(room.amenities) }
    var isActive by remember { mutableStateOf(room.isActive) }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 24.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, CleanBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "EDIT ROOM ${room.roomNumber}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = Slate900
                        )
                        Text(
                            text = "Modify room specifications & facilities",
                            fontSize = 12.sp,
                            color = Slate500
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Slate500)
                    }
                }

                HorizontalDivider(color = Slate200, thickness = 1.dp)

                errorMessage?.let { err ->
                    Text(
                        text = err,
                        color = OccupiedRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.testTag("edit_room_error_message")
                    )
                }

                // 1. Room Number
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("ROOM NUMBER", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Slate700)
                    OutlinedTextField(
                        value = roomNumber,
                        onValueChange = {
                            roomNumber = it.trim()
                            errorMessage = null
                        },
                        placeholder = { Text("e.g. 02") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_edit_room_number"),
                        shape = RoundedCornerShape(8.dp)
                    )
                    Text(
                        text = "Note: Room 12 does not exist and cannot be used.",
                        fontSize = 11.sp,
                        color = Slate500
                    )
                }

                // 2. Room Category
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("ROOM CATEGORY", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Slate700)
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        placeholder = { Text("e.g. Deluxe AC, Standard Non-AC, Family Suite") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_edit_room_category"),
                        shape = RoundedCornerShape(8.dp)
                    )
                }

                // 3. Room Type: AC / NON-AC / AC FAMILY
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("ROOM TYPE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Slate700)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RoomType.values().forEach { type ->
                            val isSelected = selectedType == type
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedType = type },
                                label = { Text(type.badgeText, fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CashierPrimary,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.weight(1f).testTag("chip_type_${type.name}")
                            )
                        }
                    }
                }

                // 4. Maximum Guests
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("MAXIMUM GUESTS: $maxGuests Persons", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Slate700)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        (1..8).forEach { num ->
                            val isSelected = maxGuests == num
                            FilterChip(
                                selected = isSelected,
                                onClick = { maxGuests = num },
                                label = { Text("$num", fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CashierPrimary,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // 5. Facilities / Amenities
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("FACILITIES / AMENITIES", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Slate700)
                    OutlinedTextField(
                        value = amenities,
                        onValueChange = { amenities = it },
                        placeholder = { Text("e.g. AC, Free WiFi, Hot Water, TV, Attached Bathroom") },
                        singleLine = false,
                        maxLines = 2,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_edit_room_amenities"),
                        shape = RoundedCornerShape(8.dp)
                    )
                }

                // 6. Room Description
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("ROOM DESCRIPTION", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Slate700)
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        placeholder = { Text("Short description of the room...") },
                        singleLine = false,
                        maxLines = 3,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_edit_room_description"),
                        shape = RoundedCornerShape(8.dp)
                    )
                }

                // 7. Active / Inactive
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ROOM STATUS",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Slate700
                        )
                        Text(
                            text = if (isActive) "Active (Available for booking)" else "Inactive (Disabled/Under Maintenance)",
                            fontSize = 12.sp,
                            color = if (isActive) AvailableGreen else Slate500
                        )
                    }

                    Switch(
                        checked = isActive,
                        onCheckedChange = { isActive = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = AvailableGreen),
                        modifier = Modifier.testTag("switch_room_active")
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Action Buttons: SAVE and CANCEL
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("btn_cancel_edit_room"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("CANCEL", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            val cleanNumber = roomNumber.trim()
                            if (cleanNumber.isBlank()) {
                                errorMessage = "Room Number cannot be empty."
                                return@Button
                            }
                            if (cleanNumber == "12" || cleanNumber == "012") {
                                errorMessage = "Room 12 does NOT exist and cannot be created."
                                return@Button
                            }
                            if (cleanNumber != room.roomNumber && existingRoomNumbers.contains(cleanNumber)) {
                                errorMessage = "Room $cleanNumber already exists."
                                return@Button
                            }

                            val updated = room.copy(
                                roomNumber = cleanNumber,
                                category = category.ifBlank { "Standard" },
                                roomType = selectedType,
                                maxGuests = maxGuests,
                                description = description,
                                amenities = amenities,
                                isActive = isActive
                            )
                            onSave(room.roomNumber, updated)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("btn_save_edit_room"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CashierPrimary)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("SAVE", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
