package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.RoomEntity
import com.example.data.RoomStatus
import com.example.data.RoomType
import com.example.ui.components.RoomStatusBadge
import com.example.ui.components.RoomTypeBadge
import com.example.ui.theme.AvailableGreen
import com.example.ui.theme.AvailableGreenBg
import com.example.ui.theme.CashierPrimary
import com.example.ui.theme.CleanBorder
import com.example.ui.theme.CleanSurface
import com.example.ui.theme.CleanTextPrimary
import com.example.ui.theme.CleanTextSecondary
import com.example.ui.theme.OccupiedRed
import com.example.ui.theme.OccupiedRedBg
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate50
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.util.PricingCalculator

@Composable
fun RoomDetailsScreen(
    room: RoomEntity,
    onBackClick: () -> Unit,
    onEditRoomClick: () -> Unit,
    onEditPricesClick: () -> Unit,
    onCreateBillClick: () -> Unit,
    onCheckoutClick: () -> Unit,
    confirmationMessage: String? = null,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CleanSurface)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Navigation Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("btn_back_room_details")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = CleanTextPrimary
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "Room ${room.roomNumber} Details",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = CleanTextPrimary
                    )
                    Text(
                        text = "Management & Room Pricing",
                        fontSize = 12.sp,
                        color = CleanTextSecondary
                    )
                }
            }

            RoomStatusBadge(status = room.status)
        }

        // Confirmation Banner if just updated
        confirmationMessage?.let { msg ->
            Surface(
                color = AvailableGreenBg,
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, AvailableGreen),
                modifier = Modifier.fillMaxWidth().testTag("confirmation_banner")
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = AvailableGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = msg,
                        color = AvailableGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Room Main Info Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, CleanBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ROOM ${room.roomNumber}",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = Slate900,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = room.category,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Slate700
                        )
                    }

                    RoomTypeBadge(roomType = room.roomType)
                }

                HorizontalDivider(color = Slate200, thickness = 1.dp)

                // Attributes
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("MAX GUESTS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate500)
                        Text("${room.maxGuests} Persons", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Slate800)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("STATUS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate500)
                        Text(if (room.isActive) "Active" else "Inactive", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (room.isActive) AvailableGreen else Slate500)
                    }
                }

                if (room.amenities.isNotBlank()) {
                    Column {
                        Text("FACILITIES & AMENITIES", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate500)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(room.amenities, fontSize = 13.sp, color = Slate800)
                    }
                }

                if (room.description.isNotBlank()) {
                    Column {
                        Text("DESCRIPTION", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate500)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(room.description, fontSize = 13.sp, color = Slate700)
                    }
                }

                // Edit Room Button
                Button(
                    onClick = onEditRoomClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("btn_edit_room"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Slate100,
                        contentColor = Slate900
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate200)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "EDIT ROOM",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Current Prices Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, CleanBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Current Prices",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Slate900
                        )
                        Text(
                            text = "Active rates applied to all new bills",
                            fontSize = 12.sp,
                            color = Slate500
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.Payment,
                        contentDescription = null,
                        tint = CashierPrimary
                    )
                }

                HorizontalDivider(color = Slate200, thickness = 1.dp)

                if (room.roomType == RoomType.AC_FAMILY) {
                    // AC FAMILY Room Pricing
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "NIGHT",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = CashierPrimary,
                            letterSpacing = 1.sp
                        )
                        PriceRow(label = "Fixed Night Price", amount = room.familyNightPrice)

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "FULL DAY",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = CashierPrimary,
                            letterSpacing = 1.sp
                        )
                        PriceRow(label = "Fixed Full Day Price", amount = room.familyFullDayPrice)

                        Surface(
                            color = Slate50,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                        ) {
                            Text(
                                text = "ℹ️ Family room price is fixed and does not automatically multiply by guest count.",
                                fontSize = 11.sp,
                                color = Slate700,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                } else {
                    // Normal AC & Non-AC Room Pricing (1 to 5 Persons)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "NIGHT",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = CashierPrimary,
                            letterSpacing = 1.sp
                        )
                        PriceRow(label = "1 Person", amount = room.nightPrice1)
                        PriceRow(label = "2 Persons", amount = room.nightPrice2)
                        PriceRow(label = "3 Persons", amount = room.nightPrice3)
                        PriceRow(label = "4 Persons", amount = room.nightPrice4)
                        PriceRow(label = "5 Persons", amount = room.nightPrice5)

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "FULL DAY",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = CashierPrimary,
                            letterSpacing = 1.sp
                        )
                        PriceRow(label = "1 Person", amount = room.fullDayPrice1)
                        PriceRow(label = "2 Persons", amount = room.fullDayPrice2)
                        PriceRow(label = "3 Persons", amount = room.fullDayPrice3)
                        PriceRow(label = "4 Persons", amount = room.fullDayPrice4)
                        PriceRow(label = "5 Persons", amount = room.fullDayPrice5)
                    }
                }

                // Edit Prices Button
                Button(
                    onClick = onEditPricesClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_edit_prices"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CashierPrimary,
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "EDIT PRICES",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        // Action Button: Create Bill or Checkout
        if (room.status == RoomStatus.AVAILABLE) {
            Button(
                onClick = onCreateBillClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("btn_create_bill_for_room"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AvailableGreen)
            ) {
                Icon(Icons.Default.AddCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Create Bill for Room ${room.roomNumber}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        } else {
            Button(
                onClick = onCheckoutClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("btn_checkout_for_room"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = OccupiedRed)
            ) {
                Icon(Icons.Default.Payment, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("View Bill / Checkout Room ${room.roomNumber}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }
}

@Composable
private fun PriceRow(label: String, amount: Double) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            color = Slate700
        )
        Text(
            text = PricingCalculator.formatCurrency(amount),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Slate900
        )
    }
}
