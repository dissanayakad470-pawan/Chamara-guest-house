package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ExpenseCategories
import com.example.data.ExpenseEntity
import com.example.ui.theme.CashierPrimary
import com.example.ui.theme.CleanBorder
import com.example.ui.theme.CleanSurface
import com.example.ui.theme.CleanTextPrimary
import com.example.ui.theme.CleanTextSecondary
import com.example.util.ReportDateHelper

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEditExpenseDialog(
    expenseToEdit: ExpenseEntity? = null,
    onDismiss: () -> Unit,
    onSaveExpense: (
        id: Long,
        category: String,
        description: String,
        amount: Double,
        date: String,
        note: String
    ) -> Unit
) {
    val isEditMode = expenseToEdit != null

    var selectedCategory by remember {
        mutableStateOf(expenseToEdit?.category ?: ExpenseCategories.DEFAULT.first())
    }
    var customCategoryText by remember {
        mutableStateOf(
            if (expenseToEdit != null && expenseToEdit.category !in ExpenseCategories.DEFAULT) {
                expenseToEdit.category
            } else ""
        )
    }
    var description by remember { mutableStateOf(expenseToEdit?.description ?: "") }
    var amountText by remember {
        mutableStateOf(if (expenseToEdit != null) expenseToEdit.amount.toLong().toString() else "")
    }
    var dateText by remember {
        mutableStateOf(expenseToEdit?.date ?: ReportDateHelper.getToday())
    }
    var noteText by remember { mutableStateOf(expenseToEdit?.note ?: "") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val isCustomCategory = selectedCategory == "Other" || selectedCategory !in ExpenseCategories.DEFAULT

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 16.dp)
                .testTag("add_expense_dialog"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CleanSurface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFFEF3C7)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ReceiptLong,
                                contentDescription = null,
                                tint = Color(0xFFD97706),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (isEditMode) "Edit Expense" else "Add New Expense",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = CleanTextPrimary
                            )
                            Text(
                                text = "Record guest house operational costs",
                                fontSize = 11.sp,
                                color = CleanTextSecondary
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = CleanTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = CleanBorder, thickness = 1.dp)
                Spacer(modifier = Modifier.height(14.dp))

                // Category Section
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Category,
                        contentDescription = null,
                        tint = CashierPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Expense Category *",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = CleanTextPrimary
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ExpenseCategories.DEFAULT.forEach { cat ->
                        val isSelected = (selectedCategory == cat) && (!isCustomCategory || cat == "Other")
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) CashierPrimary else Color(0xFFF1F5F9),
                            modifier = Modifier
                                .clickable {
                                    selectedCategory = cat
                                    if (cat != "Other") {
                                        customCategoryText = ""
                                    }
                                }
                                .testTag("cat_chip_$cat")
                        ) {
                            Text(
                                text = cat,
                                color = if (isSelected) Color.White else CleanTextPrimary,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                            )
                        }
                    }
                }

                // If "Other" or custom category is active, show custom category textfield
                if (selectedCategory == "Other" || isCustomCategory) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = customCategoryText,
                        onValueChange = { customCategoryText = it },
                        label = { Text("Custom Category Name *", fontSize = 12.sp) },
                        placeholder = { Text("e.g. Laundry, Gas Cylinder, License", fontSize = 12.sp) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_custom_category"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CashierPrimary,
                            unfocusedBorderColor = CleanBorder
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Description
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description *", fontSize = 12.sp) },
                    placeholder = { Text("e.g. August CEB Electricity bill, Room 03 Plumbing repair", fontSize = 12.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Description,
                            contentDescription = null,
                            tint = CashierPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_expense_desc"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CashierPrimary,
                        unfocusedBorderColor = CleanBorder
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Amount
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { input ->
                        if (input.all { it.isDigit() || it == '.' }) {
                            amountText = input
                        }
                    },
                    label = { Text("Amount (Rs.) *", fontSize = 12.sp) },
                    placeholder = { Text("e.g. 8500", fontSize = 12.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Paid,
                            contentDescription = null,
                            tint = Color(0xFFD97706),
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_expense_amount"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CashierPrimary,
                        unfocusedBorderColor = CleanBorder
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Date
                OutlinedTextField(
                    value = dateText,
                    onValueChange = { dateText = it },
                    label = { Text("Date (YYYY-MM-DD) *", fontSize = 12.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = CashierPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    trailingIcon = {
                        Text(
                            text = "TODAY",
                            color = CashierPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clickable { dateText = ReportDateHelper.getToday() }
                                .padding(end = 12.dp)
                        )
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_expense_date"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CashierPrimary,
                        unfocusedBorderColor = CleanBorder
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Note (Optional)
                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    label = { Text("Note (Optional)", fontSize = 12.sp) },
                    placeholder = { Text("e.g. Receipt voucher #104, Paid in cash", fontSize = 12.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.EditNote,
                            contentDescription = null,
                            tint = CleanTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    maxLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_expense_note"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CashierPrimary,
                        unfocusedBorderColor = CleanBorder
                    )
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMessage!!,
                        color = Color(0xFFDC2626),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CleanTextSecondary)
                    ) {
                        Text("CANCEL", fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = {
                            val finalCat = if (selectedCategory == "Other" || isCustomCategory) {
                                customCategoryText.trim().ifBlank { "Other" }
                            } else {
                                selectedCategory
                            }
                            val amt = amountText.toDoubleOrNull() ?: 0.0

                            if (description.isBlank()) {
                                errorMessage = "Please enter a description for the expense."
                                return@Button
                            }
                            if (amt <= 0) {
                                errorMessage = "Please enter a valid amount greater than 0."
                                return@Button
                            }
                            if (dateText.isBlank()) {
                                errorMessage = "Please enter a valid date."
                                return@Button
                            }

                            errorMessage = null
                            onSaveExpense(
                                expenseToEdit?.id ?: 0L,
                                finalCat,
                                description.trim(),
                                amt,
                                dateText.trim(),
                                noteText.trim()
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag("btn_save_expense"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CashierPrimary)
                    ) {
                        Text(
                            text = if (isEditMode) "UPDATE" else "SAVE EXPENSE",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}
