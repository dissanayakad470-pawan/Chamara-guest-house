package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Color Tokens
val CleanBg = Color(0xFFF3F4F9)
val CleanSurface = Color(0xFFFFFFFF)
val CleanTextPrimary = Color(0xFF1B1B1F)
val CleanTextSecondary = Color(0xFF44474E)
val CleanBorder = Color(0xFFE1E2EC)
val CleanBorderLight = Color(0xFFF0F1F7)

// Brand Accents
val CashierPrimary = Color(0xFF005FB0) // Clean Blue
val CashierPrimaryVariant = Color(0xFF004A8A) // Darker active Blue
val CashierSecondary = Color(0xFF2563EB) // Accent Blue
val CashierTertiary = Color(0xFF006874)

val CleanBluePill = Color(0xFFD3E4FF) // Navigation / Selected Pill

// Status colors
val AvailableGreen = Color(0xFF386A20) // Clean Forest Green for available
val AvailableGreenDot = Color(0xFF22C55E) // Bright Green Pulse/Dot
val AvailableGreenBg = Color(0xFFF0FDF4)
val AvailableGreenBorder = Color(0xFFDCFCE7)

val OccupiedRed = Color(0xFFBA1A1A) // Clean Bold Red for occupied
val OccupiedRedBg = Color(0xFFFFEDEC)
val OccupiedRedBorder = Color(0xFFFEE2E2)

// Family Room Accent
val FamilyBlue = Color(0xFF2563EB)
val FamilyGold = Color(0xFF2563EB)
val FamilyGoldBg = Color(0xFFEFF6FF)

// Slate aliases mapped to Clean Minimalism tokens
val Slate50 = CleanBg
val Slate100 = Color(0xFFEBEDF5)
val Slate200 = CleanBorder
val Slate300 = Color(0xFFC5C6D0)
val Slate500 = CleanTextSecondary
val Slate700 = Color(0xFF303237)
val Slate800 = Color(0xFF232529)
val Slate900 = CleanTextPrimary
