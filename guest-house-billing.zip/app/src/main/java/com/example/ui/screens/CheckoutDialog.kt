package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BillEntity
import com.example.data.RoomEntity
import com.example.ui.components.RoomTypeBadge
import com.example.ui.theme.AvailableGreen
import com.example.ui.theme.CashierPrimary
import com.example.ui.theme.OccupiedRed
import com.example.ui.theme.OccupiedRedBg
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate900
import com.example.util.PricingCalculator

@Composable
fun CheckoutDialog(
    room: RoomEntity,
    bill: BillEntity?,
    onDismiss: () -> Unit,
    onConfirmCheckout: (additionalPayment: Double) -> Unit,
    onViewBill: (BillEntity) -> Unit
) {
    if (bill == null) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Room ${room.roomNumber}") },
            text = { Text("No active bill found for this room. Mark as Available?") },
            confirmButton = {
                Button(
                    onClick = { onConfirmCheckout(0.0) },
                    colors = ButtonDefaults.buttonColors(containerColor = AvailableGreen)
                ) {
                    Text("Make Available")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = onDismiss) { Text("Cancel") }
            }
        )
        return
    }

    var paymentInput by remember {
        mutableStateOf(if (bill.balance > 0) bill.balance.toLong().toString() else "0")
    }

    val inputAmount = paymentInput.toDoubleOrNull() ?: 0.0
    val finalBalance = (bill.balance - inputAmount).coerceAtLeast(0.0)

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("checkout_dialog"),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Checkout Room ${room.roomNumber}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Slate900
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    RoomTypeBadge(roomType = room.roomType)
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Customer summary card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Slate100),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Guest: ${bill.customerName}",
                                fontWeight = FontWeight.SemiBold,
                                color = Slate900,
                                fontSize = 15.sp
                            )
                            Text(
                                text = bill.billNumber,
                                fontSize = 12.sp,
                                color = Slate500,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "NIC: ${bill.customerNic} | Phone: ${bill.customerPhone.ifBlank { "N/A" }}",
                            fontSize = 12.sp,
                            color = Slate700
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Stay: ${bill.stayType.displayName} (${bill.guestsCount} guests) | In: ${bill.checkInDate}",
                            fontSize = 12.sp,
                            color = Slate700
                        )
                    }
                }

                // Balance Notice
                if (bill.balance > 0) {
                    Surface(
                        color = OccupiedRedBg,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "BALANCE DUE",
                                color = OccupiedRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = PricingCalculator.formatCurrency(bill.balance),
                                color = OccupiedRed,
                                fontWeight = FontWeight.Black,
                                fontSize = 24.sp
                            )
                        }
                    }

                    OutlinedTextField(
                        value = paymentInput,
                        onValueChange = { paymentInput = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Enter Final Payment (Rs.)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("checkout_payment_input"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        leadingIcon = {
                            Icon(Icons.Default.Payment, contentDescription = null, tint = CashierPrimary)
                        },
                        trailingIcon = {
                            if (paymentInput != bill.balance.toString()) {
                                Text(
                                    text = "Pay Full",
                                    color = CashierPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(end = 8.dp)
                                        .clickable {
                                            paymentInput = bill.balance.toLong().toString()
                                        }
                                )
                            }
                        }
                    )

                    if (finalBalance > 0.0) {
                        Text(
                            text = "Remaining after payment: ${PricingCalculator.formatCurrency(finalBalance)}",
                            fontSize = 12.sp,
                            color = OccupiedRed,
                            fontWeight = FontWeight.SemiBold
                        )
                    } else {
                        Text(
                            text = "✓ Bill will be fully paid and settled.",
                            fontSize = 12.sp,
                            color = AvailableGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Surface(
                        color = Color(0xFFDCFCE7),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AvailableGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Bill is Fully Paid",
                                    fontWeight = FontWeight.Bold,
                                    color = AvailableGreen,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "Total paid: ${PricingCalculator.formatCurrency(bill.paid)}",
                                    fontSize = 12.sp,
                                    color = Slate700
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirmCheckout(inputAmount)
                },
                modifier = Modifier.testTag("confirm_checkout_button"),
                colors = ButtonDefaults.buttonColors(containerColor = AvailableGreen)
            ) {
                Text(
                    text = "CHECKOUT & FREE ROOM",
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = {
                    onViewBill(bill)
                    onDismiss()
                }
            ) {
                Text("View Full Bill")
            }
        }
    )
}
