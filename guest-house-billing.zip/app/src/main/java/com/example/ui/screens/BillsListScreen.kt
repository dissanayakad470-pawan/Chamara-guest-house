package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BillEntity
import com.example.data.BillStatus
import com.example.ui.components.RoomTypeBadge
import com.example.ui.theme.AvailableGreen
import com.example.ui.theme.AvailableGreenBg
import com.example.ui.theme.CashierPrimary
import com.example.ui.theme.OccupiedRed
import com.example.ui.theme.OccupiedRedBg
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate50
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate900
import com.example.util.PricingCalculator

@Composable
fun BillsListScreen(
    bills: List<BillEntity>,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onBillClick: (BillEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Slate50)
            .padding(16.dp)
    ) {
        // Title
        Text(
            text = "Previous Bills",
            fontSize = 22.sp,
            fontWeight = FontWeight.Black,
            color = Slate900
        )
        Text(
            text = "Total ${bills.size} recorded bills",
            fontSize = 13.sp,
            color = Slate500
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Search Field (by Bill #, Customer Name, NIC, Room #)
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("bill_search_input"),
            placeholder = { Text("Search by Bill #, Customer, NIC, Room...") },
            singleLine = true,
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = "Search", tint = Slate500)
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchChange("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Slate500)
                    }
                }
            },
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(14.dp))

        // List of Bills
        if (bills.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.Receipt,
                        contentDescription = null,
                        modifier = Modifier.height(56.dp),
                        tint = Slate500
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (searchQuery.isNotEmpty()) "No bills match '$searchQuery'" else "No bills created yet",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Slate700,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(bills, key = { it.id }) { bill ->
                    BillListItemCard(
                        bill = bill,
                        onClick = { onBillClick(bill) }
                    )
                }
            }
        }
    }
}

@Composable
fun BillListItemCard(
    bill: BillEntity,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isPaid = bill.balance <= 0.0

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("bill_item_${bill.billNumber}")
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Slate200),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Row 1: Bill Number, Room Badge, Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = bill.billNumber,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        color = CashierPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = Slate100,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "Rm ${bill.roomNumber}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Slate900,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(
                    text = bill.checkInDate,
                    fontSize = 12.sp,
                    color = Slate500,
                    fontWeight = FontWeight.Medium
                )
            }

            // Row 2: Customer Name & NIC
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = bill.customerName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Slate900
                    )
                    Text(
                        text = "NIC: ${bill.customerNic} • Phone: ${bill.customerPhone.ifBlank { "N/A" }}",
                        fontSize = 12.sp,
                        color = Slate500
                    )
                }
                RoomTypeBadge(roomType = bill.roomType)
            }

            // Row 3: Total, Paid, Balance
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Slate100, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "TOTAL", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Slate500)
                    Text(
                        text = PricingCalculator.formatCurrency(bill.total),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Slate900
                    )
                }

                Column {
                    Text(text = "PAID", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Slate500)
                    Text(
                        text = PricingCalculator.formatCurrency(bill.paid),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0284C7)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = if (isPaid) "SETTLED" else "BALANCE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isPaid) AvailableGreen else OccupiedRed
                    )
                    Text(
                        text = PricingCalculator.formatCurrency(bill.balance),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isPaid) AvailableGreen else OccupiedRed
                    )
                }
            }
        }
    }
}
