package com.example.ui.screens

import android.app.Activity
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.BillEntity
import com.example.data.BillItemEntity
import com.example.ui.theme.AvailableGreen
import com.example.ui.theme.CashierPrimary
import com.example.ui.theme.OccupiedRed
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate200
import com.example.ui.theme.Slate50
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.util.PdfInvoiceGenerator
import com.example.util.PricingCalculator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun BillDetailScreen(
    bill: BillEntity,
    items: List<BillItemEntity>,
    onBackClick: () -> Unit,
    onNewBillClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val scrollState = rememberScrollState()

    // Automatically ensure the PDF is generated offline upon viewing/saving
    LaunchedEffect(bill.id) {
        withContext(Dispatchers.IO) {
            try {
                PdfInvoiceGenerator.generatePdf(context, bill, items)
            } catch (_: Exception) {
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Slate50)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Navigation Header with BACK button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("bill_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "BACK",
                        tint = Slate900
                    )
                }
                Text(
                    text = "BACK",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Slate700
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "BILL PREVIEW",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = Slate900
                )
                Text(
                    text = bill.billNumber,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = CashierPrimary
                )
            }
        }

        // ==========================================
        // PRIMARY ACTION: LARGE PROMINENT SHARE BUTTON
        // ==========================================
        Button(
            onClick = {
                PdfInvoiceGenerator.sharePdf(context, bill, items)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .testTag("bill_share_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)), // Vibrant Emerald / Teal
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 5.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = "SHARE BILL (PDF)",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "WhatsApp • Messenger • Gmail • Bluetooth • Drive",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFFCCFBF1)
                    )
                }
            }
        }

        // ==========================================
        // ACTION BUTTONS: [PRINT] and [SAVE PDF]
        // ==========================================
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    activity?.let {
                        PdfInvoiceGenerator.printPdf(it, bill, items)
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .testTag("bill_print_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CashierPrimary)
            ) {
                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("PRINT", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = {
                    val resultMessage = PdfInvoiceGenerator.savePdfToStorage(context, bill, items)
                    Toast.makeText(context, resultMessage, Toast.LENGTH_LONG).show()
                },
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .testTag("bill_save_pdf_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)) // Sky Blue
            ) {
                Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("SAVE PDF", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = onNewBillClick,
                modifier = Modifier
                    .weight(0.9f)
                    .height(46.dp)
                    .testTag("bill_new_button"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("NEW", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        // ==========================================
        // MOBILE-FRIENDLY BILL PREVIEW PAPER CARD
        // ==========================================
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("bill_preview_card"),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate200),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header with Emblem & Guest House Title
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Slate900),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "GH",
                            color = Color(0xFFF59E0B),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "GUEST HOUSE",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = Slate900,
                            letterSpacing = 1.5.sp
                        )
                        Text(
                            text = "Official Cashier Receipt & Invoice",
                            fontSize = 11.sp,
                            color = Slate500
                        )
                    }
                }

                HorizontalDivider(color = Slate900, thickness = 2.dp)

                // Meta row: Bill Number & Date
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "BILL NUMBER", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Slate500)
                        Text(text = bill.billNumber, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = CashierPrimary)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "DATE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Slate500)
                        Text(text = bill.checkInDate, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Slate900)
                    }
                }

                HorizontalDivider(color = Slate200)

                // Customer section with Photo
                Text(
                    text = "CUSTOMER INFORMATION",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Slate500,
                    letterSpacing = 0.5.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        BillRow(label = "Customer Name:", value = bill.customerName)
                        BillRow(label = "NIC / ID Number:", value = bill.customerNic)
                        BillRow(label = "Phone Number:", value = bill.customerPhone.ifBlank { "N/A" })
                        BillRow(label = "Payment Method:", value = bill.paymentMethod.displayName, valueColor = Color(0xFF0284C7))
                    }

                    // Customer ID photo thumbnail if present
                    bill.customerPhotoPath?.let { path ->
                        val file = File(path)
                        if (file.exists()) {
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                AsyncImage(
                                    model = file,
                                    contentDescription = "Customer Photo",
                                    modifier = Modifier
                                        .size(72.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(1.dp, Slate200, RoundedCornerShape(8.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "ID Photo",
                                    fontSize = 9.sp,
                                    color = Slate500,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                HorizontalDivider(color = Slate200)

                // Stay & Room details
                Text(
                    text = "ROOM & STAY DETAILS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Slate500,
                    letterSpacing = 0.5.sp
                )

                BillRow(label = "Room Number:", value = "Room ${bill.roomNumber} (${bill.roomType.badgeText})")
                BillRow(label = "Room Type:", value = bill.roomType.displayName)
                BillRow(label = "Number of Guests:", value = "${bill.guestsCount} Person(s)")
                BillRow(label = "Stay Type:", value = bill.stayType.displayName)
                BillRow(label = "Check-in:", value = "${bill.checkInDate} at ${bill.checkInTime}")
                BillRow(label = "Check-out:", value = "${bill.checkOutDate} at ${bill.checkOutTime}")

                HorizontalDivider(color = Slate200)

                // Charges breakdown
                Text(
                    text = "BILLING BREAKDOWN",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Slate500,
                    letterSpacing = 0.5.sp
                )

                BillRow(
                    label = "Room Charge:",
                    value = PricingCalculator.formatCurrency(bill.roomCharge),
                    isBold = true
                )

                if (items.isNotEmpty()) {
                    Text(
                        text = "Extra Charges:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Slate700,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    items.forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "• ${item.description} (${item.category})",
                                fontSize = 13.sp,
                                color = Slate700
                            )
                            Text(
                                text = PricingCalculator.formatCurrency(item.amount),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = Slate900
                            )
                        }
                    }
                }

                if (bill.discount > 0.0) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Discount:",
                            fontSize = 14.sp,
                            color = AvailableGreen,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "-${PricingCalculator.formatCurrency(bill.discount)}",
                            fontSize = 14.sp,
                            color = AvailableGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                HorizontalDivider(color = Slate800, thickness = 2.dp)

                // TOTAL
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TOTAL",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = Slate900
                    )
                    Text(
                        text = PricingCalculator.formatCurrency(bill.total),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = Slate900
                    )
                }

                // PAID
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PAID (${bill.paymentMethod.displayName})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0284C7)
                    )
                    Text(
                        text = PricingCalculator.formatCurrency(bill.paid),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0284C7)
                    )
                }

                // BALANCE
                val isBalanceZero = bill.balance <= 0.0
                val balanceColor = if (isBalanceZero) AvailableGreen else OccupiedRed
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isBalanceZero) "BALANCE (SETTLED)" else "BALANCE DUE",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = balanceColor
                    )
                    Text(
                        text = PricingCalculator.formatCurrency(bill.balance),
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = balanceColor
                    )
                }

                HorizontalDivider(color = Slate200)

                // Footer note
                Text(
                    text = "Thank you for staying with us! Please retain this bill for your records.",
                    fontSize = 11.sp,
                    color = Slate500,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // ==========================================
        // BOTTOM ACTION: ADDITIONAL LARGE SHARE BUTTON
        // ==========================================
        Button(
            onClick = {
                PdfInvoiceGenerator.sharePdf(context, bill, items)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("bill_share_bottom_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
        ) {
            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "SHARE BILL (PDF)",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun BillRow(
    label: String,
    value: String,
    isBold: Boolean = false,
    valueColor: Color = Slate900
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 13.sp, color = Slate500)
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.SemiBold,
            color = valueColor
        )
    }
}
