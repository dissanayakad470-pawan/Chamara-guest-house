package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @get:Rule
  val composeTestRule = createAndroidComposeRule<MainActivity>()

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Guest House Billing", appName)
  }

  @Test
  fun `verify all main tabs and screens load without crashing`() {
    // 1. Home screen loads
    composeTestRule.onNodeWithTag("nav_home").assertIsDisplayed()

    // 2. Rooms screen loads
    composeTestRule.onNodeWithTag("nav_rooms").performClick()
    composeTestRule.waitForIdle()

    // 3. New Bill screen loads
    composeTestRule.onNodeWithTag("nav_new_bill").performClick()
    composeTestRule.waitForIdle()

    // 4. Bills screen loads
    composeTestRule.onNodeWithTag("nav_bills").performClick()
    composeTestRule.waitForIdle()

    // 5. Customers screen loads
    composeTestRule.onNodeWithTag("nav_customers").performClick()
    composeTestRule.waitForIdle()

    // 6. Reports screen loads
    composeTestRule.onNodeWithTag("nav_reports").performClick()
    composeTestRule.waitForIdle()

    // 7. Back to Home
    composeTestRule.onNodeWithTag("nav_home").performClick()
    composeTestRule.waitForIdle()
  }
}
