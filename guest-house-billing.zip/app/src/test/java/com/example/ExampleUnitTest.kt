package com.example

import com.example.data.AppDatabase
import com.example.data.RoomType
import com.example.data.StayType
import com.example.util.PricingCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testRoomListConfiguration() {
        val rooms = AppDatabase.DEFAULT_ROOMS
        // Exactly 13 rooms
        assertEquals(13, rooms.size)

        val roomNumbers = rooms.map { it.roomNumber }
        val expectedNumbers = listOf("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "13", "14")
        assertEquals(expectedNumbers, roomNumbers)

        // Room 12 does NOT exist
        assertFalse(roomNumbers.contains("12"))

        // AC rooms: 02, 03, 06, 07, 08, 14
        val acRooms = rooms.filter { it.roomType == RoomType.AC }.map { it.roomNumber }
        assertEquals(listOf("02", "03", "06", "07", "08", "14"), acRooms)

        // AC Family rooms: 09, 13
        val familyRooms = rooms.filter { it.roomType == RoomType.AC_FAMILY }.map { it.roomNumber }
        assertEquals(listOf("09", "13"), familyRooms)

        // Non-AC rooms: 01, 04, 05, 10, 11
        val nonAcRooms = rooms.filter { it.roomType == RoomType.NON_AC }.map { it.roomNumber }
        assertEquals(listOf("01", "04", "05", "10", "11"), nonAcRooms)
    }

    @Test
    fun testAcRoomPricing() {
        // 1 person: Night 3000, Full Day 4500
        assertEquals(3000.0, PricingCalculator.calculateRoomCharge(RoomType.AC, 1, StayType.NIGHT), 0.01)
        assertEquals(4500.0, PricingCalculator.calculateRoomCharge(RoomType.AC, 1, StayType.FULL_DAY), 0.01)

        // 2 persons: Night 3500, Full Day 5500
        assertEquals(3500.0, PricingCalculator.calculateRoomCharge(RoomType.AC, 2, StayType.NIGHT), 0.01)
        assertEquals(5500.0, PricingCalculator.calculateRoomCharge(RoomType.AC, 2, StayType.FULL_DAY), 0.01)

        // 3 persons: Night 4000, Full Day 6000
        assertEquals(4000.0, PricingCalculator.calculateRoomCharge(RoomType.AC, 3, StayType.NIGHT), 0.01)
        assertEquals(6000.0, PricingCalculator.calculateRoomCharge(RoomType.AC, 3, StayType.FULL_DAY), 0.01)

        // 4 persons: Night 4500, Full Day 6500
        assertEquals(4500.0, PricingCalculator.calculateRoomCharge(RoomType.AC, 4, StayType.NIGHT), 0.01)
        assertEquals(6500.0, PricingCalculator.calculateRoomCharge(RoomType.AC, 4, StayType.FULL_DAY), 0.01)

        // 5 persons: Night 5000, Full Day 7500
        assertEquals(5000.0, PricingCalculator.calculateRoomCharge(RoomType.AC, 5, StayType.NIGHT), 0.01)
        assertEquals(7500.0, PricingCalculator.calculateRoomCharge(RoomType.AC, 5, StayType.FULL_DAY), 0.01)
    }

    @Test
    fun testNonAcRoomPricing() {
        // 1 person: Night 2500, Full Day 4000
        assertEquals(2500.0, PricingCalculator.calculateRoomCharge(RoomType.NON_AC, 1, StayType.NIGHT), 0.01)
        assertEquals(4000.0, PricingCalculator.calculateRoomCharge(RoomType.NON_AC, 1, StayType.FULL_DAY), 0.01)

        // 2 persons: Night 3000, Full Day 4500
        assertEquals(3000.0, PricingCalculator.calculateRoomCharge(RoomType.NON_AC, 2, StayType.NIGHT), 0.01)
        assertEquals(4500.0, PricingCalculator.calculateRoomCharge(RoomType.NON_AC, 2, StayType.FULL_DAY), 0.01)

        // 3 persons: Night 3500, Full Day 5000
        assertEquals(3500.0, PricingCalculator.calculateRoomCharge(RoomType.NON_AC, 3, StayType.NIGHT), 0.01)
        assertEquals(5000.0, PricingCalculator.calculateRoomCharge(RoomType.NON_AC, 3, StayType.FULL_DAY), 0.01)

        // 4 persons: Night 4000, Full Day 5500
        assertEquals(4000.0, PricingCalculator.calculateRoomCharge(RoomType.NON_AC, 4, StayType.NIGHT), 0.01)
        assertEquals(5500.0, PricingCalculator.calculateRoomCharge(RoomType.NON_AC, 4, StayType.FULL_DAY), 0.01)
    }

    @Test
    fun testAcFamilyRoomPricing() {
        // Family room price is fixed and must NOT multiply by number of guests
        for (guests in 1..6) {
            assertEquals(5000.0, PricingCalculator.calculateRoomCharge(RoomType.AC_FAMILY, guests, StayType.NIGHT), 0.01)
            assertEquals(7500.0, PricingCalculator.calculateRoomCharge(RoomType.AC_FAMILY, guests, StayType.FULL_DAY), 0.01)
        }
    }

    @Test
    fun testCurrencyFormatting() {
        assertEquals("Rs. 3,500", PricingCalculator.formatCurrency(3500.0))
        assertEquals("Rs. 7,500", PricingCalculator.formatCurrency(7500.0))
    }

    @Test
    fun testCustomRoomPricing() {
        val room = AppDatabase.DEFAULT_ROOMS.first { it.roomNumber == "02" }.copy(
            nightPrice1 = 3200.0,
            nightPrice2 = 3800.0,
            fullDayPrice1 = 4800.0,
            fullDayPrice2 = 5800.0
        )
        assertEquals(3200.0, PricingCalculator.calculateRoomCharge(room, 1, StayType.NIGHT), 0.01)
        assertEquals(3800.0, PricingCalculator.calculateRoomCharge(room, 2, StayType.NIGHT), 0.01)
        assertEquals(4800.0, PricingCalculator.calculateRoomCharge(room, 1, StayType.FULL_DAY), 0.01)
        assertEquals(5800.0, PricingCalculator.calculateRoomCharge(room, 2, StayType.FULL_DAY), 0.01)
    }

    @Test
    fun testCustomFamilyRoomPricingFixed() {
        val familyRoom = AppDatabase.DEFAULT_ROOMS.first { it.roomNumber == "09" }.copy(
            familyNightPrice = 6000.0,
            familyFullDayPrice = 9000.0
        )
        // Family room price is fixed and does not multiply by guest count
        for (g in 1..5) {
            assertEquals(6000.0, familyRoom.getPrice(g, StayType.NIGHT), 0.01)
            assertEquals(9000.0, familyRoom.getPrice(g, StayType.FULL_DAY), 0.01)
        }
    }

    @Test
    fun testPdfInvoiceFileName() {
        val bill = com.example.data.BillEntity(
            billNumber = "INV-2026-0001",
            customerId = 1L,
            customerName = "John Doe",
            customerNic = "199012345678",
            customerPhone = "0771234567",
            roomNumber = "09",
            roomType = RoomType.AC_FAMILY,
            guestsCount = 4,
            stayType = StayType.NIGHT,
            checkInDate = "2026-09-04",
            checkInTime = "8:00 PM",
            checkOutDate = "2026-09-05",
            checkOutTime = "8:30 AM",
            roomCharge = 5000.0,
            total = 5000.0,
            paid = 5000.0,
            balance = 0.0
        )
        val fileName = com.example.util.PdfInvoiceGenerator.getInvoiceFileName(bill)
        assertEquals("GuestHouse_INV-2026-0001.pdf", fileName)
    }

    @Test
    fun testBillPreservesAppliedPriceSnapshot() {
        // A bill created with room 09 AC FAMILY night stay at Rs. 5000
        val savedBill = com.example.data.BillEntity(
            billNumber = "INV-2026-0005",
            customerId = 2L,
            customerName = "Jane Doe",
            customerNic = "921234567V",
            customerPhone = "0771234567",
            roomNumber = "09",
            roomType = RoomType.AC_FAMILY,
            guestsCount = 4,
            stayType = StayType.NIGHT,
            checkInDate = "2026-09-04",
            checkInTime = "8:00 PM",
            checkOutDate = "2026-09-05",
            checkOutTime = "8:30 AM",
            roomCharge = 5000.0,
            total = 5000.0,
            paid = 5000.0,
            balance = 0.0
        )

        // Even if room 09 price is later updated by owner to 7000
        val updatedRoom09 = AppDatabase.DEFAULT_ROOMS.first { it.roomNumber == "09" }.copy(
            familyNightPrice = 7000.0
        )
        // New calculation would be 7000:
        assertEquals(7000.0, updatedRoom09.getPrice(4, StayType.NIGHT), 0.01)

        // But the saved bill's roomCharge remains untouched at 5000:
        assertEquals(5000.0, savedBill.roomCharge, 0.01)
        assertEquals(5000.0, savedBill.total, 0.01)
    }
}
