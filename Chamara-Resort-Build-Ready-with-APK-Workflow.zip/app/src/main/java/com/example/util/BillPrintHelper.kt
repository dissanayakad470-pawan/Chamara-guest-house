package com.example.util

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.data.BillEntity
import com.example.data.BillItemEntity

object BillPrintHelper {

    fun generateBillHtml(bill: BillEntity, items: List<BillItemEntity>): String {
        val extraItemsHtml = if (items.isNotEmpty()) {
            val rows = items.joinToString("") { item ->
                """
                <tr>
                    <td style="padding: 6px 0; border-bottom: 1px dashed #e2e8f0;">
                        ${item.description} <small style="color: #64748b;">(${item.category})</small>
                    </td>
                    <td style="padding: 6px 0; text-align: right; border-bottom: 1px dashed #e2e8f0; font-weight: 500;">
                        ${PricingCalculator.formatCurrency(item.amount)}
                    </td>
                </tr>
                """.trimIndent()
            }
            """
            <div style="margin-top: 15px;">
                <div style="font-weight: bold; font-size: 13px; color: #475569; text-transform: uppercase; margin-bottom: 6px;">Extra Charges</div>
                <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
                    $rows
                </table>
            </div>
            """.trimIndent()
        } else ""

        val discountHtml = if (bill.discount > 0) {
            """
            <tr>
                <td style="padding: 4px 0; color: #16a34a;">Discount:</td>
                <td style="padding: 4px 0; text-align: right; color: #16a34a; font-weight: 600;">-${PricingCalculator.formatCurrency(bill.discount)}</td>
            </tr>
            """.trimIndent()
        } else ""

        val balanceColor = if (bill.balance > 0) "#dc2626" else "#16a34a"
        val balanceLabel = if (bill.balance > 0) "BALANCE DUE" else "BALANCE"

        return """
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Bill ${bill.billNumber}</title>
            <style>
                body {
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                    margin: 0;
                    padding: 20px;
                    color: #1e293b;
                    background: #ffffff;
                }
                .bill-card {
                    max-width: 480px;
                    margin: 0 auto;
                    border: 1px solid #cbd5e1;
                    border-radius: 12px;
                    padding: 24px;
                }
                .header {
                    text-align: center;
                    border-bottom: 2px solid #0f172a;
                    padding-bottom: 14px;
                    margin-bottom: 16px;
                }
                .header h1 {
                    margin: 0;
                    font-size: 24px;
                    letter-spacing: 1.5px;
                    color: #0f172a;
                }
                .header p {
                    margin: 4px 0 0;
                    color: #64748b;
                    font-size: 13px;
                }
                .meta-row {
                    display: flex;
                    justify-content: space-between;
                    font-size: 14px;
                    margin-bottom: 8px;
                }
                .section-title {
                    font-weight: 700;
                    font-size: 12px;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                    color: #64748b;
                    margin-top: 14px;
                    margin-bottom: 6px;
                    border-bottom: 1px solid #e2e8f0;
                    padding-bottom: 4px;
                }
                .info-table {
                    width: 100%;
                    font-size: 14px;
                    border-collapse: collapse;
                }
                .info-table td {
                    padding: 4px 0;
                }
                .info-table td.label {
                    color: #64748b;
                    width: 40%;
                }
                .info-table td.value {
                    font-weight: 600;
                    color: #0f172a;
                }
                .summary-table {
                    width: 100%;
                    font-size: 14px;
                    margin-top: 12px;
                    border-top: 1px solid #cbd5e1;
                    padding-top: 8px;
                }
                .summary-table td {
                    padding: 5px 0;
                }
                .total-row {
                    font-size: 18px;
                    font-weight: 800;
                    color: #0f172a;
                    border-top: 2px solid #e2e8f0;
                    border-bottom: 2px solid #e2e8f0;
                }
                .balance-row {
                    font-size: 16px;
                    font-weight: 800;
                }
                .footer {
                    text-align: center;
                    margin-top: 24px;
                    font-size: 12px;
                    color: #94a3b8;
                    border-top: 1px dashed #cbd5e1;
                    padding-top: 12px;
                }
                .badge {
                    display: inline-block;
                    padding: 2px 8px;
                    border-radius: 6px;
                    font-size: 12px;
                    font-weight: bold;
                    background: #f1f5f9;
                    color: #334155;
                }
            </style>
        </head>
        <body>
            <div class="bill-card">
                <div class="header">
                    <h1>CHAMARA RESORT</h1>
                    <p>Official Cashier Receipt & Bill</p>
                </div>

                <div class="meta-row">
                    <div><strong>Bill #:</strong> ${bill.billNumber}</div>
                    <div><strong>Date:</strong> ${bill.checkInDate}</div>
                </div>

                <div class="section-title">Customer Information</div>
                <table class="info-table">
                    <tr><td class="label">Customer Name:</td><td class="value">${bill.customerName}</td></tr>
                    <tr><td class="label">NIC / ID:</td><td class="value">${bill.customerNic}</td></tr>
                    <tr><td class="label">Phone:</td><td class="value">${bill.customerPhone.ifBlank { "N/A" }}</td></tr>
                </table>

                <div class="section-title">Stay & Room Details</div>
                <table class="info-table">
                    <tr><td class="label">Room Number:</td><td class="value">Room ${bill.roomNumber} <span class="badge">${bill.roomType.badgeText}</span></td></tr>
                    <tr><td class="label">Guests:</td><td class="value">${bill.guestsCount} Person(s)</td></tr>
                    <tr><td class="label">Stay Type:</td><td class="value">${bill.stayType.displayName}</td></tr>
                    <tr><td class="label">Check-in:</td><td class="value">${bill.checkInDate} at ${bill.checkInTime}</td></tr>
                    <tr><td class="label">Check-out:</td><td class="value">${bill.checkOutDate} at ${bill.checkOutTime}</td></tr>
                </table>

                <div class="section-title">Billing Breakdown</div>
                <table class="summary-table">
                    <tr>
                        <td style="color: #475569;">Room Charge:</td>
                        <td style="text-align: right; font-weight: 600;">${PricingCalculator.formatCurrency(bill.roomCharge)}</td>
                    </tr>
                    ${if (bill.extraChargesTotal > 0) """
                    <tr>
                        <td style="color: #475569;">Extra Charges:</td>
                        <td style="text-align: right; font-weight: 600;">${PricingCalculator.formatCurrency(bill.extraChargesTotal)}</td>
                    </tr>
                    """ else ""}
                    $discountHtml
                    <tr class="total-row">
                        <td style="padding: 8px 0;">TOTAL:</td>
                        <td style="padding: 8px 0; text-align: right;">${PricingCalculator.formatCurrency(bill.total)}</td>
                    </tr>
                    <tr>
                        <td style="padding: 6px 0; color: #475569;">PAID (${bill.paymentMethod.displayName}):</td>
                        <td style="padding: 6px 0; text-align: right; font-weight: 600; color: #0284c7;">${PricingCalculator.formatCurrency(bill.paid)}</td>
                    </tr>
                    <tr class="balance-row">
                        <td style="padding: 6px 0; color: $balanceColor;">$balanceLabel:</td>
                        <td style="padding: 6px 0; text-align: right; color: $balanceColor;">${PricingCalculator.formatCurrency(bill.balance)}</td>
                    </tr>
                </table>

                $extraItemsHtml

                <div class="footer">
                    Thank you for staying with us!<br>
                    Please retain this bill for your records.
                </div>
            </div>
        </body>
        </html>
        """.trimIndent()
    }

    /**
     * Prints or Saves as PDF via Android native PrintManager
     */
    fun printOrSavePdf(activity: Activity, bill: BillEntity, items: List<BillItemEntity>) {
        PdfInvoiceGenerator.printPdf(activity, bill, items)
    }

    /**
     * Shares bill PDF via Android standard share sheet
     */
    fun shareBill(context: Context, bill: BillEntity, items: List<BillItemEntity>) {
        PdfInvoiceGenerator.sharePdf(context, bill, items)
    }
}
