package com.example.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.BillEntity
import com.example.data.CustomerEntity
import com.example.data.RoomEntity
import com.example.data.RoomStatus
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import com.example.ui.screens.AddEditExpenseDialog
import com.example.ui.screens.BillDetailScreen
import com.example.ui.screens.BillsListScreen
import com.example.ui.screens.CheckoutDialog
import com.example.ui.screens.CustomersScreen
import com.example.ui.screens.EditPriceDialog
import com.example.ui.screens.EditRoomDialog
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NewBillScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.RoomDetailsScreen
import com.example.ui.screens.RoomsScreen
import com.example.ui.theme.CashierPrimary
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate900

enum class NavigationTab(val label: String, val icon: ImageVector, val tag: String) {
    HOME("HOME", Icons.Default.Home, "nav_home"),
    ROOMS("ROOMS", Icons.Default.MeetingRoom, "nav_rooms"),
    NEW_BILL("NEW BILL", Icons.Default.AddCircle, "nav_new_bill"),
    BILLS("BILLS", Icons.Default.ReceiptLong, "nav_bills"),
    REPORTS("REPORTS", Icons.Default.Assessment, "nav_reports"),
    CUSTOMERS("CUSTOMERS", Icons.Default.People, "nav_customers")
}

@Composable
fun MainAppScreen(
    viewModel: BillingViewModel,
    modifier: Modifier = Modifier
) {
    var currentTab by remember { mutableStateOf(NavigationTab.HOME) }

    val context = LocalContext.current
    val rooms by viewModel.rooms.collectAsStateWithLifecycle()
    val availableCount by viewModel.availableRoomsCount.collectAsStateWithLifecycle()
    val occupiedCount by viewModel.occupiedRoomsCount.collectAsStateWithLifecycle()

    val bills by viewModel.bills.collectAsStateWithLifecycle()
    val billSearchQuery by viewModel.billSearchQuery.collectAsStateWithLifecycle()

    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val customerSearchQuery by viewModel.customerSearchQuery.collectAsStateWithLifecycle()

    val newBillState by viewModel.newBillState.collectAsStateWithLifecycle()

    val activeCheckoutRoom by viewModel.activeCheckoutRoom.collectAsStateWithLifecycle()
    val activeCheckoutBill by viewModel.activeCheckoutBill.collectAsStateWithLifecycle()

    val viewedBill by viewModel.viewedBill.collectAsStateWithLifecycle()
    val viewedBillItems by viewModel.viewedBillItems.collectAsStateWithLifecycle()

    val selectedCustomer by viewModel.selectedCustomer.collectAsStateWithLifecycle()
    val customerBills by viewModel.customerBills.collectAsStateWithLifecycle()

    val selectedRoomForDetails by viewModel.selectedRoomForDetails.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    val reportData by viewModel.reportData.collectAsStateWithLifecycle()
    val showAddExpenseDialog by viewModel.showAddExpenseDialog.collectAsStateWithLifecycle()
    val expenseToEdit by viewModel.expenseToEdit.collectAsStateWithLifecycle()
    val expenseToDelete by viewModel.expenseToDelete.collectAsStateWithLifecycle()

    var showEditPricesDialog by remember { mutableStateOf(false) }
    var showEditRoomDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    // Edit Prices Dialog overlay
    if (showEditPricesDialog && selectedRoomForDetails != null) {
        EditPriceDialog(
            room = selectedRoomForDetails!!,
            onDismiss = { showEditPricesDialog = false },
            onSavePrices = { updatedRoom ->
                viewModel.updateRoomPricing(
                    room = updatedRoom,
                    onSuccess = {
                        showEditPricesDialog = false
                    }
                )
            }
        )
    }

    // Edit Room Dialog overlay
    if (showEditRoomDialog && selectedRoomForDetails != null) {
        EditRoomDialog(
            room = selectedRoomForDetails!!,
            existingRoomNumbers = rooms.map { it.roomNumber },
            onDismiss = { showEditRoomDialog = false },
            onSave = { oldNum, updatedRoom ->
                viewModel.updateRoomDetails(
                    oldRoomNumber = oldNum,
                    updatedRoom = updatedRoom,
                    onSuccess = {
                        showEditRoomDialog = false
                    }
                )
            }
        )
    }

    // Checkout Dialog overlay when a room checkout is opened
    activeCheckoutRoom?.let { room ->
        CheckoutDialog(
            room = room,
            bill = activeCheckoutBill,
            onDismiss = { viewModel.closeCheckout() },
            onConfirmCheckout = { paymentAmount ->
                activeCheckoutBill?.let { b ->
                    viewModel.completeCheckout(room.roomNumber, b.id, paymentAmount) {
                        // Room is now available
                    }
                } ?: run {
                    viewModel.completeCheckout(room.roomNumber, 0L, 0.0) {}
                }
            },
            onViewBill = { bill ->
                viewModel.viewBill(bill)
            }
        )
    }

    // Add / Edit Expense Dialog
    if (showAddExpenseDialog || expenseToEdit != null) {
        AddEditExpenseDialog(
            expenseToEdit = expenseToEdit,
            onDismiss = {
                viewModel.showAddExpenseDialog.value = false
                viewModel.expenseToEdit.value = null
            },
            onSaveExpense = { id, category, description, amount, date, note ->
                viewModel.saveExpense(
                    id = id,
                    category = category,
                    description = description,
                    amount = amount,
                    date = date,
                    note = note,
                    onSuccess = {
                        viewModel.showAddExpenseDialog.value = false
                        viewModel.expenseToEdit.value = null
                    }
                )
            }
        )
    }

    // Delete Expense Confirmation Dialog
    expenseToDelete?.let { expense ->
        AlertDialog(
            onDismissRequest = { viewModel.expenseToDelete.value = null },
            title = { Text("Delete Expense?", fontWeight = FontWeight.Bold) },
            text = {
                Text("Are you sure you want to delete this ${expense.category} expense of Rs. ${expense.amount.toLong()} (${expense.description})?")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteExpense(expense)
                    }
                ) {
                    Text("DELETE", color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { viewModel.expenseToDelete.value = null }
                ) {
                    Text("CANCEL")
                }
            }
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            // Show bottom navigation bar when not viewing a single bill receipt full-screen
            if (viewedBill == null) {
                androidx.compose.foundation.layout.Column {
                    androidx.compose.material3.HorizontalDivider(
                        color = com.example.ui.theme.CleanBorder,
                        thickness = 1.dp
                    )
                    NavigationBar(
                        containerColor = com.example.ui.theme.CleanSurface,
                        tonalElevation = 2.dp
                    ) {
                        NavigationTab.values().forEach { tab ->
                            val isSelected = currentTab == tab && selectedRoomForDetails == null
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = {
                                    viewModel.clearSelectedRoomForDetails()
                                    if (tab == NavigationTab.CUSTOMERS) {
                                        viewModel.clearSelectedCustomer()
                                    }
                                    currentTab = tab
                                },
                                icon = {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        fontSize = 9.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        maxLines = 1
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CashierPrimary,
                                    selectedTextColor = CashierPrimary,
                                    indicatorColor = com.example.ui.theme.FamilyGoldBg,
                                    unselectedIconColor = com.example.ui.theme.CleanTextSecondary,
                                    unselectedTextColor = com.example.ui.theme.CleanTextSecondary
                                ),
                                modifier = Modifier.testTag(tab.tag)
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // If viewing a bill receipt detail
            if (viewedBill != null) {
                BillDetailScreen(
                    bill = viewedBill!!,
                    items = viewedBillItems,
                    onBackClick = { viewModel.clearViewedBill() },
                    onNewBillClick = {
                        viewModel.clearViewedBill()
                        viewModel.resetNewBillForm()
                        currentTab = NavigationTab.NEW_BILL
                    }
                )
            } else if (selectedRoomForDetails != null) {
                // Room Details & Pricing Screen
                RoomDetailsScreen(
                    room = selectedRoomForDetails!!,
                    onBackClick = { viewModel.clearSelectedRoomForDetails() },
                    onEditRoomClick = { showEditRoomDialog = true },
                    onEditPricesClick = { showEditPricesDialog = true },
                    onCreateBillClick = {
                        val rNum = selectedRoomForDetails!!.roomNumber
                        viewModel.clearSelectedRoomForDetails()
                        viewModel.resetNewBillForm(rNum)
                        currentTab = NavigationTab.NEW_BILL
                    },
                    onCheckoutClick = {
                        val r = selectedRoomForDetails!!
                        viewModel.clearSelectedRoomForDetails()
                        viewModel.openCheckout(r)
                    },
                    confirmationMessage = snackbarMessage
                )
            } else {
                when (currentTab) {
                    NavigationTab.HOME -> {
                        HomeScreen(
                            rooms = rooms,
                            availableCount = availableCount,
                            occupiedCount = occupiedCount,
                            onRoomClick = { room ->
                                if (room.status == RoomStatus.AVAILABLE) {
                                    viewModel.resetNewBillForm(room.roomNumber)
                                    currentTab = NavigationTab.NEW_BILL
                                } else {
                                    viewModel.openCheckout(room)
                                }
                            },
                            onNewBillClick = {
                                viewModel.resetNewBillForm()
                                currentTab = NavigationTab.NEW_BILL
                            },
                            onReportsClick = {
                                currentTab = NavigationTab.REPORTS
                            },
                            todayIncome = reportData.totalIncome,
                            todayExpenses = reportData.totalExpenses,
                            todayNet = reportData.netIncome
                        )
                    }

                    NavigationTab.ROOMS -> {
                        RoomsScreen(
                            rooms = rooms,
                            onSelectAvailableRoom = { room ->
                                viewModel.resetNewBillForm(room.roomNumber)
                                currentTab = NavigationTab.NEW_BILL
                            },
                            onSelectOccupiedRoom = { room ->
                                viewModel.openCheckout(room)
                            },
                            onSelectRoomDetails = { room ->
                                viewModel.selectRoomForDetails(room)
                            }
                        )
                    }

                    NavigationTab.NEW_BILL -> {
                        NewBillScreen(
                            state = newBillState,
                            rooms = rooms,
                            viewModel = viewModel,
                            onBillSaved = { savedBill ->
                                try {
                                    com.example.util.PdfInvoiceGenerator.generatePdf(context, savedBill, viewModel.viewedBillItems.value)
                                } catch (_: Exception) {}
                            }
                        )
                    }

                    NavigationTab.BILLS -> {
                        BillsListScreen(
                            bills = bills,
                            searchQuery = billSearchQuery,
                            onSearchChange = { viewModel.billSearchQuery.value = it },
                            onBillClick = { bill ->
                                viewModel.viewBill(bill)
                            }
                        )
                    }

                    NavigationTab.REPORTS -> {
                        ReportsScreen(
                            reportData = reportData,
                            onPeriodSelected = { viewModel.setReportPeriod(it) },
                            onCustomDatesChanged = { from, to ->
                                viewModel.setCustomFromDate(from)
                                viewModel.setCustomToDate(to)
                            },
                            onAddExpenseClick = {
                                viewModel.expenseToEdit.value = null
                                viewModel.showAddExpenseDialog.value = true
                            },
                            onEditExpenseClick = { expense ->
                                viewModel.expenseToEdit.value = expense
                            },
                            onDeleteExpenseClick = { expense ->
                                viewModel.expenseToDelete.value = expense
                            },
                            onBillClick = { bill ->
                                viewModel.viewBill(bill)
                            }
                        )
                    }

                    NavigationTab.CUSTOMERS -> {
                        CustomersScreen(
                            customers = customers,
                            searchQuery = customerSearchQuery,
                            onSearchChange = { viewModel.customerSearchQuery.value = it },
                            selectedCustomer = selectedCustomer,
                            customerBills = customerBills,
                            onCustomerClick = { customer ->
                                viewModel.viewCustomer(customer)
                            },
                            onBackFromDetail = {
                                viewModel.clearSelectedCustomer()
                            },
                            onBillClick = { bill ->
                                viewModel.viewBill(bill)
                            }
                        )
                    }
                }
            }
        }
    }
}
