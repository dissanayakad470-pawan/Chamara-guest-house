package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFA8FF00),
    onPrimary = Color(0xFF07130E),
    primaryContainer = Color(0xFF285A32),
    onPrimaryContainer = Color(0xFFE6FFC2),
    secondary = Color(0xFFFFD83D),
    onSecondary = Color(0xFF352B00),
    tertiary = Color(0xFF8BD65B),
    background = Color(0xFF0A1510),
    surface = Color(0xFF14211A),
    onBackground = Color(0xFFF0F6EE),
    onSurface = Color(0xFFF0F6EE),
    surfaceVariant = Color(0xFF22342A),
    onSurfaceVariant = Color(0xFFC9D6CB),
    outline = Color(0xFF536A59)
)

private val LightColorScheme = lightColorScheme(
    primary = CashierPrimary,
    onPrimary = Color.White,
    primaryContainer = CleanBluePill,
    onPrimaryContainer = CashierPrimaryVariant,
    secondary = CashierSecondary,
    onSecondary = Color.White,
    tertiary = CashierTertiary,
    background = CleanBg,
    surface = CleanSurface,
    onBackground = CleanTextPrimary,
    onSurface = CleanTextPrimary,
    surfaceVariant = CleanBg,
    onSurfaceVariant = CleanTextSecondary,
    outline = CleanBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme,
        typography = Typography,
        content = content
    )
}
