package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Chamara Resort — inspired by the supplied black / lime / gold resort sign
val CleanBg = Color(0xFFF4F5EE)
val CleanSurface = Color(0xFFFFFFFF)
val CleanTextPrimary = Color(0xFF162019)
val CleanTextSecondary = Color(0xFF65736B)
val CleanBorder = Color(0xFFDDE4D7)
val CleanBorderLight = Color(0xFFECF1E9)

// Brand accents
val CashierPrimary = Color(0xFF7BD900)
val CashierPrimaryVariant = Color(0xFF173B28)
val CashierSecondary = Color(0xFFFFD83D)
val CashierTertiary = Color(0xFF2E7A45)
val CleanBluePill = Color(0xFFE9F5DD)

// Status colors
val AvailableGreen = Color(0xFF3E8B32)
val AvailableGreenDot = Color(0xFF7BD900)
val AvailableGreenBg = Color(0xFFEDF8E7)
val AvailableGreenBorder = Color(0xFFCFE6BE)

val OccupiedRed = Color(0xFFD94343)
val OccupiedRedBg = Color(0xFFFFEEEE)
val OccupiedRedBorder = Color(0xFFF1CACA)

// Family room accent
val FamilyBlue = Color(0xFF2E7A45)
val FamilyGold = Color(0xFFD5A900)
val FamilyGoldBg = Color(0xFFFFF7D7)

// Slate aliases mapped to the resort palette
val Slate50 = Color(0xFFF4F5EE)
val Slate100 = Color(0xFFE9EEE4)
val Slate200 = CleanBorder
val Slate300 = Color(0xFFC4CEC0)
val Slate500 = CleanTextSecondary
val Slate700 = Color(0xFF34433A)
val Slate800 = Color(0xFF25332B)
val Slate900 = CleanTextPrimary
